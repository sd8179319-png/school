import QRCode from 'qrcode';

export interface UpiPaymentParams {
  upiId: string;
  payeeName: string;
  amount?: number;
  note?: string;
  currency?: string;
}

export function buildUpiUri(params: UpiPaymentParams): string {
  const { upiId, payeeName, amount, note, currency = 'INR' } = params;
  let uri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&cu=${currency}`;
  if (amount && amount > 0) {
    uri += `&am=${amount.toFixed(2)}`;
  }
  if (note) {
    uri += `&tn=${encodeURIComponent(note)}`;
  }
  return uri;
}

export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 200,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    });
  } catch (err) {
    console.error('QR code generation failed:', err);
    return '';
  }
}
