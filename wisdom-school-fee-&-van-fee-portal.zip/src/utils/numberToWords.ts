/**
 * Convert number to words using the Indian Numbering System (Lakhs, Crores, Thousands, Hundreds)
 */
export function numberToWordsIndian(num: number): string {
  if (!num || isNaN(num) || num <= 0) return 'Rupees Zero Only';

  const a = [
    '',
    'One ',
    'Two ',
    'Three ',
    'Four ',
    'Five ',
    'Six ',
    'Seven ',
    'Eight ',
    'Nine ',
    'Ten ',
    'Eleven ',
    'Twelve ',
    'Thirteen ',
    'Fourteen ',
    'Fifteen ',
    'Sixteen ',
    'Seventeen ',
    'Eighteen ',
    'Nineteen '
  ];

  const b = [
    '',
    '',
    'Twenty',
    'Thirty',
    'Forty',
    'Fifty',
    'Sixty',
    'Seventy',
    'Eighty',
    'Ninety'
  ];

  function convertTwoDigits(n: number): string {
    if (n < 20) return a[n];
    return b[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + a[n % 10] : '');
  }

  function inWords(n: number): string {
    const s = ('000000000' + n).slice(-9);
    const crore = parseInt(s.substring(0, 2), 10);
    const lakh = parseInt(s.substring(2, 4), 10);
    const thousand = parseInt(s.substring(4, 6), 10);
    const hundred = parseInt(s.substring(6, 7), 10);
    const rem = parseInt(s.substring(7, 9), 10);

    let str = '';
    if (crore > 0) {
      str += convertTwoDigits(crore).trim() + ' Crore ';
    }
    if (lakh > 0) {
      str += convertTwoDigits(lakh).trim() + ' Lakh ';
    }
    if (thousand > 0) {
      str += convertTwoDigits(thousand).trim() + ' Thousand ';
    }
    if (hundred > 0) {
      str += a[hundred].trim() + ' Hundred ';
    }
    if (rem > 0) {
      if (str !== '') {
        str += 'and ';
      }
      str += convertTwoDigits(rem).trim() + ' ';
    }
    return str.trim();
  }

  const rounded = Math.round(num);
  const result = inWords(rounded);
  return `Rupees ${result} Only`;
}
