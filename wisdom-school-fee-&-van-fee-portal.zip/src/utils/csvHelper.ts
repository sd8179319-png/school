import { Student, SchoolClass, Section } from '../types';

export function exportStudentsToCsv(students: Student[], filename = 'Wisdom_School_Students.csv'): void {
  const headers = [
    'AdmissionNo',
    'StudentName',
    'FatherName',
    'Class',
    'Section',
    'Gender',
    'ParentPhone',
    'Address',
    'AcademicYear',
    'AdmissionFee',
    'TuitionFee',
    'ExamFee',
    'BooksFee',
    'UniformFee',
    'TotalSchoolFee',
    'SchoolFeePaid',
    'SchoolFeeStatus',
    'UsesVan',
    'VanRoute',
    'PickupPoint',
    'VanFee',
    'VanFeePaid',
    'VanFeeStatus'
  ];

  const rows = students.map(s => {
    const b = s.schoolFees.feeBreakdown;
    return [
      `"${s.admissionNo}"`,
      `"${s.name}"`,
      `"${s.fatherName}"`,
      `"${s.studentClass}"`,
      `"${s.section}"`,
      `"${s.gender}"`,
      `"${s.parentPhone}"`,
      `"${s.address}"`,
      `"${s.academicYear}"`,
      b.admissionFee,
      b.tuitionFee,
      b.examFee,
      b.booksStationeryFee,
      b.uniformActivityFee,
      s.schoolFees.totalFee,
      s.schoolFees.paidAmount,
      s.schoolFees.status,
      s.vanFees.usesVan ? 'YES' : 'NO',
      `"${s.vanFees.route}"`,
      `"${s.vanFees.pickupPoint}"`,
      s.vanFees.termFee,
      s.vanFees.paidAmount,
      s.vanFees.vanStatus
    ].join(',');
  });

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function downloadSampleCsvTemplate(): void {
  const sampleHeaders = [
    'AdmissionNo',
    'StudentName',
    'FatherName',
    'Class',
    'Section',
    'Gender',
    'ParentPhone',
    'Address',
    'TuitionFee',
    'BooksFee',
    'UsesVan(YES/NO)',
    'VanRoute',
    'VanFee'
  ];

  const sampleData = [
    'W2026-101,V. Vignesh,M. Venkatesan,LKG,A,Male,9176593190,"Essur Village",6000,1800,YES,"Route 1: Essur",4500',
    'W2026-102,K. Priya,K. Kumar,3rd Standard,B,Female,9840123456,"Acharapakkam",9000,2500,NO,None,0',
    'W2026-103,R. Rahul,R. Ramesh,5th Standard,A,Male,9789012345,"Melmaruvathur",10500,2300,YES,"Route 2: Melmaruvathur",5000'
  ];

  const csvContent = 'data:text/csv;charset=utf-8,' + [sampleHeaders.join(','), ...sampleData].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', 'Student_Import_Sample_Template.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function parseStudentsCsv(csvText: string): Student[] {
  const lines = csvText.split(/\r?\n/).filter(line => line.trim().length > 0);
  if (lines.length < 2) return [];

  const students: Student[] = [];
  // Skip header line
  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i];
    // Simple CSV parser supporting quotes
    const values: string[] = [];
    let insideQuote = false;
    let currentValue = '';

    for (let charIndex = 0; charIndex < rawLine.length; charIndex++) {
      const char = rawLine[charIndex];
      if (char === '"') {
        insideQuote = !insideQuote;
      } else if (char === ',' && !insideQuote) {
        values.push(currentValue.trim());
        currentValue = '';
      } else {
        currentValue += char;
      }
    }
    values.push(currentValue.trim());

    if (values.length < 4) continue;

    const admNo = values[0] || `W2026-${Math.floor(100 + Math.random() * 900)}`;
    const name = values[1] || 'Student Name';
    const fatherName = values[2] || 'Parent';
    const rawClass = values[3] || 'LKG';
    const section = (values[4] as Section) || 'A';
    const gender = (values[5] === 'Female' ? 'Female' : 'Male');
    const phone = values[6] || '9176593190';
    const address = values[7] || 'Essur';
    const tuitionFee = parseFloat(values[8]) || 8000;
    const booksFee = parseFloat(values[9]) || 2000;
    const usesVan = (values[10] || '').toUpperCase() === 'YES';
    const vanRoute = values[11] || (usesVan ? 'Route 1: Essur' : 'None');
    const vanFee = parseFloat(values[12]) || (usesVan ? 4500 : 0);

    const validClass: SchoolClass = [
      'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'
    ].includes(rawClass as SchoolClass) ? (rawClass as SchoolClass) : 'LKG';

    const totalFee = tuitionFee + booksFee;

    students.push({
      id: `imported-${Date.now()}-${i}`,
      admissionNo: admNo,
      name,
      fatherName,
      studentClass: validClass,
      section: ['A', 'B', 'C'].includes(section) ? section : 'A',
      gender,
      parentPhone: phone,
      whatsappPhone: phone,
      address,
      academicYear: '2026 - 2027',
      schoolFees: {
        totalFee,
        paidAmount: 0,
        term: 'Term 1',
        feeBreakdown: {
          admissionFee: 0,
          tuitionFee,
          examFee: 0,
          booksStationeryFee: booksFee,
          uniformActivityFee: 0,
          otherFee: 0,
        },
        status: 'Pending',
      },
      vanFees: {
        usesVan,
        route: vanRoute,
        pickupPoint: usesVan ? 'Bus Stop' : 'Walking',
        termFee: vanFee,
        paidAmount: 0,
        vanStatus: usesVan ? 'Pending' : 'Paid',
      },
    });
  }

  return students;
}
