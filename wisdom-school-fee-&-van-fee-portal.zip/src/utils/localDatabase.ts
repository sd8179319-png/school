import type { FeeReceipt, SchoolSettings, Student } from '../types';

const DATABASE_NAME = 'wisdom-school-data';
const DATABASE_VERSION = 1;
const STORE_NAME = 'app-state';
const DATA_KEY = 'current';

const LEGACY_KEYS = {
  settings: 'wisdom_settings_v1',
  students: 'wisdom_students_v1',
  receipts: 'wisdom_receipts_v1',
};

export interface AppData {
  settings: SchoolSettings;
  students: Student[];
  receipts: FeeReceipt[];
}

function openDatabase(): Promise<IDBDatabase> {
  if (typeof indexedDB === 'undefined') {
    return Promise.reject(new Error('IndexedDB is not available in this browser.'));
  }

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);

    request.onupgradeneeded = () => {
      request.result.createObjectStore(STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Could not open the local database.'));
    request.onblocked = () => reject(new Error('The local database is blocked by another browser tab.'));
  });
}

function readLegacyValue<T>(key: string, fallback: T): T {
  const stored = localStorage.getItem(key);
  return stored === null ? fallback : JSON.parse(stored) as T;
}

export function loadLegacyAppData(defaults: AppData): AppData {
  return {
    settings: readLegacyValue(LEGACY_KEYS.settings, defaults.settings),
    students: readLegacyValue(LEGACY_KEYS.students, defaults.students),
    receipts: readLegacyValue(LEGACY_KEYS.receipts, defaults.receipts),
  };
}

function removeLegacyData(): void {
  try {
    Object.values(LEGACY_KEYS).forEach(key => localStorage.removeItem(key));
  } catch (error) {
    console.error('Could not remove migrated localStorage data:', error);
  }
}

export async function loadAppData(defaults: AppData): Promise<AppData> {
  const database = await openDatabase();

  try {
    const transaction = database.transaction(STORE_NAME, 'readonly');
    const request = transaction.objectStore(STORE_NAME).get(DATA_KEY);
    const savedData = await new Promise<AppData | undefined>((resolve, reject) => {
      let result: AppData | undefined;
      request.onsuccess = () => {
        result = request.result as AppData | undefined;
      };
      request.onerror = () => reject(request.error ?? new Error('Could not read saved data.'));
      transaction.oncomplete = () => resolve(result);
      transaction.onerror = () => reject(transaction.error ?? new Error('Could not read saved data.'));
      transaction.onabort = () => reject(transaction.error ?? new Error('Reading saved data was interrupted.'));
    });

    if (savedData) {
      removeLegacyData();
      return savedData;
    }

    const migratedData = loadLegacyAppData(defaults);
    await saveWithDatabase(database, migratedData);
    removeLegacyData();
    return migratedData;
  } finally {
    database.close();
  }
}

async function saveWithDatabase(database: IDBDatabase, data: AppData): Promise<void> {
  const transaction = database.transaction(STORE_NAME, 'readwrite');
  transaction.objectStore(STORE_NAME).put(data, DATA_KEY);

  await new Promise<void>((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error('Could not save data to the local database.'));
    transaction.onabort = () => reject(transaction.error ?? new Error('Saving data to the local database was interrupted.'));
  });
}

export async function saveAppData(data: AppData): Promise<void> {
  const database = await openDatabase();

  try {
    await saveWithDatabase(database, data);
  } finally {
    database.close();
  }
}
