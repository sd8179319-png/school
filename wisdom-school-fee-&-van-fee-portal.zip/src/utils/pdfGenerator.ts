import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { SchoolSettings, Student, FeeReceipt } from '../types';
import { numberToWordsIndian } from './numberToWords';

export interface BulkPdfFilter {
  selectedClass?: string;
  statusFilter?: 'all' | 'due' | 'paid';
  academicYear?: string;
}

/**
 * 1. Bulk School Fees Only Register PDF
 */
export function generateBulkSchoolFeesPdf(
  students: Student[],
  settings: SchoolSettings,
  filter: BulkPdfFilter
): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  // Filter students
  const filtered = students.filter(s => {
    if (filter.selectedClass && filter.selectedClass !== 'All' && s.studentClass !== filter.selectedClass) {
      return false;
    }
    if (filter.statusFilter === 'due' && s.schoolFees.status === 'Paid') {
      return false;
    }
    if (filter.statusFilter === 'paid' && s.schoolFees.status !== 'Paid') {
      return false;
    }
    return true;
  });

  // Header
  doc.setFillColor(30, 58, 138); // brand navy #1e3a8a
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(settings.schoolName, 148.5, 9, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`${settings.addressLine1}, ${settings.addressLine2} | Phone: ${settings.phone1}`, 148.5, 15, { align: 'center' });
  doc.text(`SCHOOL FEES AUDIT & COLLECTION REGISTER - ${filter.selectedClass || 'ALL CLASSES'} (${settings.currentAcademicYear})`, 148.5, 20, { align: 'center' });

  // Summary Metrics Banner
  const totalStudents = filtered.length;
  const totalBilled = filtered.reduce((acc, s) => acc + s.schoolFees.totalFee, 0);
  const totalCollected = filtered.reduce((acc, s) => acc + s.schoolFees.paidAmount, 0);
  const totalPending = totalBilled - totalCollected;

  doc.setFillColor(241, 245, 249);
  doc.rect(14, 27, 269, 12, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(14, 27, 269, 12, 'S');

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Total Students: ${totalStudents}`, 20, 34);
  doc.text(`Total Fees: Rs. ${totalBilled.toLocaleString('en-IN')}`, 75, 34);
  doc.setTextColor(22, 101, 52); // green
  doc.text(`Collected: Rs. ${totalCollected.toLocaleString('en-IN')}`, 140, 34);
  doc.setTextColor(185, 28, 28); // red
  doc.text(`Balance Due: Rs. ${totalPending.toLocaleString('en-IN')}`, 200, 34);
  doc.setTextColor(30, 58, 138);
  doc.text(`GPay: ${settings.gpayNumber}`, 250, 34);

  // Table Data
  const tableRows = filtered.map((s, index) => {
    const fee = s.schoolFees;
    const balance = fee.totalFee - fee.paidAmount;
    return [
      (index + 1).toString(),
      s.admissionNo,
      s.name,
      `${s.studentClass} - ${s.section}`,
      s.parentPhone,
      `Rs. ${fee.feeBreakdown.admissionFee}`,
      `Rs. ${fee.feeBreakdown.tuitionFee}`,
      `Rs. ${fee.feeBreakdown.booksStationeryFee + fee.feeBreakdown.examFee + fee.feeBreakdown.uniformActivityFee}`,
      `Rs. ${fee.totalFee.toLocaleString('en-IN')}`,
      `Rs. ${fee.paidAmount.toLocaleString('en-IN')}`,
      `Rs. ${balance.toLocaleString('en-IN')}`,
      fee.status.toUpperCase(),
    ];
  });

  autoTable(doc, {
    startY: 42,
    head: [[
      'S.No',
      'Adm No',
      'Student Name',
      'Class & Sec',
      'Parent Mobile',
      'Adm Fee',
      'Tuition',
      'Books/Exam',
      'Total Fee',
      'Paid (Rs.)',
      'Due (Rs.)',
      'Status'
    ]],
    body: tableRows,
    styles: {
      fontSize: 8,
      cellPadding: 2,
      font: 'helvetica',
      textColor: [15, 23, 42],
    },
    headStyles: {
      fillColor: [30, 58, 138],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'center', cellWidth: 20 },
      2: { fontStyle: 'bold', cellWidth: 38 },
      3: { halign: 'center', cellWidth: 22 },
      4: { halign: 'center', cellWidth: 24 },
      5: { halign: 'right', cellWidth: 18 },
      6: { halign: 'right', cellWidth: 18 },
      7: { halign: 'right', cellWidth: 22 },
      8: { halign: 'right', fontStyle: 'bold', cellWidth: 22 },
      9: { halign: 'right', cellWidth: 22, textColor: [22, 101, 52] },
      10: { halign: 'right', cellWidth: 22, textColor: [185, 28, 28], fontStyle: 'bold' },
      11: { halign: 'center', cellWidth: 18, fontStyle: 'bold' },
    },
    didDrawPage: (data) => {
      // Footer
      const pageCount = (doc as any).internal.getNumberOfPages();
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(
        `Admin: ${settings.adminName} | Principal: ${settings.principalName} | GPay: ${settings.gpayNumber} | Generated on ${new Date().toLocaleDateString('en-IN')}`,
        14,
        202
      );
      doc.text(`Page ${data.pageNumber} of ${pageCount}`, 275, 202, { align: 'right' });
    },
  });

  const fileName = `School_Fees_Bulk_Report_${(filter.selectedClass || 'All').replace(/\s+/g, '_')}_${Date.now()}.pdf`;
  doc.save(fileName);
}

/**
 * 2. Bulk Van Fees Only Register PDF
 */
export function generateBulkVanFeesPdf(
  students: Student[],
  settings: SchoolSettings,
  filter: BulkPdfFilter
): void {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  // Filter only students who use van
  const vanRiders = students.filter(s => {
    if (!s.vanFees.usesVan) return false;
    if (filter.selectedClass && filter.selectedClass !== 'All' && s.studentClass !== filter.selectedClass) {
      return false;
    }
    if (filter.statusFilter === 'due' && s.vanFees.vanStatus === 'Paid') {
      return false;
    }
    if (filter.statusFilter === 'paid' && s.vanFees.vanStatus !== 'Paid') {
      return false;
    }
    return true;
  });

  // Header
  doc.setFillColor(202, 138, 4); // Amber-gold for school van / transport
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(settings.schoolName, 148.5, 9, { align: 'center' });

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`SCHOOL VAN & TRANSPORT FEE MASTER REGISTER - ACADEMIC YEAR ${settings.currentAcademicYear}`, 148.5, 15, { align: 'center' });
  doc.text(`Admin: ${settings.adminName} | Principal: ${settings.principalName} | GPay: ${settings.gpayNumber}`, 148.5, 20, { align: 'center' });

  // Summary Metrics Banner
  const totalVanStudents = vanRiders.length;
  const totalVanFee = vanRiders.reduce((acc, s) => acc + s.vanFees.termFee, 0);
  const totalVanCollected = vanRiders.reduce((acc, s) => acc + s.vanFees.paidAmount, 0);
  const totalVanPending = totalVanFee - totalVanCollected;

  doc.setFillColor(254, 243, 199); // Amber 100
  doc.rect(14, 27, 269, 12, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.rect(14, 27, 269, 12, 'S');

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(`Van Riders: ${totalVanStudents}`, 20, 34);
  doc.text(`Total Van Fees: Rs. ${totalVanFee.toLocaleString('en-IN')}`, 75, 34);
  doc.setTextColor(22, 101, 52);
  doc.text(`Collected: Rs. ${totalVanCollected.toLocaleString('en-IN')}`, 140, 34);
  doc.setTextColor(185, 28, 28);
  doc.text(`Van Dues Pending: Rs. ${totalVanPending.toLocaleString('en-IN')}`, 200, 34);
  doc.setTextColor(15, 23, 42);
  doc.text(`GPay: ${settings.gpayNumber}`, 255, 34);

  // Table Data
  const tableRows = vanRiders.map((s, index) => {
    const v = s.vanFees;
    const due = v.termFee - v.paidAmount;
    return [
      (index + 1).toString(),
      s.admissionNo,
      s.name,
      `${s.studentClass} - ${s.section}`,
      v.route,
      v.pickupPoint,
      s.parentPhone,
      `Rs. ${v.termFee.toLocaleString('en-IN')}`,
      `Rs. ${v.paidAmount.toLocaleString('en-IN')}`,
      `Rs. ${due.toLocaleString('en-IN')}`,
      v.vanStatus.toUpperCase(),
      v.lastPaymentDate || 'Pending',
    ];
  });

  autoTable(doc, {
    startY: 42,
    head: [[
      'S.No',
      'Adm No',
      'Student Name',
      'Class',
      'Assigned Route',
      'Pickup Point',
      'Parent Contact',
      'Van Fee',
      'Paid',
      'Due',
      'Status',
      'Last Paid'
    ]],
    body: tableRows,
    styles: {
      fontSize: 8,
      cellPadding: 2,
      font: 'helvetica',
    },
    headStyles: {
      fillColor: [180, 83, 9], // Amber-700
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'center',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 10 },
      1: { halign: 'center', cellWidth: 20 },
      2: { fontStyle: 'bold', cellWidth: 34 },
      3: { halign: 'center', cellWidth: 18 },
      4: { cellWidth: 42 },
      5: { cellWidth: 32 },
      6: { halign: 'center', cellWidth: 22 },
      7: { halign: 'right', cellWidth: 18 },
      8: { halign: 'right', cellWidth: 18, textColor: [22, 101, 52] },
      9: { halign: 'right', cellWidth: 18, textColor: [185, 28, 28], fontStyle: 'bold' },
      10: { halign: 'center', cellWidth: 16, fontStyle: 'bold' },
      11: { halign: 'center', cellWidth: 20 },
    },
    didDrawPage: (data) => {
      const pageCount = (doc as any).internal.getNumberOfPages();
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(
        `Transport Incharge | Admin: ${settings.adminName} | Principal: ${settings.principalName} | Generated: ${new Date().toLocaleDateString('en-IN')}`,
        14,
        202
      );
      doc.text(`Page ${data.pageNumber} of ${pageCount}`, 275, 202, { align: 'right' });
    },
  });

  const fileName = `Van_Fees_Bulk_Report_${Date.now()}.pdf`;
  doc.save(fileName);
}

/**
 * 3. Bulk Dual-Copy Slips PDF (Multi-page printable slips: School Copy + Parent Copy)
 */
export function generateBulkReceiptSlipsPdf(
  students: Student[],
  settings: SchoolSettings,
  type: 'school-only' | 'van-only' | 'both',
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Filter students based on type
  const targetStudents = students.filter(s => {
    if (type === 'van-only') return s.vanFees.usesVan;
    return true;
  });

  if (targetStudents.length === 0) {
    alert('No students found matching the selected criteria.');
    return;
  }

  targetStudents.forEach((student, index) => {
    if (index > 0) {
      doc.addPage();
    }

    const receiptNo = `WNS-2026-${1000 + index + 1}`;
    const today = new Date().toLocaleDateString('en-IN');

    // Draw School Copy (Top Half of A4)
    drawSingleReceiptCopy(doc, 10, 'SCHOOL COPY', student, settings, receiptNo, today, type, qrDataUrl);

    // Draw Cutting Line with scissors indicator
    doc.setDrawColor(148, 163, 184);
    doc.setLineDashPattern([2, 2], 0);
    doc.line(10, 148, 200, 148);
    doc.setLineDashPattern([], 0);

    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('--- CUT HERE (DUAL COPY A4) ---', 105, 149, { align: 'center' });

    // Draw Student Copy (Bottom Half of A4)
    drawSingleReceiptCopy(doc, 155, 'STUDENT / PARENT COPY', student, settings, receiptNo, today, type, qrDataUrl);
  });

  const fileName = `Bulk_${type === 'van-only' ? 'Van' : 'School'}_Receipt_Slips_${Date.now()}.pdf`;
  doc.save(fileName);
}

/**
 * Helper to draw one half of an A4 dual receipt
 */
function drawSingleReceiptCopy(
  doc: jsPDF,
  startY: number,
  copyLabel: string,
  student: Student,
  settings: SchoolSettings,
  receiptNo: string,
  dateStr: string,
  type: 'school-only' | 'van-only' | 'both',
  qrDataUrl?: string
): void {
  const boxHeight = 132;
  const isSchool = copyLabel.includes('SCHOOL');

  // Outer border
  doc.setDrawColor(30, 58, 138);
  doc.setLineWidth(0.8);
  doc.rect(10, startY, 190, boxHeight);

  // Copy Badge
  doc.setFillColor(isSchool ? 30 : 15, isSchool ? 58 : 23, isSchool ? 138 : 42);
  doc.rect(160, startY + 2, 38, 5, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.text(copyLabel, 179, startY + 5.5, { align: 'center' });

  // School Header
  doc.setTextColor(30, 58, 138);
  doc.setFontSize(13);
  doc.text(settings.schoolName, 105, startY + 9, { align: 'center' });

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`${settings.addressLine1}, ${settings.addressLine2}`, 105, startY + 13.5, { align: 'center' });
  doc.text(`${settings.affiliation} | Phone: ${settings.phone1}`, 105, startY + 17, { align: 'center' });

  // Receipt Title Bar
  doc.setFillColor(241, 245, 249);
  doc.rect(75, startY + 19, 60, 5, 'F');
  doc.setDrawColor(148, 163, 184);
  doc.setLineWidth(0.3);
  doc.rect(75, startY + 19, 60, 5, 'S');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  const title = type === 'van-only' ? 'VAN / TRANSPORT FEE RECEIPT' : 'OFFICIAL FEE RECEIPT';
  doc.text(title, 105, startY + 22.8, { align: 'center' });

  // Student Info Grid
  doc.setFontSize(8);
  const gridY = startY + 29;

  doc.setFont('helvetica', 'bold');
  doc.text('Receipt No:', 14, gridY);
  doc.setFont('helvetica', 'normal');
  doc.text(receiptNo, 33, gridY);

  doc.setFont('helvetica', 'bold');
  doc.text('Date:', 150, gridY);
  doc.setFont('helvetica', 'normal');
  doc.text(dateStr, 160, gridY);

  doc.setFont('helvetica', 'bold');
  doc.text('Student Name:', 14, gridY + 5);
  doc.setFont('helvetica', 'bold');
  doc.text(student.name.toUpperCase(), 35, gridY + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Adm / Roll No:', 140, gridY + 5);
  doc.setFont('helvetica', 'normal');
  doc.text(student.admissionNo, 162, gridY + 5);

  doc.setFont('helvetica', 'bold');
  doc.text('Class & Sec:', 14, gridY + 10);
  doc.setFont('helvetica', 'normal');
  doc.text(`${student.studentClass} - Section ${student.section}`, 33, gridY + 10);

  doc.setFont('helvetica', 'bold');
  doc.text('Academic Year:', 140, gridY + 10);
  doc.setFont('helvetica', 'normal');
  doc.text(student.academicYear, 164, gridY + 10);

  // Particulars rows
  let feeItems: { name: string; amount: number }[] = [];
  if (type === 'van-only') {
    feeItems = [
      { name: `Van / Transport Fee (${student.vanFees.route})`, amount: student.vanFees.paidAmount || student.vanFees.termFee },
      { name: `Pickup Point: ${student.vanFees.pickupPoint}`, amount: 0 },
    ];
  } else if (type === 'school-only') {
    const bk = student.schoolFees.feeBreakdown;
    if (bk.admissionFee > 0) feeItems.push({ name: 'Admission Fee', amount: bk.admissionFee });
    if (bk.tuitionFee > 0) feeItems.push({ name: `Tuition Fee (${student.schoolFees.term})`, amount: bk.tuitionFee });
    if (bk.examFee > 0) feeItems.push({ name: 'Examination & Term Fee', amount: bk.examFee });
    if (bk.booksStationeryFee > 0) feeItems.push({ name: 'Books, Notebooks & Stationery', amount: bk.booksStationeryFee });
    if (bk.uniformActivityFee > 0) feeItems.push({ name: 'Uniform & Extra Activities', amount: bk.uniformActivityFee });
  } else {
    // Both
    const bk = student.schoolFees.feeBreakdown;
    feeItems.push({ name: `Tuition & School Fee (${student.schoolFees.term})`, amount: student.schoolFees.paidAmount });
    if (student.vanFees.usesVan) {
      feeItems.push({ name: `Van Fee (${student.vanFees.route})`, amount: student.vanFees.paidAmount });
    }
  }

  const total = feeItems.reduce((acc, it) => acc + it.amount, 0);

  // Table
  const tableData = feeItems.map((item, idx) => [
    (idx + 1).toString(),
    item.name,
    item.amount > 0 ? `Rs. ${item.amount.toLocaleString('en-IN')}` : '-',
  ]);

  autoTable(doc, {
    startY: gridY + 13,
    margin: { left: 14, right: 14 },
    head: [['S.No', 'Particulars / Fee Description', 'Amount (Rs.)']],
    body: tableData,
    foot: [['', 'TOTAL AMOUNT RECEIVED:', `Rs. ${total.toLocaleString('en-IN')}`]],
    theme: 'grid',
    styles: {
      fontSize: 7.5,
      cellPadding: 1.5,
      textColor: [15, 23, 42],
    },
    headStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'center',
    },
    footStyles: {
      fillColor: [248, 250, 252],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      halign: 'right',
    },
    columnStyles: {
      0: { halign: 'center', cellWidth: 12 },
      1: { cellWidth: 126 },
      2: { halign: 'right', cellWidth: 44, fontStyle: 'bold' },
    },
  });

  const lastTableY = (doc as any).lastAutoTable.finalY + 3;

  // Words & Payment Note
  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'bold');
  doc.text('Amount in Words:', 14, lastTableY);
  doc.setFont('helvetica', 'normal');
  doc.text(numberToWordsIndian(total), 40, lastTableY);

  doc.setFont('helvetica', 'bold');
  doc.text(`Payment Mode: GPay / Cash`, 14, lastTableY + 4.5);
  doc.text(`GPay Phone: ${settings.gpayNumber}`, 80, lastTableY + 4.5);
  doc.text(`UPI VPA: ${settings.upiId}`, 130, lastTableY + 4.5);

  // Embed QR code thumbnail if available
  if (qrDataUrl) {
    try {
      doc.addImage(qrDataUrl, 'PNG', 170, lastTableY + 6, 20, 20);
      doc.setFontSize(6);
      doc.text('GPay Scan', 180, lastTableY + 28, { align: 'center' });
    } catch (e) {
      // Ignore image error if invalid
    }
  }

  // Signatures
  const signY = startY + boxHeight - 8;
  doc.setLineWidth(0.4);
  doc.setLineDashPattern([1, 1], 0);
  doc.line(16, signY, 56, signY);
  doc.line(80, signY, 125, signY);
  doc.line(145, signY, 192, signY);
  doc.setLineDashPattern([], 0);

  doc.setFontSize(7);
  doc.setFont('helvetica', 'normal');
  doc.text('Parent Signature', 36, signY + 3.5, { align: 'center' });
  doc.text(`Admin (${settings.adminName})`, 102.5, signY + 3.5, { align: 'center' });
  doc.text(`Principal (${settings.principalName})`, 168.5, signY + 3.5, { align: 'center' });
}

/**
 * 4. Single / Bulk Student Tuition Fee Passbook Card PDF
 */
export function generateTuitionFeeCardPdf(
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  drawTuitionCardOnPage(doc, student, settings, qrDataUrl);
  doc.save(`Tuition_Fee_Card_${student.name.replace(/\s+/g, '_')}_${student.admissionNo}.pdf`);
}

export function generateBulkTuitionCardsPdf(
  students: Student[],
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  students.forEach((student, index) => {
    if (index > 0) doc.addPage();
    drawTuitionCardOnPage(doc, student, settings, qrDataUrl);
  });

  doc.save(`Bulk_Tuition_Fee_Cards_${Date.now()}.pdf`);
}

function drawTuitionCardOnPage(
  doc: jsPDF,
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  // Border Card container
  doc.setDrawColor(30, 58, 138);
  doc.setLineWidth(1);
  doc.rect(10, 10, 190, 277);

  // Top header banner
  doc.setFillColor(30, 58, 138);
  doc.rect(10, 10, 190, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(settings.schoolName, 105, 18, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(`${settings.addressLine1}, ${settings.addressLine2}`, 105, 24, { align: 'center' });
  doc.text(`${settings.affiliation} • Phone: ${settings.phone1}`, 105, 29, { align: 'center' });

  // Title bar
  doc.setFillColor(241, 245, 249);
  doc.rect(10, 34, 190, 8, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.line(10, 42, 200, 42);

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`OFFICIAL STUDENT TUITION FEE CARD (${settings.currentAcademicYear})`, 105, 39.5, { align: 'center' });

  // Student Particulars Box
  doc.setFillColor(248, 250, 252);
  doc.rect(14, 46, 182, 34, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(14, 46, 182, 34, 'S');

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Student Name:', 18, 53);
  doc.setTextColor(15, 23, 42);
  doc.text(student.name.toUpperCase(), 45, 53);

  doc.setTextColor(71, 85, 105);
  doc.text('Admission / Roll No:', 120, 53);
  doc.setTextColor(15, 23, 42);
  doc.text(student.admissionNo, 160, 53);

  doc.setTextColor(71, 85, 105);
  doc.text('Standard & Section:', 18, 60);
  doc.setTextColor(15, 23, 42);
  doc.text(`${student.studentClass} - Section ${student.section}`, 52, 60);

  doc.setTextColor(71, 85, 105);
  doc.text('Father / Guardian:', 120, 60);
  doc.setTextColor(15, 23, 42);
  doc.text(student.fatherName || 'Parent', 160, 60);

  doc.setTextColor(71, 85, 105);
  doc.text('Parent Mobile No:', 18, 67);
  doc.setTextColor(15, 23, 42);
  doc.text(student.parentPhone, 50, 67);

  doc.setTextColor(71, 85, 105);
  doc.text('Residential Address:', 18, 74);
  doc.setTextColor(15, 23, 42);
  doc.text(student.address || 'Essur Village', 52, 74);

  // Fee Particulars Table
  const bk = student.schoolFees.feeBreakdown;
  const schoolFee = student.schoolFees.totalFee;
  const schoolPaid = student.schoolFees.paidAmount;
  const schoolDue = Math.max(0, schoolFee - schoolPaid);

  autoTable(doc, {
    startY: 84,
    margin: { left: 14, right: 14 },
    head: [['Fee Particulars', 'Amount (Rs.)', 'Due Term', 'Current Status']],
    body: [
      ['Admission & Registration Fee', `Rs. ${bk.admissionFee.toLocaleString('en-IN')}`, 'One-Time', bk.admissionFee > 0 ? 'Billed' : 'N/A'],
      ['Tuition & Educational Fee', `Rs. ${bk.tuitionFee.toLocaleString('en-IN')}`, student.schoolFees.term, 'Active'],
      ['Term & Periodic Exam Fee', `Rs. ${bk.examFee.toLocaleString('en-IN')}`, 'Term-wise', bk.examFee > 0 ? 'Billed' : '-'],
      ['Books, Notebooks & Stationery', `Rs. ${bk.booksStationeryFee.toLocaleString('en-IN')}`, 'Annual', bk.booksStationeryFee > 0 ? 'Billed' : '-'],
      ['Uniform & Extra Activities', `Rs. ${bk.uniformActivityFee.toLocaleString('en-IN')}`, 'Annual', bk.uniformActivityFee > 0 ? 'Billed' : '-'],
    ],
    foot: [['TOTAL ANNUAL SCHOOL FEES:', `Rs. ${schoolFee.toLocaleString('en-IN')}`, 'Amount Paid:', `Rs. ${schoolPaid.toLocaleString('en-IN')}`]],
    styles: { fontSize: 8, cellPadding: 2 },
    headStyles: { fillColor: [30, 58, 138], textColor: [255, 255, 255], fontStyle: 'bold' },
    footStyles: { fillColor: [241, 245, 249], textColor: [15, 23, 42], fontStyle: 'bold' },
  });

  // Installment Stamping Table (The Passbook Grid)
  const currentY = (doc as any).lastAutoTable.finalY + 6;

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('OFFICIAL PAYMENT INSTALLMENTS & CASHIER VERIFICATION RECORD', 14, currentY);

  autoTable(doc, {
    startY: currentY + 3,
    margin: { left: 14, right: 14 },
    head: [['Installment', 'Scheduled Month', 'Amount (Rs.)', 'Amount Paid', 'Receipt No & Date', 'Balance', 'Cashier Stamp']],
    body: [
      ['Term I (1st Installment)', 'June - July', `Rs. ${Math.round(schoolFee * 0.4).toLocaleString('en-IN')}`, student.schoolFees.paidAmount > 0 ? `Rs. ${Math.min(student.schoolFees.paidAmount, Math.round(schoolFee * 0.4)).toLocaleString('en-IN')}` : 'Rs. 0', student.schoolFees.lastPaymentDate || 'Pending', student.schoolFees.paidAmount >= Math.round(schoolFee * 0.4) ? 'NIL' : `Rs. ${Math.max(0, Math.round(schoolFee * 0.4) - student.schoolFees.paidAmount).toLocaleString('en-IN')}`, student.schoolFees.paidAmount > 0 ? 'PAID / SEALED' : ''],
      ['Term II (2nd Installment)', 'October - November', `Rs. ${Math.round(schoolFee * 0.35).toLocaleString('en-IN')}`, student.schoolFees.paidAmount > Math.round(schoolFee * 0.4) ? `Rs. ${Math.min(student.schoolFees.paidAmount - Math.round(schoolFee * 0.4), Math.round(schoolFee * 0.35)).toLocaleString('en-IN')}` : 'Rs. 0', 'Pending', 'Rs. ' + Math.max(0, schoolFee - student.schoolFees.paidAmount).toLocaleString('en-IN'), ''],
      ['Term III (3rd Installment)', 'January - February', `Rs. ${Math.round(schoolFee * 0.25).toLocaleString('en-IN')}`, student.schoolFees.status === 'Paid' ? `Rs. ${Math.round(schoolFee * 0.25).toLocaleString('en-IN')}` : 'Rs. 0', 'Pending', schoolDue > 0 ? `Rs. ${schoolDue.toLocaleString('en-IN')}` : 'NIL', ''],
    ],
    styles: { fontSize: 8, cellPadding: 2.5 },
    headStyles: { fillColor: [51, 65, 85], textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 42 },
      1: { halign: 'center', cellWidth: 26 },
      2: { halign: 'right', cellWidth: 24 },
      3: { halign: 'right', cellWidth: 24, textColor: [22, 101, 52] },
      4: { halign: 'center', cellWidth: 26 },
      5: { halign: 'right', cellWidth: 20, fontStyle: 'bold', textColor: [185, 28, 28] },
      6: { halign: 'center', cellWidth: 20 },
    },
  });

  // Payment Instructions & GPay QR Box
  const bottomY = (doc as any).lastAutoTable.finalY + 6;

  doc.setFillColor(240, 253, 244); // light green
  doc.rect(14, bottomY, 182, 38, 'F');
  doc.setDrawColor(34, 197, 94);
  doc.rect(14, bottomY, 182, 38, 'S');

  doc.setTextColor(22, 101, 52);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('OFFICIAL GOOGLE PAY & UPI ONLINE PAYMENT MODE', 18, bottomY + 6);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`• GPay / PhonePe Mobile Number: ${settings.gpayNumber}`, 18, bottomY + 12);
  doc.text(`• Official UPI VPA ID: ${settings.upiId}`, 18, bottomY + 17);
  doc.text(`• Account Payee: ${settings.adminName} (${settings.adminRole})`, 18, bottomY + 22);
  doc.text('• Please send payment screenshot with student roll number to school office.', 18, bottomY + 27);
  doc.text(`• Total Balance Pending: Rs. ${schoolDue.toLocaleString('en-IN')}`, 18, bottomY + 33);

  if (qrDataUrl) {
    try {
      doc.addImage(qrDataUrl, 'PNG', 160, bottomY + 3, 30, 30);
      doc.setFontSize(6);
      doc.text('Scan GPay to Pay', 175, bottomY + 35, { align: 'center' });
    } catch (e) {}
  }

  // Signatures at bottom
  const signY = 272;
  doc.setLineWidth(0.4);
  doc.setLineDashPattern([1, 1], 0);
  doc.line(18, signY, 58, signY);
  doc.line(80, signY, 125, signY);
  doc.line(145, signY, 190, signY);
  doc.setLineDashPattern([], 0);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Parent / Guardian Sign', 38, signY + 3.5, { align: 'center' });
  doc.text(`Admin (${settings.adminName})`, 102.5, signY + 3.5, { align: 'center' });
  doc.text(`Principal (${settings.principalName})`, 167.5, signY + 3.5, { align: 'center' });
}

/**
 * 5. Single / Bulk Student Van Fee Pass Card PDF
 */
export function generateVanFeeCardPdf(
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  drawVanCardOnPage(doc, student, settings, qrDataUrl);
  doc.save(`Van_Fee_Pass_Card_${student.name.replace(/\s+/g, '_')}_${student.admissionNo}.pdf`);
}

export function generateBulkVanCardsPdf(
  students: Student[],
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const vanStudents = students.filter(s => s.vanFees.usesVan);
  if (vanStudents.length === 0) {
    alert('No van riding students found.');
    return;
  }

  vanStudents.forEach((student, index) => {
    if (index > 0) doc.addPage();
    drawVanCardOnPage(doc, student, settings, qrDataUrl);
  });

  doc.save(`Bulk_Van_Transport_Pass_Cards_${Date.now()}.pdf`);
}

function drawVanCardOnPage(
  doc: jsPDF,
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const v = student.vanFees;
  const vanFee = v.termFee;
  const vanPaid = v.paidAmount;
  const vanDue = Math.max(0, vanFee - vanPaid);

  // Outer border
  doc.setDrawColor(217, 119, 6); // amber-600
  doc.setLineWidth(1);
  doc.rect(10, 10, 190, 277);

  // Top header banner
  doc.setFillColor(217, 119, 6); // Amber
  doc.rect(10, 10, 190, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(15);
  doc.text(settings.schoolName, 105, 18, { align: 'center' });

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(`${settings.addressLine1}, ${settings.addressLine2}`, 105, 24, { align: 'center' });
  doc.text(`SCHOOL BUS & TRANSPORT PASS CARD - ACADEMIC YEAR ${settings.currentAcademicYear}`, 105, 29, { align: 'center' });

  // Title bar
  doc.setFillColor(254, 243, 199);
  doc.rect(10, 34, 190, 8, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.line(10, 42, 200, 42);

  doc.setTextColor(146, 64, 14);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(`OFFICIAL STUDENT VAN / TRANSPORT PASSBOOK CARD`, 105, 39.5, { align: 'center' });

  // Transport Details Card
  doc.setFillColor(255, 251, 235);
  doc.rect(14, 46, 182, 38, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.rect(14, 46, 182, 38, 'S');

  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(120, 53, 15);
  doc.text('Student Name:', 18, 53);
  doc.setTextColor(15, 23, 42);
  doc.text(student.name.toUpperCase(), 45, 53);

  doc.setTextColor(120, 53, 15);
  doc.text('Admission No:', 120, 53);
  doc.setTextColor(15, 23, 42);
  doc.text(student.admissionNo, 155, 53);

  doc.setTextColor(120, 53, 15);
  doc.text('Standard & Section:', 18, 60);
  doc.setTextColor(15, 23, 42);
  doc.text(`${student.studentClass} - Section ${student.section}`, 52, 60);

  doc.setTextColor(120, 53, 15);
  doc.text('Parent Mobile:', 120, 60);
  doc.setTextColor(15, 23, 42);
  doc.text(student.parentPhone, 155, 60);

  doc.setTextColor(120, 53, 15);
  doc.text('Assigned Van Route:', 18, 67);
  doc.setTextColor(15, 23, 42);
  doc.text(v.route || 'Route 1: Essur', 55, 67);

  doc.setTextColor(120, 53, 15);
  doc.text('Boarding / Drop Point:', 18, 74);
  doc.setTextColor(15, 23, 42);
  doc.text(v.pickupPoint || 'Main Bus Stop', 55, 74);

  doc.setTextColor(120, 53, 15);
  doc.text('Driver / Incharge Check:', 120, 74);
  doc.setTextColor(22, 101, 52);
  doc.text('AUTHORIZED RIDER', 155, 74);

  // Van Fee Schedule Table
  autoTable(doc, {
    startY: 88,
    margin: { left: 14, right: 14 },
    head: [['Term / Month Period', 'Scheduled Van Fee', 'Paid Amount', 'Receipt Date', 'Due Balance', 'Transport Seal']],
    body: [
      ['Term I (June to September)', `Rs. ${Math.round(vanFee * 0.4).toLocaleString('en-IN')}`, v.paidAmount > 0 ? `Rs. ${Math.min(v.paidAmount, Math.round(vanFee * 0.4)).toLocaleString('en-IN')}` : 'Rs. 0', v.lastPaymentDate || 'Pending', v.paidAmount >= Math.round(vanFee * 0.4) ? 'NIL' : `Rs. ${Math.max(0, Math.round(vanFee * 0.4) - v.paidAmount).toLocaleString('en-IN')}`, v.paidAmount > 0 ? 'CLEARED' : ''],
      ['Term II (October to December)', `Rs. ${Math.round(vanFee * 0.35).toLocaleString('en-IN')}`, v.paidAmount > Math.round(vanFee * 0.4) ? `Rs. ${Math.min(v.paidAmount - Math.round(vanFee * 0.4), Math.round(vanFee * 0.35)).toLocaleString('en-IN')}` : 'Rs. 0', 'Pending', `Rs. ${Math.max(0, vanFee - v.paidAmount).toLocaleString('en-IN')}`, ''],
      ['Term III (January to April)', `Rs. ${Math.round(vanFee * 0.25).toLocaleString('en-IN')}`, v.vanStatus === 'Paid' ? `Rs. ${Math.round(vanFee * 0.25).toLocaleString('en-IN')}` : 'Rs. 0', 'Pending', vanDue > 0 ? `Rs. ${vanDue.toLocaleString('en-IN')}` : 'NIL', ''],
    ],
    foot: [['TOTAL VAN FEES:', `Rs. ${vanFee.toLocaleString('en-IN')}`, `Rs. ${vanPaid.toLocaleString('en-IN')}`, '', `Rs. ${vanDue.toLocaleString('en-IN')}`, v.vanStatus.toUpperCase()]],
    styles: { fontSize: 8, cellPadding: 2.5 },
    headStyles: { fillColor: [180, 83, 9], textColor: [255, 255, 255], fontStyle: 'bold', halign: 'center' },
    footStyles: { fillColor: [254, 243, 199], textColor: [120, 53, 15], fontStyle: 'bold' },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 50 },
      1: { halign: 'right', cellWidth: 30 },
      2: { halign: 'right', cellWidth: 30, textColor: [22, 101, 52] },
      3: { halign: 'center', cellWidth: 26 },
      4: { halign: 'right', cellWidth: 24, fontStyle: 'bold', textColor: [185, 28, 28] },
      5: { halign: 'center', cellWidth: 22 },
    },
  });

  // Transport Guidelines Box
  const guideY = (doc as any).lastAutoTable.finalY + 6;

  doc.setFillColor(248, 250, 252);
  doc.rect(14, guideY, 182, 40, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(14, guideY, 182, 40, 'S');

  doc.setTextColor(30, 58, 138);
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.text('SCHOOL TRANSPORT INSTRUCTIONS & SAFETY GUIDELINES FOR PARENTS', 18, guideY + 6);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('1. Students must arrive at their designated boarding point 5 minutes before scheduled van arrival.', 18, guideY + 12);
  doc.text('2. This pass card must be carried daily and presented to the van incharge/driver upon request.', 18, guideY + 17);
  doc.text('3. Van fees must be cleared by the 10th of every scheduled term to maintain uninterrupted pickup.', 18, guideY + 22);
  doc.text('4. Parents must notify the school office in advance if a student will not be using the van on any day.', 18, guideY + 27);
  doc.text(`5. Transport Emergency Helpline: ${settings.phone1} / ${settings.phone2}`, 18, guideY + 32);

  // GPay QR Box for Van fee
  const qrBoxY = guideY + 45;
  doc.setFillColor(254, 243, 199);
  doc.rect(14, qrBoxY, 182, 34, 'F');
  doc.setDrawColor(245, 158, 11);
  doc.rect(14, qrBoxY, 182, 34, 'S');

  doc.setTextColor(146, 64, 14);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text('GPAY ONLINE VAN FEE PAYMENT DETAILS', 18, qrBoxY + 6);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(`• GPay Phone: ${settings.gpayNumber} (${settings.adminName})`, 18, qrBoxY + 12);
  doc.text(`• GPay UPI ID: ${settings.upiId}`, 18, qrBoxY + 17);
  doc.text(`• Current Van Fee Balance Due: Rs. ${vanDue.toLocaleString('en-IN')}`, 18, qrBoxY + 22);
  doc.text('• Send screenshot on WhatsApp to activate van pass clearance.', 18, qrBoxY + 27);

  if (qrDataUrl) {
    try {
      doc.addImage(qrDataUrl, 'PNG', 160, qrBoxY + 2, 30, 30);
      doc.setFontSize(6);
      doc.text('GPay Scan', 175, qrBoxY + 32, { align: 'center' });
    } catch (e) {}
  }

  // Signatures
  const signY = 272;
  doc.setLineWidth(0.4);
  doc.setLineDashPattern([1, 1], 0);
  doc.line(18, signY, 58, signY);
  doc.line(80, signY, 125, signY);
  doc.line(145, signY, 190, signY);
  doc.setLineDashPattern([], 0);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text('Parent Signature', 38, signY + 3.5, { align: 'center' });
  doc.text(`Transport Incharge`, 102.5, signY + 3.5, { align: 'center' });
  doc.text(`Principal (${settings.principalName})`, 167.5, signY + 3.5, { align: 'center' });
}

/**
 * 6. Student ID Cards PDF (Printable Badges)
 */
export function generateStudentIdCardPdf(
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  drawSingleIdCardBadge(doc, 20, 30, student, settings, qrDataUrl);
  doc.save(`Student_ID_Card_${student.name.replace(/\s+/g, '_')}_${student.admissionNo}.pdf`);
}

export function generateBulkIdCardsPdf(
  students: Student[],
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  // Print up to 4 or 6 ID cards per A4 page in a 2x3 grid
  const cardsPerPage = 4;
  students.forEach((student, index) => {
    const pageIndex = Math.floor(index / cardsPerPage);
    const cardSlot = index % cardsPerPage;

    if (index > 0 && cardSlot === 0) {
      doc.addPage();
    }

    const col = cardSlot % 2;
    const row = Math.floor(cardSlot / 2);

    const startX = 15 + col * 92;
    const startY = 15 + row * 130;

    drawSingleIdCardBadge(doc, startX, startY, student, settings, qrDataUrl);
  });

  doc.save(`Bulk_Student_ID_Cards_${Date.now()}.pdf`);
}

function drawSingleIdCardBadge(
  doc: jsPDF,
  x: number,
  y: number,
  student: Student,
  settings: SchoolSettings,
  qrDataUrl?: string
): void {
  const w = 86;
  const h = 120;

  // Outer border & shadow effect
  doc.setDrawColor(30, 58, 138);
  doc.setLineWidth(0.8);
  doc.rect(x, y, w, h);

  // Top header block
  doc.setFillColor(30, 58, 138);
  doc.rect(x, y, w, 20, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.text(settings.schoolName, x + w / 2, y + 6, { align: 'center' });

  doc.setFontSize(6);
  doc.setFont('helvetica', 'normal');
  doc.text(`${settings.addressLine1}, Essur`, x + w / 2, y + 10, { align: 'center' });
  doc.text(`STUDENT IDENTITY CARD • ${settings.currentAcademicYear}`, x + w / 2, y + 14, { align: 'center' });

  // Photo Box or Avatar
  const photoY = y + 23;
  const photoW = 24;
  const photoH = 28;
  const photoX = x + (w - photoW) / 2;

  doc.setFillColor(241, 245, 249);
  doc.rect(photoX, photoY, photoW, photoH, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.rect(photoX, photoY, photoW, photoH, 'S');

  // Photo outline or placeholder text
  doc.setFontSize(6);
  doc.setTextColor(148, 163, 184);
  doc.text('PHOTO', photoX + photoW / 2, photoY + photoH / 2, { align: 'center' });

  // Student Name
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.text(student.name.toUpperCase(), x + w / 2, photoY + photoH + 5, { align: 'center' });

  // Class & Admission No
  doc.setFontSize(7.5);
  doc.setTextColor(30, 58, 138);
  doc.text(`${student.studentClass} - Section ${student.section}`, x + w / 2, photoY + photoH + 9, { align: 'center' });

  doc.setFontSize(7);
  doc.setTextColor(71, 85, 105);
  const detailY = photoY + photoH + 15;

  doc.setFont('helvetica', 'bold');
  doc.text('Adm / Roll No:', x + 6, detailY);
  doc.setFont('helvetica', 'normal');
  doc.text(student.admissionNo, x + 30, detailY);

  doc.setFont('helvetica', 'bold');
  doc.text('Father Name:', x + 6, detailY + 4.5);
  doc.setFont('helvetica', 'normal');
  doc.text(student.fatherName || 'Parent', x + 30, detailY + 4.5);

  doc.setFont('helvetica', 'bold');
  doc.text('Contact No:', x + 6, detailY + 9);
  doc.setFont('helvetica', 'normal');
  doc.text(student.parentPhone, x + 30, detailY + 9);

  doc.setFont('helvetica', 'bold');
  doc.text('Blood Group:', x + 6, detailY + 13.5);
  doc.setFont('helvetica', 'normal');
  doc.text(student.bloodGroup || 'B+ Positive', x + 30, detailY + 13.5);

  doc.setFont('helvetica', 'bold');
  doc.text('Van Route:', x + 6, detailY + 18);
  doc.setFont('helvetica', 'normal');
  doc.text(student.vanFees.usesVan ? student.vanFees.pickupPoint : 'Walking', x + 30, detailY + 18);

  // Bottom Footer with Principal Sign & Mini QR
  const footY = y + h - 14;
  doc.setDrawColor(203, 213, 225);
  doc.line(x + 4, footY, x + w - 4, footY);

  if (qrDataUrl) {
    try {
      doc.addImage(qrDataUrl, 'PNG', x + 6, footY + 1.5, 10, 10);
    } catch (e) {}
  }

  doc.setFontSize(6);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Phone: ${settings.phone1}`, x + 20, footY + 5);
  doc.text('Emergency: Call School Office', x + 20, footY + 9);

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`Principal: ${settings.principalName}`, x + w - 6, footY + 5, { align: 'right' });
  doc.text('Authorized Signatory', x + w - 6, footY + 9, { align: 'right' });
}
