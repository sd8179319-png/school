import { SchoolSettings, Student } from '../types';

export interface WhatsAppMessage {
  studentId: string;
  studentName: string;
  parentName: string;
  phone: string;
  cleanPhone: string;
  messageText: string;
  waUrl: string;
}

export function formatIndianPhone(phone: string): string {
  const digits = (phone || '').replace(/\D/g, '');
  if (digits.length === 10) {
    return `91${digits}`;
  }
  if (digits.length === 12 && digits.startsWith('91')) {
    return digits;
  }
  return digits;
}

export function generateFeeDueMessage(
  student: Student,
  settings: SchoolSettings,
  language: 'en' | 'ta' = 'en'
): string {
  const schoolDue = student.schoolFees.totalFee - student.schoolFees.paidAmount;
  const vanDue = student.vanFees.usesVan
    ? student.vanFees.termFee - student.vanFees.paidAmount
    : 0;
  const totalDue = schoolDue + vanDue;

  if (language === 'ta') {
    return (
`வணக்கம் ${student.fatherName || 'பெற்றோர்'},
${settings.schoolName} நிர்வாகம் சார்பாக அன்பான நினைவூட்டல்.

மாணவர் பெயர்: ${student.name}
வகுப்பு: ${student.studentClass} - பிரிவு ${student.section}
சேர்க்கை எண்: ${student.admissionNo}

கட்டண நிலுவை விவரம்:
• பள்ளி கல்வி கட்டணம்: ₹${schoolDue.toLocaleString('en-IN')}
${student.vanFees.usesVan ? `• பள்ளி வேன் கட்டணம்: ₹${vanDue.toLocaleString('en-IN')} (${student.vanFees.route})` : ''}
----------------------------------------
மொத்த நிலுவை தொகை: ₹${totalDue.toLocaleString('en-IN')}
----------------------------------------

கட்டணத்தை உடனடியாக கூகிள் பே (Google Pay / GPay) மூலம் செலுத்தலாம்:
📱 GPay எண்: ${settings.gpayNumber}
👤 பயனாளி: ${settings.adminName} (${settings.adminRole})
🔗 UPI ID: ${settings.upiId}

பணம் செலுத்தியதும் ரசீதை இந்த எண்ணிற்கு வாட்ஸ்அப் செய்யவும்.
தொடர்புக்கு: ${settings.phone1} / ${settings.phone2}

நன்றி,
நிர்வாகி: ${settings.adminName}
முதல்வர்: ${settings.principalName}
${settings.schoolName}, எசூர்`
    );
  }

  // English Template
  return (
`Dear ${student.fatherName || 'Parent'},
Warm greetings from ${settings.schoolName}.

Student Name: ${student.name}
Class: ${student.studentClass} - Section ${student.section}
Adm / Roll No: ${student.admissionNo}

FEE PAYMENT DETAILS:
• School Tuition & Term Fee Due: ₹${schoolDue.toLocaleString('en-IN')}
${student.vanFees.usesVan ? `• Van / Transport Fee Due: ₹${vanDue.toLocaleString('en-IN')} (${student.vanFees.route})` : ''}
----------------------------------------
TOTAL OUTSTANDING DUE: ₹${totalDue.toLocaleString('en-IN')}
----------------------------------------

PAYMENT INSTRUCTIONS (GPAY / UPI):
You can conveniently pay via Google Pay (GPay) / PhonePe / Paytm:
📱 GPay Mobile: ${settings.gpayNumber}
👤 Name: ${settings.adminName} (Wisdom School)
💳 UPI ID: ${settings.upiId}

After payment, please reply with transaction screenshot to receive official receipt slip.

For queries, contact: ${settings.phone1}
Admin: ${settings.adminName} | Principal: ${settings.principalName}
${settings.schoolName}, Essur`
  );
}

export function generatePaymentReceiptMessage(
  student: Student,
  receiptNo: string,
  amountPaid: number,
  feeType: string,
  settings: SchoolSettings
): string {
  const schoolBalance = student.schoolFees.totalFee - student.schoolFees.paidAmount;
  const vanBalance = student.vanFees.usesVan ? student.vanFees.termFee - student.vanFees.paidAmount : 0;

  return (
`Official Fee Receipt - ${settings.schoolName}

Dear ${student.fatherName || 'Parent'},
We have received payment for ${student.name} (${student.studentClass} - ${student.section}, Roll No: ${student.admissionNo}).

Receipt No: ${receiptNo}
Date: ${new Date().toLocaleDateString('en-IN')}
Fee Category: ${feeType}
Amount Received: ₹${amountPaid.toLocaleString('en-IN')}
School Fee Balance: ₹${schoolBalance.toLocaleString('en-IN')}
${student.vanFees.usesVan ? `Van Fee Balance: ₹${vanBalance.toLocaleString('en-IN')}` : ''}

Paid to GPay / Cash: ${settings.gpayNumber} (${settings.adminName})
Thank you for your timely payment!

With regards,
Principal: ${settings.principalName}
Admin: ${settings.adminName}
${settings.schoolName}, Essur`
  );
}

export function generateVanNoticeMessage(
  student: Student,
  settings: SchoolSettings
): string {
  const vanDue = student.vanFees.termFee - student.vanFees.paidAmount;

  return (
`VAN / TRANSPORT FEE NOTICE - ${settings.schoolName}

Dear ${student.fatherName || 'Parent'},
This is regarding school transport service for:
Student: ${student.name} (${student.studentClass})
Van Route: ${student.vanFees.route}
Pickup Point: ${student.vanFees.pickupPoint}

Van Fee Term Amount: ₹${student.vanFees.termFee.toLocaleString('en-IN')}
Amount Paid: ₹${student.vanFees.paidAmount.toLocaleString('en-IN')}
Balance Due: ₹${vanDue.toLocaleString('en-IN')}

Please pay the van fee balance via GPay to ensure uninterrupted transport:
📱 GPay Number: ${settings.gpayNumber} (${settings.adminName})
UPI ID: ${settings.upiId}

Thank you,
Transport Desk & Admin: ${settings.adminName}
Principal: ${settings.principalName}
${settings.schoolName}`
  );
}
