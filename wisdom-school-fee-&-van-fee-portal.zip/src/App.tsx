/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { ReceiptGenerator } from './components/ReceiptGenerator';
import { StudentDirectory } from './components/StudentDirectory';
import { BulkPdfCenter } from './components/BulkPdfCenter';
import { WhatsAppMessenger } from './components/WhatsAppMessenger';
import { VanFeeManager } from './components/VanFeeManager';
import { GpayModal } from './components/GpayModal';
import { SettingsModal } from './components/SettingsModal';

import { Student, SchoolSettings, FeeReceipt } from './types';
import { DEFAULT_SETTINGS, INITIAL_STUDENTS } from './utils/sampleData';
import { PendingDuesSummary } from './components/PendingDuesSummary';
import { EditFeeModal } from './components/EditFeeModal';
import { IdCardGenerator } from './components/IdCardGenerator';
import { FeeCardsManager } from './components/FeeCardsManager';
import { loadAppData, loadLegacyAppData, saveAppData } from './utils/localDatabase';

export default function App() {
  // Application State
  const [currentTab, setCurrentTab] = useState<string>('receipt');
  const [settings, setSettings] = useState<SchoolSettings>(DEFAULT_SETTINGS);
  const [students, setStudents] = useState<Student[]>(INITIAL_STUDENTS);
  const [recentReceipts, setRecentReceipts] = useState<FeeReceipt[]>([]);
  const [storageReady, setStorageReady] = useState(false);
  const [storageEnabled, setStorageEnabled] = useState(true);
  const [storageError, setStorageError] = useState('');

  // Selection state for receipt generator
  const [selectedStudentForReceipt, setSelectedStudentForReceipt] = useState<Student | null>(null);

  // Fee Editing Modal State
  const [editingFeeStudent, setEditingFeeStudent] = useState<Student | null>(null);
  const [isEditFeeModalOpen, setIsEditFeeModalOpen] = useState<boolean>(false);

  // Modals
  const [isGpayModalOpen, setIsGpayModalOpen] = useState<boolean>(false);
  const [gpayModalAmount, setGpayModalAmount] = useState<number>(0);
  const [gpayModalStudentName, setGpayModalStudentName] = useState<string>('');
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    let active = true;
    const defaults: { settings: SchoolSettings; students: Student[]; receipts: FeeReceipt[] } = {
      settings: DEFAULT_SETTINGS,
      students: INITIAL_STUDENTS,
      receipts: [],
    };

    const applyData = (data: typeof defaults) => {
      const loadedSettings = { ...data.settings };
      if (!loadedSettings.upiId || loadedSettings.upiId.includes('okaxis')) {
        loadedSettings.upiId = 'rsaravanan102002-1@okhdfcbank';
      }
      setSettings(loadedSettings);
      setStudents(data.students);
      setRecentReceipts(data.receipts);
    };

    loadAppData(defaults)
      .then(data => {
        if (!active) return;
        applyData(data);
        setStorageReady(true);
      })
      .catch(error => {
        console.error('Could not load data from IndexedDB:', error);
        if (!active) return;

        try {
          applyData(loadLegacyAppData(defaults));
        } catch (legacyError) {
          console.error('Could not load data from localStorage:', legacyError);
          applyData(defaults);
        }

        setStorageEnabled(false);
        setStorageError('Your data could not be loaded from browser storage. Changes will not be saved.');
        setStorageReady(true);
      });

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!storageReady || !storageEnabled) return;

    saveAppData({ settings, students, receipts: recentReceipts })
      .then(() => setStorageError(''))
      .catch(error => {
        console.error('Could not save data to IndexedDB:', error);
        setStorageError('Your latest changes could not be saved. Check available browser storage and try again.');
      });
  }, [settings, students, recentReceipts, storageReady, storageEnabled]);

  // Student CRUD
  const handleAddStudent = (newStudent: Student) => {
    setStudents(prev => [newStudent, ...prev]);
  };

  const handleUpdateStudent = (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.id === updatedStudent.id ? updatedStudent : s));
  };

  const handleDeleteStudent = (id: string) => {
    setStudents(prev => prev.filter(s => s.id !== id));
  };

  const handleDeleteMultipleStudents = (ids: string[]) => {
    setStudents(prev => prev.filter(s => !ids.includes(s.id)));
  };

  const handleDeleteAllStudents = () => {
    setStudents([]);
  };

  const handleRestoreSampleStudents = () => {
    setStudents(INITIAL_STUDENTS);
  };

  // Receipt handling
  const handleSaveReceipt = (receipt: FeeReceipt) => {
    setRecentReceipts(prev => [receipt, ...prev]);

    // If receipt belongs to existing student, update student balance
    if (receipt.studentId && receipt.studentId !== 'manual') {
      setStudents(prev => prev.map(s => {
        if (s.id !== receipt.studentId) return s;

        // Check if items contain van fee
        const vanPaidItem = receipt.items.find(i => i.description.toLowerCase().includes('van') || i.description.toLowerCase().includes('transport'));
        const vanPayment = vanPaidItem ? vanPaidItem.amount : 0;
        const schoolPayment = receipt.totalAmount - vanPayment;

        const newSchoolPaid = Math.min(s.schoolFees.totalFee, s.schoolFees.paidAmount + schoolPayment);
        const newVanPaid = s.vanFees.usesVan ? Math.min(s.vanFees.termFee, s.vanFees.paidAmount + vanPayment) : 0;

        return {
          ...s,
          schoolFees: {
            ...s.schoolFees,
            paidAmount: newSchoolPaid,
            status: newSchoolPaid >= s.schoolFees.totalFee ? 'Paid' : 'Partial',
            lastPaymentDate: receipt.date,
          },
          vanFees: {
            ...s.vanFees,
            paidAmount: newVanPaid,
            vanStatus: newVanPaid >= s.vanFees.termFee ? 'Paid' : 'Partial',
            lastPaymentDate: receipt.date,
          },
        };
      }));
    }
  };

  // Count of students with unpaid school or van dues
  const pendingDuesCount = students.filter(s => {
    const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
    const vanDue = s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0;
    return schoolDue > 0 || vanDue > 0;
  }).length;

  // Navigation shortcut: Select student for receipt
  const handleSelectForReceipt = (student: Student) => {
    setSelectedStudentForReceipt(student);
    setCurrentTab('receipt');
  };

  const handleOpenEditFees = (student: Student) => {
    setEditingFeeStudent(student);
    setIsEditFeeModalOpen(true);
  };

  const handleOpenGpayModal = (amount = 0, name = '') => {
    setGpayModalAmount(amount);
    setGpayModalStudentName(name);
    setIsGpayModalOpen(true);
  };

  const handleResetAllData = async () => {
    if (!confirm('Are you sure you want to restore default sample students and reset history?')) return;

    setStudents(INITIAL_STUDENTS);
    setSettings(DEFAULT_SETTINGS);
    setRecentReceipts([]);

    try {
      ['wisdom_settings_v1', 'wisdom_students_v1', 'wisdom_receipts_v1']
        .forEach(key => localStorage.removeItem(key));
    } catch (error) {
      console.error('Could not remove old browser data:', error);
    }

    try {
      await saveAppData({ settings: DEFAULT_SETTINGS, students: INITIAL_STUDENTS, receipts: [] });
      setStorageEnabled(true);
      setStorageError('');
      alert('Data reset to defaults.');
    } catch (error) {
      console.error('Could not save reset data to IndexedDB:', error);
      setStorageError('Data was reset for this session, but could not be saved to browser storage.');
    }
  };

  if (!storageReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 text-slate-600">
        Loading saved data...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {storageError && (
        <div role="alert" className="no-print bg-rose-100 px-4 py-2 text-center text-sm text-rose-800">
          {storageError}
        </div>
      )}
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        settings={settings}
        onOpenGpayModal={() => handleOpenGpayModal()}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onQuickPrint={() => window.print()}
        pendingDuesCount={pendingDuesCount}
      />

      {/* Main Content Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-6">
        
        {/* Main Dashboard Pending Dues Summary Card on Receipt screen & Dues Tab */}
        {(currentTab === 'receipt' || currentTab === 'dues') && (
          <PendingDuesSummary
            students={students}
            settings={settings}
            onSelectForReceipt={handleSelectForReceipt}
            onOpenGpayModal={handleOpenGpayModal}
            onEditFees={handleOpenEditFees}
            onNavigateToWhatsApp={() => setCurrentTab('whatsapp')}
          />
        )}

        {currentTab === 'receipt' && (
          <ReceiptGenerator
            students={students}
            settings={settings}
            onSaveReceipt={handleSaveReceipt}
            recentReceipts={recentReceipts}
            onOpenGpayModal={handleOpenGpayModal}
            selectedStudent={selectedStudentForReceipt}
            onEditFees={handleOpenEditFees}
          />
        )}

        {currentTab === 'fee-cards' && (
          <FeeCardsManager
            students={students}
            settings={settings}
            onOpenGpayModal={handleOpenGpayModal}
          />
        )}

        {currentTab === 'id-cards' && (
          <IdCardGenerator
            students={students}
            settings={settings}
            onUpdateStudent={handleUpdateStudent}
          />
        )}

        {currentTab === 'students' && (
          <StudentDirectory
            students={students}
            onAddStudent={handleAddStudent}
            onUpdateStudent={handleUpdateStudent}
            onDeleteStudent={handleDeleteStudent}
            onDeleteMultipleStudents={handleDeleteMultipleStudents}
            onDeleteAllStudents={handleDeleteAllStudents}
            onRestoreSampleStudents={handleRestoreSampleStudents}
            onSelectForReceipt={handleSelectForReceipt}
            settings={settings}
            onOpenGpayModal={handleOpenGpayModal}
            onEditFees={handleOpenEditFees}
          />
        )}

        {currentTab === 'bulk-pdf' && (
          <BulkPdfCenter
            students={students}
            settings={settings}
            onOpenGpayModal={() => handleOpenGpayModal()}
          />
        )}

        {currentTab === 'whatsapp' && (
          <WhatsAppMessenger
            students={students}
            settings={settings}
            onOpenGpayModal={() => handleOpenGpayModal()}
          />
        )}

        {currentTab === 'van' && (
          <VanFeeManager
            students={students}
            settings={settings}
            onUpdateStudent={handleUpdateStudent}
            onSelectForReceipt={handleSelectForReceipt}
            onOpenGpayModal={handleOpenGpayModal}
          />
        )}
      </main>

      {/* Screen-Only Footer */}
      <footer className="no-print bg-slate-900 text-slate-400 text-xs py-4 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-between items-center gap-2">
          <div>
            <p className="font-semibold text-slate-300">
              {settings.schoolName} — {settings.addressLine1}, {settings.addressLine2}
            </p>
            <p className="text-[11px] text-slate-400">
              Admin: <strong className="text-amber-400">{settings.adminName}</strong> | Principal:{' '}
              <strong className="text-emerald-400">{settings.principalName}</strong> | GPay Mobile:{' '}
              <strong className="text-white font-mono">{settings.gpayNumber}</strong>
            </p>
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-3">
            <span>{storageError ? 'Data saving issue' : 'Data saved on this device'}</span>
            <span>•</span>
            <span>Classes: LKG to 5th Std</span>
            <span>•</span>
            <button
              onClick={handleResetAllData}
              className="text-slate-400 hover:text-rose-400 transition"
            >
              Reset Data
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <EditFeeModal
        isOpen={isEditFeeModalOpen}
        onClose={() => setIsEditFeeModalOpen(false)}
        student={editingFeeStudent}
        onSave={handleUpdateStudent}
        onOpenGpayModal={handleOpenGpayModal}
        settings={settings}
      />

      <GpayModal
        isOpen={isGpayModalOpen}
        onClose={() => setIsGpayModalOpen(false)}
        settings={settings}
        defaultAmount={gpayModalAmount}
        studentName={gpayModalStudentName}
      />

      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaveSettings={setSettings}
        onResetData={handleResetAllData}
      />
    </div>
  );
}
