import React, { useState, useEffect } from 'react';
import { X, Save, Trash2, User, School, Bus, AlertCircle } from 'lucide-react';
import { Student, SchoolSettings, SchoolClass, Section } from '../types';

interface StudentModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null; // null for New Student, or existing Student to Edit
  onSave: (student: Student) => void;
  onDelete?: (studentId: string) => void;
  settings: SchoolSettings;
}

export const StudentModal: React.FC<StudentModalProps> = ({
  isOpen,
  onClose,
  student,
  onSave,
  onDelete,
  settings,
}) => {
  // Form State
  const [formAdmNo, setFormAdmNo] = useState<string>('');
  const [formName, setFormName] = useState<string>('');
  const [formFatherName, setFormFatherName] = useState<string>('');
  const [formClass, setFormClass] = useState<SchoolClass>('LKG');
  const [formSection, setFormSection] = useState<Section>('A');
  const [formGender, setFormGender] = useState<'Male' | 'Female'>('Male');
  const [formPhone, setFormPhone] = useState<string>('9176593190');
  const [formAddress, setFormAddress] = useState<string>('Essur Village');

  // School Fees
  const [formAdmissionFee, setFormAdmissionFee] = useState<number>(0);
  const [formTuition, setFormTuition] = useState<number>(8000);
  const [formBooks, setFormBooks] = useState<number>(2000);
  const [formExamFee, setFormExamFee] = useState<number>(1500);
  const [formPaid, setFormPaid] = useState<number>(0);

  // Van Fees
  const [formUsesVan, setFormUsesVan] = useState<boolean>(false);
  const [formVanRoute, setFormVanRoute] = useState<string>('Route 1: Essur - Thozhupedu');
  const [formPickupPoint, setFormPickupPoint] = useState<string>('Essur Bus Stand');
  const [formVanFee, setFormVanFee] = useState<number>(4500);
  const [formVanPaid, setFormVanPaid] = useState<number>(0);

  useEffect(() => {
    if (student) {
      setFormAdmNo(student.admissionNo);
      setFormName(student.name);
      setFormFatherName(student.fatherName || '');
      setFormClass(student.studentClass);
      setFormSection(student.section);
      setFormGender(student.gender);
      setFormPhone(student.parentPhone || '');
      setFormAddress(student.address || '');

      const b = student.schoolFees.feeBreakdown;
      setFormAdmissionFee(b.admissionFee || 0);
      setFormTuition(b.tuitionFee || 0);
      setFormBooks(b.booksStationeryFee || 0);
      setFormExamFee(b.examFee || 0);
      setFormPaid(student.schoolFees.paidAmount || 0);

      setFormUsesVan(student.vanFees.usesVan);
      setFormVanRoute(student.vanFees.route || 'Route 1: Essur - Thozhupedu');
      setFormPickupPoint(student.vanFees.pickupPoint || 'Essur Bus Stand');
      setFormVanFee(student.vanFees.termFee || 0);
      setFormVanPaid(student.vanFees.paidAmount || 0);
    } else {
      const rand = Math.floor(100 + Math.random() * 900);
      setFormAdmNo(`W2026-${rand}`);
      setFormName('');
      setFormFatherName('');
      setFormClass('LKG');
      setFormSection('A');
      setFormGender('Male');
      setFormPhone('9176593190');
      setFormAddress('Essur Village');
      setFormAdmissionFee(0);
      setFormTuition(8000);
      setFormBooks(2000);
      setFormExamFee(1500);
      setFormPaid(0);
      setFormUsesVan(false);
      setFormVanRoute('Route 1: Essur - Thozhupedu');
      setFormPickupPoint('Essur Bus Stand');
      setFormVanFee(4500);
      setFormVanPaid(0);
    }
  }, [student, isOpen]);

  if (!isOpen) return null;

  const totalSchoolFee = formAdmissionFee + formTuition + formBooks + formExamFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formAdmNo.trim()) {
      alert('Please fill student name and admission number.');
      return;
    }

    let schoolStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';
    if (formPaid >= totalSchoolFee && totalSchoolFee > 0) schoolStatus = 'Paid';
    else if (formPaid > 0) schoolStatus = 'Partial';

    let vanStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';
    if (formVanPaid >= formVanFee && formVanFee > 0) vanStatus = 'Paid';
    else if (formVanPaid > 0) vanStatus = 'Partial';

    const studentData: Student = {
      id: student ? student.id : `std-${Date.now()}`,
      admissionNo: formAdmNo,
      name: formName,
      fatherName: formFatherName,
      studentClass: formClass,
      section: formSection,
      gender: formGender,
      parentPhone: formPhone,
      whatsappPhone: formPhone,
      address: formAddress,
      academicYear: settings.currentAcademicYear,
      schoolFees: {
        totalFee: totalSchoolFee,
        paidAmount: formPaid,
        term: 'Annual',
        feeBreakdown: {
          admissionFee: formAdmissionFee,
          tuitionFee: formTuition,
          examFee: formExamFee,
          booksStationeryFee: formBooks,
          uniformActivityFee: 0,
          otherFee: 0,
        },
        status: schoolStatus,
        lastPaymentDate: formPaid > 0 ? new Date().toISOString().split('T')[0] : (student?.schoolFees.lastPaymentDate),
      },
      vanFees: {
        usesVan: formUsesVan,
        route: formUsesVan ? formVanRoute : 'None',
        pickupPoint: formUsesVan ? formPickupPoint : 'Walking',
        termFee: formUsesVan ? formVanFee : 0,
        paidAmount: formUsesVan ? formVanPaid : 0,
        vanStatus: formUsesVan ? vanStatus : 'Paid',
        lastPaymentDate: formVanPaid > 0 ? new Date().toISOString().split('T')[0] : (student?.vanFees.lastPaymentDate),
      },
      remarks: student?.remarks || 'Active Student',
    };

    onSave(studentData);
    onClose();
  };

  const handleDelete = () => {
    if (!student || !onDelete) return;
    if (confirm(`Are you sure you want to delete student record for ${student.name} (${student.admissionNo})? This action cannot be undone.`)) {
      onDelete(student.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-4 text-white flex justify-between items-center sticky top-0 z-10 shadow-sm">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-amber-300 font-bold">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">
                {student ? `Edit Student: ${student.name}` : 'Add New Student (LKG to 5th Std)'}
              </h3>
              <p className="text-[11px] text-blue-200">
                {student ? `Admission No: ${student.admissionNo} • Class: ${student.studentClass}` : 'Enter student details, fee structures, and transport route'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          
          {/* Section 1: Basic Info */}
          <div className="space-y-3">
            <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] border-b pb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-blue-600" />
              <span>Student & Academic Details</span>
            </h4>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Admission No *</label>
                <input
                  type="text"
                  required
                  value={formAdmNo}
                  onChange={(e) => setFormAdmNo(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Student Name *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. S. Vignesh"
                  className="w-full border border-slate-300 rounded-lg p-2 font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Father / Guardian Name</label>
                <input
                  type="text"
                  value={formFatherName}
                  onChange={(e) => setFormFatherName(e.target.value)}
                  placeholder="e.g. P. Sivakumar"
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Standard / Class *</label>
                <select
                  value={formClass}
                  onChange={(e) => setFormClass(e.target.value as SchoolClass)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-semibold bg-white"
                >
                  <option value="Pre-KG">Pre-KG</option>
                  <option value="LKG">LKG</option>
                  <option value="UKG">UKG</option>
                  <option value="1st Standard">1st Standard</option>
                  <option value="2nd Standard">2nd Standard</option>
                  <option value="3rd Standard">3rd Standard</option>
                  <option value="4th Standard">4th Standard</option>
                  <option value="5th Standard">5th Standard</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Section</label>
                <select
                  value={formSection}
                  onChange={(e) => setFormSection(e.target.value as Section)}
                  className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                >
                  <option value="A">Section A</option>
                  <option value="B">Section B</option>
                  <option value="C">Section C</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                <select
                  value={formGender}
                  onChange={(e) => setFormGender(e.target.value as any)}
                  className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Parent Mobile / WhatsApp</label>
                <input
                  type="text"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  placeholder="e.g. 9176593190"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Address / Village</label>
                <input
                  type="text"
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  placeholder="e.g. Essur Village"
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>
            </div>
          </div>

          {/* Section 2: School Fees Structure */}
          <div className="space-y-3 pt-2">
            <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] border-b pb-1 flex items-center gap-1.5">
              <School className="w-3.5 h-3.5 text-indigo-600" />
              <span>School Fees Particulars (₹)</span>
            </h4>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Admission Fee</label>
                <input
                  type="number"
                  value={formAdmissionFee || ''}
                  onChange={(e) => setFormAdmissionFee(parseFloat(e.target.value) || 0)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tuition Fee</label>
                <input
                  type="number"
                  value={formTuition || ''}
                  onChange={(e) => setFormTuition(parseFloat(e.target.value) || 0)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Books & Stationery</label>
                <input
                  type="number"
                  value={formBooks || ''}
                  onChange={(e) => setFormBooks(parseFloat(e.target.value) || 0)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Exam Fee</label>
                <input
                  type="number"
                  value={formExamFee || ''}
                  onChange={(e) => setFormExamFee(parseFloat(e.target.value) || 0)}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div className="col-span-2">
                <label className="block font-bold text-slate-800 mb-1">
                  Total School Fee: <span className="font-mono text-blue-700">₹ {totalSchoolFee.toLocaleString('en-IN')}</span>
                </label>
              </div>

              <div className="col-span-2">
                <label className="block font-semibold text-emerald-800 mb-1">Amount Already Paid (₹)</label>
                <input
                  type="number"
                  value={formPaid || ''}
                  onChange={(e) => setFormPaid(parseFloat(e.target.value) || 0)}
                  className="w-full border border-emerald-300 bg-emerald-50/50 rounded-lg p-2 font-mono font-bold text-emerald-900"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Transport & Van Fee */}
          <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center border-b pb-1">
              <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] flex items-center gap-1.5">
                <Bus className="w-3.5 h-3.5 text-amber-600" />
                <span>Van & Transport Details</span>
              </h4>
              <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-700">
                <input
                  type="checkbox"
                  checked={formUsesVan}
                  onChange={(e) => setFormUsesVan(e.target.checked)}
                  className="rounded border-slate-300 text-amber-600 focus:ring-amber-500 w-4 h-4"
                />
                <span>Uses School Van</span>
              </label>
            </div>

            {formUsesVan && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-amber-50/50 p-3 rounded-xl border border-amber-200 animate-fade-in">
                <div className="col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Van Route</label>
                  <input
                    type="text"
                    value={formVanRoute}
                    onChange={(e) => setFormVanRoute(e.target.value)}
                    placeholder="e.g. Route 1: Essur - Thozhupedu"
                    className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Pickup / Drop Point</label>
                  <input
                    type="text"
                    value={formPickupPoint}
                    onChange={(e) => setFormPickupPoint(e.target.value)}
                    placeholder="e.g. Essur Temple Stop"
                    className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Van Fee Term (₹)</label>
                  <input
                    type="number"
                    value={formVanFee || ''}
                    onChange={(e) => setFormVanFee(parseFloat(e.target.value) || 0)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono bg-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-amber-900 mb-1">Van Fee Paid (₹)</label>
                  <input
                    type="number"
                    value={formVanPaid || ''}
                    onChange={(e) => setFormVanPaid(parseFloat(e.target.value) || 0)}
                    className="w-full border border-amber-300 rounded-lg p-2 font-mono bg-white font-bold"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div className="pt-4 border-t flex flex-wrap justify-between items-center gap-2">
            {student && onDelete && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl font-bold flex items-center gap-1.5 transition"
              >
                <Trash2 className="w-4 h-4 text-rose-600" />
                <span>Delete Student</span>
              </button>
            )}

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold text-slate-700 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-sm flex items-center gap-1.5 transition"
              >
                <Save className="w-4 h-4" />
                <span>{student ? 'Update Student Record' : 'Save New Student'}</span>
              </button>
            </div>
          </div>
        </form>

      </div>
    </div>
  );
};
