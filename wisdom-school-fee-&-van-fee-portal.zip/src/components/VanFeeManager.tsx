import React, { useState } from 'react';
import { 
  Bus, 
  MapPin, 
  CheckCircle, 
  AlertCircle, 
  FileDown, 
  MessageCircle, 
  CreditCard, 
  Plus, 
  Search,
  Users
} from 'lucide-react';
import { Student, SchoolSettings } from '../types';
import { generateBulkVanFeesPdf } from '../utils/pdfGenerator';
import { generateVanNoticeMessage } from '../utils/whatsappHelper';

interface VanFeeManagerProps {
  students: Student[];
  settings: SchoolSettings;
  onUpdateStudent: (student: Student) => void;
  onSelectForReceipt: (student: Student) => void;
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
}

export const VanFeeManager: React.FC<VanFeeManagerProps> = ({
  students,
  settings,
  onUpdateStudent,
  onSelectForReceipt,
  onOpenGpayModal,
}) => {
  const [selectedRoute, setSelectedRoute] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Extract all van riders
  const vanRiders = students.filter(s => s.vanFees.usesVan);

  // Extract distinct routes
  const availableRoutes = Array.from(new Set(vanRiders.map(s => s.vanFees.route))).filter(Boolean);

  const filteredRiders = vanRiders.filter(s => {
    if (selectedRoute !== 'All' && s.vanFees.route !== selectedRoute) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = s.name.toLowerCase().includes(q);
      const matchAdm = s.admissionNo.toLowerCase().includes(q);
      const matchStop = s.vanFees.pickupPoint.toLowerCase().includes(q);
      const matchPhone = s.parentPhone.includes(q);
      return matchName || matchAdm || matchStop || matchPhone;
    }
    return true;
  });

  // Calculate route metrics
  const totalBilled = filteredRiders.reduce((acc, s) => acc + s.vanFees.termFee, 0);
  const totalCollected = filteredRiders.reduce((acc, s) => acc + s.vanFees.paidAmount, 0);
  const totalPending = totalBilled - totalCollected;

  const handleMarkVanFeePaid = (student: Student) => {
    const updated: Student = {
      ...student,
      vanFees: {
        ...student.vanFees,
        paidAmount: student.vanFees.termFee,
        vanStatus: 'Paid',
        lastPaymentDate: new Date().toISOString().split('T')[0],
      },
    };
    onUpdateStudent(updated);
    alert(`Van fee of ₹${student.vanFees.termFee} marked as paid for ${student.name}.`);
  };

  const handleSendVanWhatsApp = (student: Student) => {
    const message = generateVanNoticeMessage(student, settings);
    const cleanPhone = (student.parentPhone || '').replace(/\D/g, '');
    const phoneWithPrefix = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const url = `https://wa.me/${phoneWithPrefix}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-sm">
              <Bus className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                School Van & Transport Fee Management
              </h2>
              <p className="text-xs text-slate-500">
                Track bus stops, routes, driver checklists, and transport collections across Essur & surrounding villages.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => generateBulkVanFeesPdf(students, settings, { selectedClass: 'All' })}
              className="px-3.5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <FileDown className="w-4 h-4" />
              <span>Download Van Fee Bulk PDF</span>
            </button>
          </div>
        </div>

        {/* Route Filter & Metrics */}
        <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-500 block uppercase font-semibold text-[10px]">Total Van Students</span>
            <span className="text-lg font-bold text-slate-900">{filteredRiders.length} Students</span>
          </div>

          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <span className="text-slate-500 block uppercase font-semibold text-[10px]">Total Van Fee</span>
            <span className="text-lg font-mono font-bold text-slate-900">₹ {totalBilled.toLocaleString('en-IN')}</span>
          </div>

          <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs">
            <span className="text-emerald-700 block uppercase font-semibold text-[10px]">Collected</span>
            <span className="text-lg font-mono font-bold text-emerald-800">₹ {totalCollected.toLocaleString('en-IN')}</span>
          </div>

          <div className="bg-rose-50 p-3 rounded-xl border border-rose-200 text-xs">
            <span className="text-rose-700 block uppercase font-semibold text-[10px]">Pending Dues</span>
            <span className="text-lg font-mono font-bold text-rose-800">₹ {totalPending.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Route selector pills */}
        <div className="mt-4 flex flex-wrap justify-between items-center gap-3">
          <div className="flex gap-1.5 overflow-x-auto">
            <button
              onClick={() => setSelectedRoute('All')}
              className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                selectedRoute === 'All'
                  ? 'bg-amber-700 text-white font-bold'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              All Routes ({vanRiders.length})
            </button>
            {availableRoutes.map((rt) => (
              <button
                key={rt}
                onClick={() => setSelectedRoute(rt)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                  selectedRoute === rt
                    ? 'bg-amber-700 text-white font-bold'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {rt}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search rider, stop, roll no..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* Van Riders Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Adm No</th>
                <th className="p-3">Student Name</th>
                <th className="p-3">Class</th>
                <th className="p-3">Van Route & Stop</th>
                <th className="p-3">Parent Phone</th>
                <th className="p-3 text-right">Van Fee</th>
                <th className="p-3 text-right">Paid</th>
                <th className="p-3 text-right">Balance Due</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRiders.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400 italic">
                    No van riders found matching your selection.
                  </td>
                </tr>
              ) : (
                filteredRiders.map((s) => {
                  const v = s.vanFees;
                  const due = v.termFee - v.paidAmount;

                  return (
                    <tr key={s.id} className="hover:bg-slate-50">
                      <td className="p-3 font-mono font-bold text-slate-800">{s.admissionNo}</td>
                      <td className="p-3 font-bold text-slate-900">{s.name}</td>
                      <td className="p-3">{s.studentClass} - {s.section}</td>
                      <td className="p-3">
                        <div className="font-semibold text-slate-800">{v.route}</div>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-amber-600" />
                          <span>{v.pickupPoint}</span>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-slate-700">{s.parentPhone}</td>
                      <td className="p-3 text-right font-mono font-semibold">
                        ₹ {v.termFee.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3 text-right font-mono text-emerald-700">
                        ₹ {v.paidAmount.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3 text-right font-mono font-bold text-rose-700">
                        ₹ {due.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3 text-center">
                        {due <= 0 ? (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            Paid
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                            Due
                          </span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Quick receipt generation */}
                          <button
                            onClick={() => onSelectForReceipt(s)}
                            className="p-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100"
                            title="Generate Van Fee Receipt"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                          </button>

                          {/* Quick Mark Paid */}
                          {due > 0 && (
                            <button
                              onClick={() => handleMarkVanFeePaid(s)}
                              className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                              title="Mark Full Van Fee Paid"
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Send WhatsApp Reminder */}
                          <button
                            onClick={() => handleSendVanWhatsApp(s)}
                            className="p-1.5 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100"
                            title="Send WhatsApp Van Fee Notice with GPay 917659319"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
