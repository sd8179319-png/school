import React, { useState, useEffect } from 'react';
import { 
  Contact, 
  Download, 
  Upload, 
  User, 
  Sparkles, 
  Layers,
} from 'lucide-react';
import { Student, SchoolSettings } from '../types';
import { generateStudentIdCardPdf, generateBulkIdCardsPdf } from '../utils/pdfGenerator';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';

interface IdCardGeneratorProps {
  students: Student[];
  settings: SchoolSettings;
  onUpdateStudent: (updatedStudent: Student) => void;
}

export const IdCardGenerator: React.FC<IdCardGeneratorProps> = ({
  students,
  settings,
  onUpdateStudent,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [qrSrc, setQrSrc] = useState<string>('');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [previewSide, setPreviewSide] = useState<'front' | 'back'>('front');
  const [downloadError, setDownloadError] = useState<string>('');

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  const filteredStudents = students.filter(s => {
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;
    return true;
  });

  const selectedStudent = filteredStudents.find(s => s.id === selectedStudentId) || filteredStudents[0] || students[0];

  useEffect(() => {
    if (selectedStudent) {
      const upiUri = buildUpiUri({
        upiId: settings.upiId,
        payeeName: settings.adminName,
        note: `ID:${selectedStudent.admissionNo} ${selectedStudent.name}`,
      });
      generateQrDataUrl(upiUri).then(dataUrl => setQrSrc(dataUrl));
    }
  }, [selectedStudent, settings]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedStudent) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const photoUrl = event.target?.result as string;
      if (photoUrl) {
        onUpdateStudent({
          ...selectedStudent,
          photoUrl,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadSinglePdf = async () => {
    if (!selectedStudent) return;
    setIsDownloading(true);
    setDownloadError('');
    try {
      await generateStudentIdCardPdf(selectedStudent, settings, qrSrc);
    } catch (error) {
      setDownloadError(error instanceof Error ? error.message : 'Could not create the ID card PDF.');
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadBulkPdf = async () => {
    if (filteredStudents.length === 0) return;
    setIsDownloading(true);
    setDownloadError('');
    try {
      const qrDataUrls = await Promise.all(filteredStudents.map(student => {
        const upiUri = buildUpiUri({
          upiId: settings.upiId,
          payeeName: settings.adminName,
          note: `ID:${student.admissionNo} ${student.name}`,
        });
        return generateQrDataUrl(upiUri);
      }));
      await generateBulkIdCardsPdf(filteredStudents, settings, qrDataUrls);
    } catch (error) {
      setDownloadError(error instanceof Error ? error.message : 'Could not create the bulk ID card PDF.');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold shadow-sm">
              <Contact className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                Student Identity Card Creator & Generator
              </h2>
              <p className="text-xs text-slate-500">
                Print student cards front and back at standard CR-80 ID-card size (85.6 × 54 mm).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadBulkPdf}
              disabled={isDownloading || filteredStudents.length === 0}
              className="px-3.5 py-2 bg-blue-800 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <Layers className="w-4 h-4 text-amber-300" />
              <span>Download Bulk Front &amp; Back ({filteredStudents.length})</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap justify-between items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="font-bold text-slate-600">Class:</span>
            {classesList.map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                  selectedClass === cls
                    ? 'bg-blue-900 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Select Student:</span>
            <select
              value={selectedStudent?.id || ''}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="border border-slate-300 rounded-lg p-1.5 text-xs font-semibold text-slate-800 bg-white"
            >
              {filteredStudents.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.studentClass} - {s.section}) • {s.admissionNo}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Card Editor & Live Card Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: ID Card Profile & Photo Customizer (5 Cols) */}
        <section className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Student ID Card Customizer</span>
            </h3>

            {selectedStudent && (
              <div className="space-y-3 text-xs">
                {/* Photo Upload Card */}
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center gap-4">
                  <div className="w-20 h-24 rounded-lg bg-slate-200 border-2 border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                    {selectedStudent.photoUrl ? (
                      <img
                        src={selectedStudent.photoUrl}
                        alt={selectedStudent.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-8 h-8 text-slate-400" />
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <span className="font-bold text-slate-800 block text-xs">Student ID Photo</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow-sm transition">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Student Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[10px] text-slate-500">
                      Passport size photo (JPG, PNG).
                    </p>
                  </div>
                </div>

                {/* Blood Group and Emergency Contact */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Blood Group</label>
                    <select
                      value={selectedStudent.bloodGroup || 'B+'}
                      onChange={(e) => onUpdateStudent({ ...selectedStudent, bloodGroup: e.target.value })}
                      className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-800 bg-white"
                    >
                      {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                        <option key={bg} value={bg}>{bg} Positive/Negative</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Emergency Mobile</label>
                    <input
                      type="text"
                      value={selectedStudent.emergencyContact || selectedStudent.parentPhone}
                      onChange={(e) => onUpdateStudent({ ...selectedStudent, emergencyContact: e.target.value })}
                      placeholder="e.g. 9176593190"
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                    />
                  </div>
                </div>

                {/* Quick Info Review */}
                <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1 text-slate-700">
                  <p><strong>Name:</strong> {selectedStudent.name}</p>
                  <p><strong>Admission No:</strong> {selectedStudent.admissionNo}</p>
                  <p><strong>Class:</strong> {selectedStudent.studentClass} - {selectedStudent.section}</p>
                  <p><strong>Father:</strong> {selectedStudent.fatherName}</p>
                  <p><strong>Address:</strong> {selectedStudent.address}</p>
                  <p><strong>Transport:</strong> {selectedStudent.vanFees.usesVan ? selectedStudent.vanFees.pickupPoint : 'Self / Walking'}</p>
                </div>

                {/* Download PDF Button */}
                <button
                  onClick={handleDownloadSinglePdf}
                  disabled={isDownloading}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow transition flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download ID-Size PDF (Front &amp; Back)</span>
                </button>
              </div>
            )}
            {downloadError && (
              <p role="alert" className="rounded-lg border border-red-200 bg-red-50 p-2 text-xs font-semibold text-red-700">
                {downloadError}
              </p>
            )}
          </div>
        </section>

        {/* Right Column: Physical ID Card Visual Preview (7 Cols) */}
        <section className="lg:col-span-7 bg-slate-200/80 rounded-2xl p-6 border border-slate-300 flex flex-col items-center justify-center">
          
          <div className="w-full max-w-xl flex justify-between items-center mb-3">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">CR-80 ID Card Preview</span>
            <div className="flex gap-1 rounded-lg bg-slate-300 p-1">
              <button
                onClick={() => setPreviewSide('front')}
                className={`px-3 py-1 rounded-md text-xs font-bold ${previewSide === 'front' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-600'}`}
              >
                Front
              </button>
              <button
                onClick={() => setPreviewSide('back')}
                className={`px-3 py-1 rounded-md text-xs font-bold ${previewSide === 'back' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-600'}`}
              >
                Back
              </button>
            </div>
          </div>

          {selectedStudent && (
            <div className="w-full max-w-xl aspect-[85.6/54] bg-white rounded-xl shadow-2xl border-2 border-blue-950 overflow-hidden font-sans text-slate-900 select-none">
              {previewSide === 'front' ? (
                <>
                  <div className="h-[22%] bg-blue-950 text-white px-4 flex flex-col justify-center border-b-2 border-amber-400">
                    <h3 className="text-sm font-bold uppercase tracking-wide truncate">{settings.schoolName}</h3>
                    <p className="text-[10px] text-blue-200 truncate">{settings.addressLine1}, {settings.addressLine2}</p>
                  </div>
                  <div className="h-[70%] px-4 py-2 flex gap-4 items-center">
                    <div className="w-[22%] h-[88%] rounded border border-blue-900 bg-slate-100 overflow-hidden flex items-center justify-center shrink-0">
                      {selectedStudent.photoUrl ? (
                        <img src={selectedStudent.photoUrl} alt={selectedStudent.name} className="w-full h-full object-cover" />
                      ) : (
                        <User className="w-10 h-10 text-slate-400" />
                      )}
                    </div>
                    <div className="min-w-0 space-y-1">
                      <h4 className="text-lg font-extrabold uppercase truncate">{selectedStudent.name}</h4>
                      <p className="text-xs font-bold text-blue-900">{selectedStudent.studentClass} - Section {selectedStudent.section}</p>
                      <p className="text-xs"><strong>Admission No:</strong> {selectedStudent.admissionNo}</p>
                      <p className="text-xs"><strong>Parent:</strong> {selectedStudent.fatherName || 'Parent'} · {selectedStudent.parentPhone}</p>
                      <p className="text-xs"><strong>Blood:</strong> {selectedStudent.bloodGroup || 'Not specified'} · <strong>Transport:</strong> {selectedStudent.vanFees.usesVan ? selectedStudent.vanFees.pickupPoint : 'Walking'}</p>
                    </div>
                  </div>
                  <div className="h-[8%] bg-amber-400 text-center text-[9px] font-bold flex items-center justify-center">
                    STUDENT ID · {settings.currentAcademicYear}
                  </div>
                </>
              ) : (
                <>
                  <div className="h-[22%] bg-blue-950 text-white px-4 flex items-center justify-center border-b-2 border-amber-400">
                    <h3 className="text-sm font-bold uppercase tracking-wide">If Found, Please Return To</h3>
                  </div>
                  <div className="h-[78%] p-4 flex gap-4">
                    <div className="flex-1 min-w-0 space-y-2 text-xs">
                      <p><strong>Student:</strong> {selectedStudent.name}</p>
                      <p><strong>Address:</strong> {selectedStudent.address || 'Not provided'}</p>
                      <p><strong>Emergency Contact:</strong> {selectedStudent.emergencyContact || selectedStudent.parentPhone}</p>
                      <div className="border-t border-slate-200 pt-2">
                        <p className="font-bold">{settings.schoolName}</p>
                        <p>{settings.phone1}{settings.phone2 ? ` / ${settings.phone2}` : ''}</p>
                        <p>{settings.addressLine1}, {settings.addressLine2}</p>
                      </div>
                    </div>
                    {qrSrc && <img src={qrSrc} alt="Student payment QR code" className="w-20 h-20 self-center border border-slate-300 p-1 rounded" />}
                  </div>
                </>
              )}
            </div>
          )}
        </section>

      </div>
    </div>
  );
};
