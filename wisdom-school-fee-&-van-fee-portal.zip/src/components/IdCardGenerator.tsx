import React, { useState, useEffect } from 'react';
import { 
  Contact, 
  Download, 
  Printer, 
  Upload, 
  User, 
  Filter, 
  Sparkles, 
  ShieldCheck, 
  QrCode, 
  Layers,
  GraduationCap
} from 'lucide-react';
import { Student, SchoolSettings, SchoolClass } from '../types';
import { generateStudentIdCardPdf, generateBulkIdCardsPdf } from '../utils/pdfGenerator';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';
import { DEFAULT_SCHOOL_LOGO } from '../utils/sampleData';

interface IdCardGeneratorProps {
  students: Student[];
  settings: SchoolSettings;
  onUpdateStudent: (updatedStudent: Student) => void;
}

export const IdCardGenerator: React.FC<IdCardGeneratorProps> = ({
  students,
  settings,
  onUpdateStudent,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [qrSrc, setQrSrc] = useState<string>('');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  const filteredStudents = students.filter(s => {
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;
    return true;
  });

  const selectedStudent = students.find(s => s.id === selectedStudentId) || filteredStudents[0] || students[0];

  useEffect(() => {
    if (selectedStudent) {
      const upiUri = buildUpiUri({
        upiId: settings.upiId,
        payeeName: settings.adminName,
        note: `ID:${selectedStudent.admissionNo} ${selectedStudent.name}`,
      });
      generateQrDataUrl(upiUri).then(dataUrl => setQrSrc(dataUrl));
    }
  }, [selectedStudent, settings]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedStudent) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const photoUrl = event.target?.result as string;
      if (photoUrl) {
        onUpdateStudent({
          ...selectedStudent,
          photoUrl,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDownloadSinglePdf = () => {
    if (!selectedStudent) return;
    setIsDownloading(true);
    setTimeout(() => {
      generateStudentIdCardPdf(selectedStudent, settings, qrSrc);
      setIsDownloading(false);
    }, 200);
  };

  const handleDownloadBulkPdf = () => {
    if (filteredStudents.length === 0) return;
    setIsDownloading(true);
    setTimeout(() => {
      generateBulkIdCardsPdf(filteredStudents, settings, qrSrc);
      setIsDownloading(false);
    }, 300);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold shadow-sm">
              <Contact className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                Student Identity Card Creator & Generator
              </h2>
              <p className="text-xs text-slate-500">
                Design, customize student photos, and download official print-ready ID cards (CR-80 Badge Standard).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadBulkPdf}
              disabled={isDownloading}
              className="px-3.5 py-2 bg-blue-800 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <Layers className="w-4 h-4 text-amber-300" />
              <span>Download Bulk ID Cards ({filteredStudents.length} Students)</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print Badge A4</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap justify-between items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="font-bold text-slate-600">Class:</span>
            {classesList.map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                  selectedClass === cls
                    ? 'bg-blue-900 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Select Student:</span>
            <select
              value={selectedStudent?.id || ''}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="border border-slate-300 rounded-lg p-1.5 text-xs font-semibold text-slate-800 bg-white"
            >
              {filteredStudents.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.studentClass} - {s.section}) • {s.admissionNo}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Grid: Card Editor & Live Card Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: ID Card Profile & Photo Customizer (5 Cols) */}
        <section className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>Student ID Card Customizer</span>
            </h3>

            {selectedStudent && (
              <div className="space-y-3 text-xs">
                {/* Photo Upload Card */}
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center gap-4">
                  <div className="w-20 h-24 rounded-lg bg-slate-200 border-2 border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                    {selectedStudent.photoUrl ? (
                      <img
                        src={selectedStudent.photoUrl}
                        alt={selectedStudent.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <User className="w-8 h-8 text-slate-400" />
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <span className="font-bold text-slate-800 block text-xs">Student ID Photo</span>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow-sm transition">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Student Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoUpload}
                        className="hidden"
                      />
                    </label>
                    <p className="text-[10px] text-slate-500">
                      Passport size photo (JPG, PNG).
                    </p>
                  </div>
                </div>

                {/* Blood Group and Emergency Contact */}
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Blood Group</label>
                    <select
                      value={selectedStudent.bloodGroup || 'B+'}
                      onChange={(e) => onUpdateStudent({ ...selectedStudent, bloodGroup: e.target.value })}
                      className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-800 bg-white"
                    >
                      {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                        <option key={bg} value={bg}>{bg} Positive/Negative</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Emergency Mobile</label>
                    <input
                      type="text"
                      value={selectedStudent.emergencyContact || selectedStudent.parentPhone}
                      onChange={(e) => onUpdateStudent({ ...selectedStudent, emergencyContact: e.target.value })}
                      placeholder="e.g. 9176593190"
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                    />
                  </div>
                </div>

                {/* Quick Info Review */}
                <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200 space-y-1 text-slate-700">
                  <p><strong>Name:</strong> {selectedStudent.name}</p>
                  <p><strong>Admission No:</strong> {selectedStudent.admissionNo}</p>
                  <p><strong>Class:</strong> {selectedStudent.studentClass} - {selectedStudent.section}</p>
                  <p><strong>Father:</strong> {selectedStudent.fatherName}</p>
                  <p><strong>Address:</strong> {selectedStudent.address}</p>
                  <p><strong>Transport:</strong> {selectedStudent.vanFees.usesVan ? selectedStudent.vanFees.pickupPoint : 'Self / Walking'}</p>
                </div>

                {/* Download PDF Button */}
                <button
                  onClick={handleDownloadSinglePdf}
                  disabled={isDownloading}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow transition flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download This Student ID Card (PDF)</span>
                </button>
              </div>
            )}
          </div>
        </section>

        {/* Right Column: Physical ID Card Visual Preview (7 Cols) */}
        <section className="lg:col-span-7 bg-slate-200/80 rounded-2xl p-6 border border-slate-300 flex flex-col items-center justify-center">
          
          <div className="w-full flex justify-between items-center mb-3 max-w-sm">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              CR-80 Standard ID Card Preview
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              86mm × 120mm Badge
            </span>
          </div>

          {selectedStudent && (
            <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border-2 border-slate-800 overflow-hidden relative font-sans text-slate-900 select-none">
              
              {/* Lanyard Hole Mockup */}
              <div className="w-full pt-2 flex justify-center bg-blue-950">
                <div className="w-8 h-2 rounded-full bg-slate-900 border border-slate-700"></div>
              </div>

              {/* ID Card Top Header */}
              <div className="bg-blue-950 text-white p-3 text-center border-b-2 border-amber-400">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <img
                    src={settings.logoUrl || DEFAULT_SCHOOL_LOGO}
                    alt="School Logo"
                    className="w-8 h-8 rounded-full bg-white p-0.5 object-contain"
                  />
                  <div>
                    <h3 className="font-header text-xs md:text-sm font-bold uppercase tracking-tight text-white leading-tight">
                      {settings.schoolName}
                    </h3>
                    <p className="text-[8px] text-blue-200 leading-none">
                      Essur Village, Acharapakkam Taluk - 603301
                    </p>
                  </div>
                </div>

                <div className="inline-block bg-amber-400 text-slate-950 text-[9px] font-extrabold uppercase px-3 py-0.5 rounded-full tracking-wider mt-0.5">
                  STUDENT IDENTITY CARD • {settings.currentAcademicYear}
                </div>
              </div>

              {/* Photo & Name Section */}
              <div className="p-4 flex flex-col items-center space-y-2">
                
                {/* Photo Frame */}
                <div className="w-24 h-28 rounded-xl border-2 border-blue-900 p-0.5 bg-white shadow-md overflow-hidden flex items-center justify-center">
                  {selectedStudent.photoUrl ? (
                    <img
                      src={selectedStudent.photoUrl}
                      alt={selectedStudent.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <div className="w-full h-full bg-slate-100 flex flex-col items-center justify-center text-slate-400">
                      <User className="w-10 h-10 mb-1" />
                      <span className="text-[9px] font-bold">STUDENT PHOTO</span>
                    </div>
                  )}
                </div>

                {/* Student Full Name */}
                <div className="text-center">
                  <h4 className="font-extrabold text-base text-slate-950 tracking-tight uppercase">
                    {selectedStudent.name}
                  </h4>
                  <div className="inline-block bg-blue-100 text-blue-900 font-bold text-xs px-2.5 py-0.5 rounded-full mt-0.5 border border-blue-200">
                    {selectedStudent.studentClass} - Section {selectedStudent.section}
                  </div>
                </div>

                {/* Details Grid */}
                <div className="w-full bg-slate-50 rounded-xl p-3 border border-slate-200 text-[11px] space-y-1">
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-500">Roll / Adm No:</span>
                    <span className="font-mono font-bold text-slate-900">{selectedStudent.admissionNo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-500">Father's Name:</span>
                    <span className="font-bold text-slate-800">{selectedStudent.fatherName || 'Parent'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-500">Parent Mobile:</span>
                    <span className="font-mono font-semibold text-slate-800">{selectedStudent.parentPhone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-500">Blood Group:</span>
                    <span className="font-bold text-rose-700">{selectedStudent.bloodGroup || 'B+ Positive'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-semibold text-slate-500">Transport:</span>
                    <span className="font-semibold text-slate-800 truncate max-w-[150px]">
                      {selectedStudent.vanFees.usesVan ? selectedStudent.vanFees.pickupPoint : 'Walking'}
                    </span>
                  </div>
                </div>

                {/* Footer with QR Code & Principal Signature */}
                <div className="w-full pt-2 border-t border-slate-200 flex justify-between items-center text-[9px]">
                  <div className="flex items-center gap-1.5">
                    {qrSrc && (
                      <img src={qrSrc} alt="QR Code" className="w-10 h-10 border border-slate-300 rounded p-0.5 bg-white" />
                    )}
                    <div>
                      <span className="font-bold text-slate-700 block">Wisdom School</span>
                      <span className="text-[8px] text-slate-500 font-mono">GPay: {settings.gpayNumber}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-bold text-slate-900 block leading-tight">CHITHRA</span>
                    <span className="text-[8px] text-slate-500">Principal Signature</span>
                  </div>
                </div>

              </div>

              {/* Bottom Decorative Strip */}
              <div className="h-2 bg-gradient-to-r from-blue-900 via-amber-400 to-blue-900"></div>
            </div>
          )}
        </section>

      </div>
    </div>
  );
};
