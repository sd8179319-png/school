import React, { useState, useEffect } from 'react';
import { X, Copy, Check, QrCode, Smartphone, ExternalLink, ShieldCheck } from 'lucide-react';
import { SchoolSettings } from '../types';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';

interface GpayModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SchoolSettings;
  defaultAmount?: number;
  studentName?: string;
}

export const GpayModal: React.FC<GpayModalProps> = ({
  isOpen,
  onClose,
  settings,
  defaultAmount = 0,
  studentName = '',
}) => {
  const [amount, setAmount] = useState<number>(defaultAmount);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [qrSrc, setQrSrc] = useState<string>('');

  useEffect(() => {
    if (defaultAmount > 0) {
      setAmount(defaultAmount);
    }
  }, [defaultAmount]);

  useEffect(() => {
    if (!isOpen) return;

    const uri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
      amount: amount > 0 ? amount : undefined,
      note: studentName ? `Fee for ${studentName}` : 'Wisdom School Fee',
    });

    generateQrDataUrl(uri).then(dataUrl => setQrSrc(dataUrl));
  }, [isOpen, amount, studentName, settings]);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const upiUri = buildUpiUri({
    upiId: settings.upiId,
    payeeName: settings.adminName,
    amount: amount > 0 ? amount : undefined,
    note: studentName ? `School Fee ${studentName}` : 'Wisdom School Fee',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
        {/* Top Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 p-4 text-white flex justify-between items-center">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white text-emerald-700 font-extrabold text-lg flex items-center justify-center shadow-sm">
              G
            </div>
            <div>
              <h2 className="font-bold text-base leading-tight">Google Pay & UPI Payment</h2>
              <p className="text-xs text-emerald-100">Wisdom Nursery & Primary School</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-emerald-100 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4">
          {/* Admin & Principal Verified Badge */}
          <div className="bg-emerald-50 rounded-xl p-3 border border-emerald-200 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-bold text-emerald-950">Official Payment Account</p>
              <p className="text-emerald-800">
                Admin: <strong className="text-emerald-950">{settings.adminName}</strong>
              </p>
              <p className="text-emerald-800">
                Principal: <strong className="text-emerald-950">{settings.principalName}</strong>
              </p>
            </div>
          </div>

          {/* QR Code Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col items-center justify-center">
            {qrSrc ? (
              <img
                src={qrSrc}
                alt="UPI QR Code"
                className="w-48 h-48 rounded-xl shadow-sm border border-slate-200 bg-white p-2"
              />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center bg-slate-200 rounded-xl">
                <QrCode className="w-12 h-12 text-slate-400 animate-pulse" />
              </div>
            )}
            <p className="text-[11px] font-semibold text-slate-600 mt-2 flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
              Scan with GPay, PhonePe, Paytm or BHIM
            </p>
            {amount > 0 && (
              <span className="text-sm font-bold text-emerald-700 mt-1">
                Amount: ₹{amount.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {/* Amount input for dynamic QR */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Specify Amount for QR Code (₹)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-sm font-bold text-slate-400">₹</span>
              <input
                type="number"
                value={amount || ''}
                onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                placeholder="Enter fee amount (e.g. 4500)"
                className="w-full pl-8 pr-3 py-1.5 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Key Payment Credentials */}
          <div className="space-y-2 text-xs">
            {/* GPay Number */}
            <div className="flex justify-between items-center p-2.5 bg-slate-100 rounded-lg border border-slate-200">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold tracking-wider">
                  GPay / PhonePe Mobile Number
                </span>
                <span className="font-mono font-bold text-sm text-slate-900 tracking-wider">
                  {settings.gpayNumber}
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(settings.gpayNumber, 'phone')}
                className="flex items-center gap-1 px-2.5 py-1 text-xs rounded bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 font-semibold transition"
              >
                {copiedField === 'phone' ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-600" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* UPI ID */}
            <div className="flex justify-between items-center p-3 bg-emerald-50 rounded-xl border border-emerald-300 shadow-sm">
              <div>
                <span className="text-emerald-800 block text-[10px] uppercase font-bold tracking-wider">
                  Official GPay UPI VPA ID
                </span>
                <span className="font-mono font-extrabold text-sm text-emerald-950 select-all block">
                  {settings.upiId}
                </span>
              </div>
              <button
                onClick={() => copyToClipboard(settings.upiId, 'upi')}
                className="flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold transition shadow-sm"
              >
                {copiedField === 'upi' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy UPI</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Direct Pay Link for Mobile */}
          <a
            href={upiUri}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md transition"
          >
            <ExternalLink className="w-4 h-4" />
            <span>Open in GPay / UPI App (Mobile)</span>
          </a>
        </div>
      </div>
    </div>
  );
};
