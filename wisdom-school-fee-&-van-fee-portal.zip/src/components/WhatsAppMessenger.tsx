import React, { useState } from 'react';
import { 
  MessageCircle, 
  Send, 
  CheckCircle2, 
  Copy, 
  Check, 
  Filter, 
  Smartphone, 
  ArrowRight, 
  RotateCcw, 
  Languages, 
  ExternalLink,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { Student, SchoolSettings } from '../types';
import { 
  formatIndianPhone, 
  generateFeeDueMessage, 
  generateVanNoticeMessage 
} from '../utils/whatsappHelper';

interface WhatsAppMessengerProps {
  students: Student[];
  settings: SchoolSettings;
  onOpenGpayModal: () => void;
}

export const WhatsAppMessenger: React.FC<WhatsAppMessengerProps> = ({
  students,
  settings,
  onOpenGpayModal,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [filterType, setFilterType] = useState<'due-all' | 'due-school' | 'due-van' | 'all'>('due-all');
  const [messageLanguage, setMessageLanguage] = useState<'en' | 'ta'>('en');
  const [activeTemplate, setActiveTemplate] = useState<'due-reminder' | 'van-notice' | 'custom'>('due-reminder');
  const [customText, setCustomText] = useState<string>('');
  
  // Dispatch Queue Tracking
  const [sentStatusMap, setSentStatusMap] = useState<Record<string, 'pending' | 'sent' | 'skipped'>>({});
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  // Filter students for queue
  const queueStudents = students.filter(s => {
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;

    const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
    const vanDue = s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0;

    if (filterType === 'due-all') {
      return schoolDue > 0 || vanDue > 0;
    }
    if (filterType === 'due-school') {
      return schoolDue > 0;
    }
    if (filterType === 'due-van') {
      return s.vanFees.usesVan && vanDue > 0;
    }
    return true;
  });

  const currentStudent = queueStudents[currentIndex] || queueStudents[0];

  const getPersonalizedMessage = (student: Student): string => {
    if (!student) return '';

    if (activeTemplate === 'van-notice') {
      return generateVanNoticeMessage(student, settings);
    }

    if (activeTemplate === 'custom' && customText.trim()) {
      const schoolDue = student.schoolFees.totalFee - student.schoolFees.paidAmount;
      const vanDue = student.vanFees.usesVan ? student.vanFees.termFee - student.vanFees.paidAmount : 0;
      return customText
        .replace(/{student_name}/g, student.name)
        .replace(/{admission_no}/g, student.admissionNo)
        .replace(/{class}/g, `${student.studentClass} - ${student.section}`)
        .replace(/{father_name}/g, student.fatherName || 'Parent')
        .replace(/{school_due}/g, `₹${schoolDue}`)
        .replace(/{van_due}/g, `₹${vanDue}`)
        .replace(/{total_due}/g, `₹${schoolDue + vanDue}`)
        .replace(/{gpay_number}/g, settings.gpayNumber)
        .replace(/{admin_name}/g, settings.adminName)
        .replace(/{principal_name}/g, settings.principalName)
        .replace(/{school_name}/g, settings.schoolName);
    }

    return generateFeeDueMessage(student, settings, messageLanguage);
  };

  const handleSendToStudent = (student: Student, index?: number) => {
    const text = getPersonalizedMessage(student);
    const formattedPhone = formatIndianPhone(student.parentPhone);
    const url = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(text)}`;

    window.open(url, '_blank');

    // Mark as sent
    setSentStatusMap(prev => ({ ...prev, [student.id]: 'sent' }));

    // Move to next student in queue if within active list
    if (typeof index === 'number' && index < queueStudents.length - 1) {
      setCurrentIndex(index + 1);
    }
  };

  const handleSkip = (studentId: string) => {
    setSentStatusMap(prev => ({ ...prev, [studentId]: 'skipped' }));
    if (currentIndex < queueStudents.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handleCopyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleResetQueue = () => {
    setSentStatusMap({});
    setCurrentIndex(0);
  };

  const totalQueue = queueStudents.length;
  const sentCount = Object.values(sentStatusMap).filter(v => v === 'sent').length;

  return (
    <div className="space-y-5">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                <MessageCircle className="w-5 h-5" />
              </span>
              <h2 className="text-lg font-bold text-slate-900">
                Automated WhatsApp Parent Messaging
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Automate 1-click WhatsApp payment reminders with GPay number ({settings.gpayNumber}), fee breakdowns, and UPI links.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleResetQueue}
              className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Queue</span>
            </button>
            <div className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
              Sent: {sentCount} / {totalQueue} Parents
            </div>
          </div>
        </div>

        {/* Filter & Template Selection Bar */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Class Filter */}
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Class:</span>
            <div className="flex gap-1 overflow-x-auto">
              {classesList.map((cls) => (
                <button
                  key={cls}
                  onClick={() => {
                    setSelectedClass(cls);
                    setCurrentIndex(0);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                    selectedClass === cls
                      ? 'bg-blue-900 text-white font-bold'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>
          </div>

          {/* Dues Type Selector */}
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Target Group:</span>
            <select
              value={filterType}
              onChange={(e) => {
                setFilterType(e.target.value as any);
                setCurrentIndex(0);
              }}
              className="border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:ring-2 focus:ring-emerald-500 focus:outline-none bg-white font-semibold"
            >
              <option value="due-all">All Pending Dues (School & Van)</option>
              <option value="due-school">School Fee Dues Only</option>
              <option value="due-van">Van Fee Dues Only</option>
              <option value="all">All Students</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Split: Left = Automated Dispatcher Stepper; Right = Template Selector & Customizer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Queue Dispatcher Stepper (7 Cols) */}
        <section className="lg:col-span-7 space-y-4">
          
          {/* Active Stepper Card */}
          {currentStudent ? (
            <div className="bg-white rounded-2xl shadow-sm border-2 border-emerald-300 p-5 space-y-4 relative overflow-hidden">
              <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-500 to-teal-600"></div>

              {/* Progress and Student Indicator */}
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  Queue Item {currentIndex + 1} of {totalQueue}
                </span>

                <span className="text-xs font-mono font-bold text-slate-500">
                  Adm: {currentStudent.admissionNo}
                </span>
              </div>

              {/* Student Summary */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 flex justify-between items-center">
                <div>
                  <h3 className="font-bold text-base text-slate-900 leading-tight">
                    {currentStudent.name}
                  </h3>
                  <p className="text-xs text-slate-600">
                    {currentStudent.studentClass} - Section {currentStudent.section} • Father: {currentStudent.fatherName}
                  </p>
                  <p className="text-xs font-mono text-emerald-700 mt-0.5">
                    WhatsApp: <strong>+91 {currentStudent.parentPhone}</strong>
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-[10px] uppercase font-semibold text-slate-500 block">
                    Outstanding Due
                  </span>
                  <span className="text-base font-extrabold font-mono text-rose-700">
                    ₹ {(
                      (currentStudent.schoolFees.totalFee - currentStudent.schoolFees.paidAmount) +
                      (currentStudent.vanFees.usesVan ? currentStudent.vanFees.termFee - currentStudent.vanFees.paidAmount : 0)
                    ).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              {/* Message Live Preview */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                    Personalized WhatsApp Message Preview
                  </label>
                  <button
                    onClick={() => handleCopyText(getPersonalizedMessage(currentStudent), currentStudent.id)}
                    className="text-[11px] text-slate-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
                  >
                    {copiedId === currentStudent.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-600" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Text</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-slate-900 text-emerald-400 p-3.5 rounded-xl font-mono text-xs whitespace-pre-wrap leading-relaxed max-h-56 overflow-y-auto border border-slate-800 shadow-inner">
                  {getPersonalizedMessage(currentStudent)}
                </div>
              </div>

              {/* Big Action Buttons */}
              <div className="flex flex-wrap gap-2 pt-2">
                {/* 1-Click Send on WhatsApp */}
                <button
                  onClick={() => handleSendToStudent(currentStudent, currentIndex)}
                  className="flex-1 py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs shadow-md transition flex items-center justify-center gap-2 hover:scale-[1.01]"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Launch WhatsApp Web / App & Send</span>
                </button>

                {/* Skip to Next */}
                <button
                  onClick={() => handleSkip(currentStudent.id)}
                  className="py-3 px-4 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl font-semibold text-xs transition flex items-center gap-1.5"
                >
                  <span>Skip</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              <div className="text-[11px] text-slate-500 flex justify-between items-center pt-1 border-t border-slate-100">
                <span>Direct link opens WhatsApp desktop or web</span>
                <span>GPay: {settings.gpayNumber} ({settings.adminName})</span>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 text-center text-slate-500 space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <p className="font-bold text-slate-800 text-sm">All messages in this queue have been dispatched!</p>
              <p className="text-xs text-slate-400">Change your class filter or reset the queue to review.</p>
              <button
                onClick={handleResetQueue}
                className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold"
              >
                Reset Queue
              </button>
            </div>
          )}

          {/* Queue List Table */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
            <h4 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-2">
              Dispatched Queue List ({queueStudents.length} Parents)
            </h4>

            <div className="space-y-1.5 max-h-64 overflow-y-auto text-xs pr-1">
              {queueStudents.map((st, idx) => {
                const status = sentStatusMap[st.id] || 'pending';
                const isCurrent = idx === currentIndex;

                return (
                  <div
                    key={st.id}
                    onClick={() => setCurrentIndex(idx)}
                    className={`p-2.5 rounded-xl border flex justify-between items-center cursor-pointer transition ${
                      isCurrent
                        ? 'border-emerald-500 bg-emerald-50/60 font-semibold'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <div>
                        <div className="text-slate-900 font-bold">{st.name}</div>
                        <div className="text-[10px] text-slate-500">
                          {st.studentClass} • {st.parentPhone}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {status === 'sent' && (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Check className="w-3 h-3" /> Sent
                        </span>
                      )}
                      {status === 'skipped' && (
                        <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                          Skipped
                        </span>
                      )}
                      {status === 'pending' && (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                          Pending
                        </span>
                      )}

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSendToStudent(st, idx);
                        }}
                        className="p-1 rounded-lg bg-emerald-600 text-white hover:bg-emerald-500"
                        title="Send now"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </section>

        {/* RIGHT COLUMN: Message Templates & Customizer (5 Cols) */}
        <section className="lg:col-span-5 space-y-4">
          
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <Languages className="w-4 h-4 text-blue-600" />
              Template & Language Configuration
            </h3>

            {/* Language Switch */}
            <div className="flex rounded-xl bg-slate-100 p-1 text-xs">
              <button
                onClick={() => setMessageLanguage('en')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition ${
                  messageLanguage === 'en'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                English Template
              </button>
              <button
                onClick={() => setMessageLanguage('ta')}
                className={`flex-1 py-1.5 rounded-lg font-bold transition ${
                  messageLanguage === 'ta'
                    ? 'bg-white text-emerald-800 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                தமிழ் (Tamil Message)
              </button>
            </div>

            {/* Template Type Choice */}
            <div className="space-y-2 text-xs">
              <label className="block font-semibold text-slate-700">Message Type</label>
              
              <button
                type="button"
                onClick={() => setActiveTemplate('due-reminder')}
                className={`w-full p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                  activeTemplate === 'due-reminder'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold">General Fee Due Reminder</div>
                  <div className="text-[10px] text-slate-500">Includes school fee, van fee & GPay 917659319</div>
                </div>
                {activeTemplate === 'due-reminder' && <Check className="w-4 h-4 text-blue-600" />}
              </button>

              <button
                type="button"
                onClick={() => setActiveTemplate('van-notice')}
                className={`w-full p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                  activeTemplate === 'van-notice'
                    ? 'border-amber-600 bg-amber-50 text-amber-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold">Van / Transport Fee Notice</div>
                  <div className="text-[10px] text-slate-500">Focuses on route, pickup stop & van dues</div>
                </div>
                {activeTemplate === 'van-notice' && <Check className="w-4 h-4 text-amber-600" />}
              </button>

              <button
                type="button"
                onClick={() => setActiveTemplate('custom')}
                className={`w-full p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                  activeTemplate === 'custom'
                    ? 'border-purple-600 bg-purple-50 text-purple-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <div className="font-bold">Custom Message Composer</div>
                  <div className="text-[10px] text-slate-500">Write your own text with dynamic variables</div>
                </div>
                {activeTemplate === 'custom' && <Check className="w-4 h-4 text-purple-600" />}
              </button>
            </div>

            {/* Custom Template Editor */}
            {activeTemplate === 'custom' && (
              <div className="space-y-2 text-xs">
                <label className="block font-semibold text-slate-700">Custom Message Template</label>
                <textarea
                  rows={6}
                  value={customText}
                  onChange={(e) => setCustomText(e.target.value)}
                  placeholder={`Dear {father_name}, please pay {total_due} for {student_name} ({class}) via GPay {gpay_number} to Admin {admin_name}.`}
                  className="w-full border border-slate-300 rounded-xl p-2.5 text-xs font-mono focus:ring-2 focus:ring-purple-600 focus:outline-none"
                />
                <div className="text-[10px] text-slate-500">
                  Tags: <code>{'{student_name}'}</code>, <code>{'{total_due}'}</code>, <code>{'{gpay_number}'}</code>, <code>{'{class}'}</code>
                </div>
              </div>
            )}

            {/* Verified Payment Info Note */}
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs space-y-1">
              <div className="flex items-center gap-1.5 text-emerald-900 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Default GPay Dispatch Settings</span>
              </div>
              <p className="text-emerald-800 text-[11px]">
                Parents will be instructed to make payment directly to:
              </p>
              <div className="font-mono text-[11px] text-emerald-950 font-bold">
                • GPay Mobile: {settings.gpayNumber}
                <br />
                • Admin Payee: {settings.adminName}
                <br />
                • Principal: {settings.principalName}
              </div>
            </div>

          </div>

        </section>

      </div>
    </div>
  );
};
