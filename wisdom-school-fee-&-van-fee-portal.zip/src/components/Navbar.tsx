import React from 'react';
import { 
  Printer, 
  Users, 
  FileDown, 
  MessageCircle, 
  Bus, 
  Settings, 
  QrCode,
  GraduationCap,
  ShieldAlert,
  Contact,
  BookOpen
} from 'lucide-react';
import { SchoolSettings } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  settings: SchoolSettings;
  onOpenGpayModal: () => void;
  onOpenSettings: () => void;
  onQuickPrint: () => void;
  pendingDuesCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  settings,
  onOpenGpayModal,
  onOpenSettings,
  onQuickPrint,
  pendingDuesCount = 0,
}) => {
  const navItems = [
    { id: 'receipt', label: 'Receipt Maker', icon: Printer, badge: 'Dual A4' },
    { 
      id: 'dues', 
      label: 'Pending Dues', 
      icon: ShieldAlert, 
      badge: pendingDuesCount > 0 ? `${pendingDuesCount} Unpaid` : null,
      highlight: true
    },
    { id: 'fee-cards', label: 'Tuition & Van Cards', icon: BookOpen, badge: 'Passbook' },
    { id: 'id-cards', label: 'Student ID Cards', icon: Contact, badge: 'CR-80' },
    { id: 'students', label: 'Students (LKG - 5th)', icon: Users, badge: null },
    { id: 'bulk-pdf', label: 'Bulk PDF Center', icon: FileDown, badge: 'School & Van' },
    { id: 'whatsapp', label: 'WhatsApp Messaging', icon: MessageCircle, badge: 'Automated' },
    { id: 'van', label: 'Van / Transport Fees', icon: Bus, badge: null },
  ];

  return (
    <header className="no-print bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white shadow-xl sticky top-0 z-40 border-b border-blue-900/60">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 pt-3 pb-2 flex flex-wrap justify-between items-center gap-3">
        {/* School Logo & Title */}
        <div className="flex items-center gap-3">
          {settings.logoUrl ? (
            <img
              src={settings.logoUrl}
              alt="School Logo"
              className="w-12 h-12 rounded-xl object-contain bg-white p-1 border border-amber-400/40 shadow-md"
            />
          ) : (
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 p-0.5 shadow-md flex items-center justify-center text-slate-950">
              <GraduationCap className="w-7 h-7" />
            </div>
          )}
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-header text-lg md:text-xl font-bold tracking-tight text-white leading-tight">
                {settings.schoolName}
              </h1>
              <span className="hidden sm:inline-block text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-blue-500/20 text-blue-200 border border-blue-400/30">
                LKG TO 5TH STD
              </span>
            </div>
            <p className="text-xs text-blue-200/90 font-medium">
              Essur, Acharapakkam Taluk • <span className="text-amber-300 font-semibold">Admin: {settings.adminName}</span> • <span className="text-emerald-300 font-semibold">Principal: {settings.principalName}</span>
            </p>
          </div>
        </div>

        {/* Action Badges & GPay Highlight */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* GPAY Button */}
          <button
            onClick={onOpenGpayModal}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-600 border border-emerald-400/50 text-white font-semibold text-xs transition shadow-sm hover:scale-[1.02] active:scale-[0.98]"
            title={`View GPay Details & QR Code (${settings.upiId})`}
          >
            <div className="w-5 h-5 rounded-full bg-white text-emerald-700 flex items-center justify-center font-bold text-[10px]">
              G
            </div>
            <div className="text-left leading-tight">
              <span className="block font-bold text-white">GPAY: {settings.gpayNumber}</span>
              <span className="text-[9px] text-emerald-200 font-mono hidden md:block">{settings.upiId}</span>
            </div>
            <QrCode className="w-3.5 h-3.5 text-emerald-200" />
          </button>

          {/* Quick Print A4 Dual Copy */}
          <button
            onClick={onQuickPrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-sm hover:scale-[1.02]"
          >
            <Printer className="w-4 h-4" />
            <span>PRINT RECEIPT</span>
          </button>

          {/* Settings */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
            title="School Settings & Administration"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Bar Tabs */}
      <div className="max-w-7xl mx-auto px-4">
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-1 border-t border-blue-900/40 text-xs">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-t-lg font-medium transition whitespace-nowrap border-b-2 ${
                  isActive
                    ? 'bg-white/10 text-white border-amber-400 shadow-inner'
                    : 'text-slate-300 hover:text-white hover:bg-white/5 border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                    isActive ? 'bg-amber-400/20 text-amber-300' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
