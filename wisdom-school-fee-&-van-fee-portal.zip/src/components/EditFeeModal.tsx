import React, { useState, useEffect } from 'react';
import { X, Save, IndianRupee, Bus, GraduationCap, CheckCircle2, AlertCircle, QrCode } from 'lucide-react';
import { Student, SchoolSettings, PaymentStatus } from '../types';

interface EditFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  onSave: (updatedStudent: Student) => void;
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
  settings: SchoolSettings;
}

export const EditFeeModal: React.FC<EditFeeModalProps> = ({
  isOpen,
  onClose,
  student,
  onSave,
  onOpenGpayModal,
  settings,
}) => {
  // Fee breakdown state
  const [term, setTerm] = useState<string>('Term 1');
  const [admissionFee, setAdmissionFee] = useState<number>(0);
  const [tuitionFee, setTuitionFee] = useState<number>(0);
  const [examFee, setExamFee] = useState<number>(0);
  const [booksFee, setBooksFee] = useState<number>(0);
  const [uniformFee, setUniformFee] = useState<number>(0);
  const [otherFee, setOtherFee] = useState<number>(0);
  const [schoolPaid, setSchoolPaid] = useState<number>(0);

  // Van fee state
  const [usesVan, setUsesVan] = useState<boolean>(false);
  const [vanRoute, setVanRoute] = useState<string>('');
  const [pickupPoint, setPickupPoint] = useState<string>('');
  const [vanTermFee, setVanTermFee] = useState<number>(0);
  const [vanPaid, setVanPaid] = useState<number>(0);
  const [remarks, setRemarks] = useState<string>('');

  useEffect(() => {
    if (student) {
      const b = student.schoolFees.feeBreakdown;
      setTerm(student.schoolFees.term || 'Term 1');
      setAdmissionFee(b.admissionFee || 0);
      setTuitionFee(b.tuitionFee || 0);
      setExamFee(b.examFee || 0);
      setBooksFee(b.booksStationeryFee || 0);
      setUniformFee(b.uniformActivityFee || 0);
      setOtherFee(b.otherFee || 0);
      setSchoolPaid(student.schoolFees.paidAmount || 0);

      setUsesVan(student.vanFees.usesVan || false);
      setVanRoute(student.vanFees.route || 'Route 1: Essur - Thozhupedu');
      setPickupPoint(student.vanFees.pickupPoint || 'Essur Bus Stand');
      setVanTermFee(student.vanFees.termFee || 0);
      setVanPaid(student.vanFees.paidAmount || 0);
      setRemarks(student.remarks || '');
    }
  }, [student]);

  if (!isOpen || !student) return null;

  const totalSchoolFee = admissionFee + tuitionFee + examFee + booksFee + uniformFee + otherFee;
  const schoolDue = Math.max(0, totalSchoolFee - schoolPaid);
  const vanDue = usesVan ? Math.max(0, vanTermFee - vanPaid) : 0;
  const grandTotalDue = schoolDue + vanDue;

  const handleQuickPayFullSchool = () => {
    setSchoolPaid(totalSchoolFee);
  };

  const handleQuickPayFullVan = () => {
    setVanPaid(vanTermFee);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    let schoolStatus: PaymentStatus = 'Pending';
    if (schoolPaid >= totalSchoolFee && totalSchoolFee > 0) {
      schoolStatus = 'Paid';
    } else if (schoolPaid > 0) {
      schoolStatus = 'Partial';
    }

    let vanStatus: PaymentStatus = 'Pending';
    if (!usesVan || (vanPaid >= vanTermFee && vanTermFee > 0)) {
      vanStatus = 'Paid';
    } else if (vanPaid > 0) {
      vanStatus = 'Partial';
    }

    const updatedStudent: Student = {
      ...student,
      schoolFees: {
        ...student.schoolFees,
        term,
        totalFee: totalSchoolFee,
        paidAmount: schoolPaid,
        status: schoolStatus,
        lastPaymentDate: schoolPaid > 0 ? new Date().toISOString().split('T')[0] : student.schoolFees.lastPaymentDate,
        feeBreakdown: {
          admissionFee,
          tuitionFee,
          examFee,
          booksStationeryFee: booksFee,
          uniformActivityFee: uniformFee,
          otherFee,
        },
      },
      vanFees: {
        usesVan,
        route: usesVan ? vanRoute : 'None',
        pickupPoint: usesVan ? pickupPoint : 'Walking',
        termFee: usesVan ? vanTermFee : 0,
        paidAmount: usesVan ? vanPaid : 0,
        vanStatus,
        lastPaymentDate: vanPaid > 0 ? new Date().toISOString().split('T')[0] : student.vanFees.lastPaymentDate,
      },
      remarks,
    };

    onSave(updatedStudent);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 p-4 text-white flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/10 border border-white/20">
              <IndianRupee className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">
                Edit Fees: {student.name}
              </h3>
              <p className="text-xs text-blue-200">
                {student.studentClass} - Section {student.section} • Adm No: <span className="font-mono font-bold text-white">{student.admissionNo}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-blue-200 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4 text-xs">
          
          {/* Summary Banner */}
          <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-slate-50 border border-slate-200">
            <div>
              <span className="text-[10px] text-slate-500 font-bold uppercase block">School Fee Due</span>
              <span className={`text-base font-mono font-extrabold ${schoolDue > 0 ? 'text-rose-700' : 'text-emerald-700'}`}>
                ₹ {schoolDue.toLocaleString('en-IN')}
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Van Fee Due</span>
              <span className={`text-base font-mono font-extrabold ${vanDue > 0 ? 'text-amber-800' : 'text-emerald-700'}`}>
                {usesVan ? `₹ ${vanDue.toLocaleString('en-IN')}` : 'No Van'}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Total Outstanding Due</span>
              <span className="text-base font-mono font-extrabold text-rose-700">
                ₹ {grandTotalDue.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* School Fees Section */}
          <div className="space-y-3">
            <div className="flex justify-between items-center border-b pb-1">
              <h4 className="font-bold uppercase tracking-wider text-blue-900 text-[11px] flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-blue-600" />
                <span>School Fees Particulars</span>
              </h4>
              <div className="flex items-center gap-2">
                <label className="text-[10px] font-semibold text-slate-600">Fee Term:</label>
                <select
                  value={term}
                  onChange={(e) => setTerm(e.target.value)}
                  className="p-1 border border-slate-300 rounded text-xs bg-white font-medium"
                >
                  <option value="Term 1">Term 1</option>
                  <option value="Term 2">Term 2</option>
                  <option value="Term 3">Term 3</option>
                  <option value="Term 1 & 2">Term 1 & 2</option>
                  <option value="Full Year">Full Year</option>
                  <option value="Monthly">Monthly</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Admission Fee (₹)</label>
                <input
                  type="number"
                  value={admissionFee || ''}
                  onChange={(e) => setAdmissionFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tuition Fee (₹) *</label>
                <input
                  type="number"
                  value={tuitionFee || ''}
                  onChange={(e) => setTuitionFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 bg-blue-50/50"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Exam Fee (₹)</label>
                <input
                  type="number"
                  value={examFee || ''}
                  onChange={(e) => setExamFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Books & Stationery (₹)</label>
                <input
                  type="number"
                  value={booksFee || ''}
                  onChange={(e) => setBooksFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Uniform & Activity (₹)</label>
                <input
                  type="number"
                  value={uniformFee || ''}
                  onChange={(e) => setUniformFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Other / Miscellaneous (₹)</label>
                <input
                  type="number"
                  value={otherFee || ''}
                  onChange={(e) => setOtherFee(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800"
                />
              </div>
            </div>

            {/* School Fee Total and Paid Adjustment */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-blue-50/60 rounded-xl border border-blue-200">
              <div>
                <label className="block font-bold text-slate-800 mb-1">Total School Fee</label>
                <div className="font-mono font-extrabold text-sm text-blue-950">
                  ₹ {totalSchoolFee.toLocaleString('en-IN')}
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="font-bold text-emerald-800">School Fee Paid (₹)</label>
                  <button
                    type="button"
                    onClick={handleQuickPayFullSchool}
                    className="text-[10px] text-emerald-700 hover:underline font-semibold"
                  >
                    Set Full Paid
                  </button>
                </div>
                <input
                  type="number"
                  value={schoolPaid || ''}
                  onChange={(e) => setSchoolPaid(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="w-full border border-emerald-400 bg-white rounded-lg p-2 font-mono font-bold text-emerald-900"
                />
              </div>
            </div>
          </div>

          {/* Van / Transport Fee Section */}
          <div className="space-y-3 pt-2">
            <div className="flex justify-between items-center border-b pb-1">
              <h4 className="font-bold uppercase tracking-wider text-amber-800 text-[11px] flex items-center gap-1.5">
                <Bus className="w-4 h-4 text-amber-600" />
                <span>Van & Transport Fee</span>
              </h4>
              <label className="flex items-center gap-1.5 cursor-pointer text-xs font-semibold text-slate-700">
                <input
                  type="checkbox"
                  checked={usesVan}
                  onChange={(e) => setUsesVan(e.target.checked)}
                  className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                />
                <span>Uses School Van</span>
              </label>
            </div>

            {usesVan && (
              <div className="space-y-3 p-3 bg-amber-50/50 rounded-xl border border-amber-200">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Van Route</label>
                    <input
                      type="text"
                      value={vanRoute}
                      onChange={(e) => setVanRoute(e.target.value)}
                      placeholder="e.g. Route 1: Essur - Thozhupedu"
                      className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Pickup / Drop Point</label>
                    <input
                      type="text"
                      value={pickupPoint}
                      onChange={(e) => setPickupPoint(e.target.value)}
                      placeholder="e.g. Essur Temple Stop"
                      className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Van Term Fee (₹)</label>
                    <input
                      type="number"
                      value={vanTermFee || ''}
                      onChange={(e) => setVanTermFee(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold text-amber-950 bg-white"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="font-bold text-emerald-800">Van Fee Paid (₹)</label>
                      <button
                        type="button"
                        onClick={handleQuickPayFullVan}
                        className="text-[10px] text-emerald-700 hover:underline font-semibold"
                      >
                        Set Full Paid
                      </button>
                    </div>
                    <input
                      type="number"
                      value={vanPaid || ''}
                      onChange={(e) => setVanPaid(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full border border-emerald-400 bg-white rounded-lg p-2 font-mono font-bold text-emerald-900"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Remarks */}
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Fee Notes / Remarks</label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Fee concession granted / Next installment on 25th"
              className="w-full border border-slate-300 rounded-lg p-2 text-slate-800"
            />
          </div>

          {/* Actions Footer */}
          <div className="pt-3 border-t flex flex-wrap justify-between items-center gap-2">
            {grandTotalDue > 0 && (
              <button
                type="button"
                onClick={() => onOpenGpayModal(grandTotalDue, student.name)}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold text-xs flex items-center gap-1.5 shadow-sm transition"
              >
                <QrCode className="w-4 h-4" />
                <span>Show GPay QR (₹{grandTotalDue.toLocaleString('en-IN')})</span>
              </button>
            )}

            <div className="flex items-center gap-2 ml-auto">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold text-slate-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-700 hover:bg-blue-600 text-white rounded-xl font-bold shadow-sm flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Save Fee Updates</span>
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
