import React, { useState, useEffect } from 'react';
import { 
  Printer, 
  RotateCcw, 
  Bookmark, 
  MessageCircle, 
  FileDown, 
  QrCode, 
  UserCheck, 
  Scissors, 
  GraduationCap
} from 'lucide-react';
import { Student, SchoolSettings, SchoolClass, Section, PaymentMode, FeeReceipt } from '../types';
import { numberToWordsIndian } from '../utils/numberToWords';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';
import { generatePaymentReceiptMessage } from '../utils/whatsappHelper';

interface ReceiptGeneratorProps {
  students: Student[];
  settings: SchoolSettings;
  onSaveReceipt: (receipt: FeeReceipt, updatedStudent?: Student) => void;
  recentReceipts: FeeReceipt[];
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
  selectedStudent?: Student | null;
  onEditFees?: (student: Student) => void;
}

export const ReceiptGenerator: React.FC<ReceiptGeneratorProps> = ({
  students,
  settings,
  onSaveReceipt,
  recentReceipts,
  onOpenGpayModal,
  selectedStudent,
  onEditFees,
}) => {
  // Form State
  const [receiptNo, setReceiptNo] = useState<string>('');
  const [receiptDate, setReceiptDate] = useState<string>('');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [studentName, setStudentName] = useState<string>('S. Vignesh');
  const [rollNo, setRollNo] = useState<string>('W2026-001');
  const [studentClass, setStudentClass] = useState<SchoolClass>('LKG');
  const [section, setSection] = useState<Section>('A');
  const [academicYear, setAcademicYear] = useState<string>(settings.currentAcademicYear);
  const [termName, setTermName] = useState<string>('Term I');

  // Fee items
  const [feeAdmission, setFeeAdmission] = useState<number>(0);
  const [feeTuition, setFeeTuition] = useState<number>(4500);
  const [feeExam, setFeeExam] = useState<number>(1000);
  const [feeBooks, setFeeBooks] = useState<number>(1200);
  const [feeActivity, setFeeActivity] = useState<number>(800);
  const [feeVans, setFeeVans] = useState<number>(0);
  const [feeOther, setFeeOther] = useState<number>(0);

  // Payment
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('GPay / UPI');
  const [txnRef, setTxnRef] = useState<string>('');
  const [parentPhone, setParentPhone] = useState<string>('9176593190');

  // Dynamic QR Code Data URL for receipt print
  const [qrSrc, setQrSrc] = useState<string>('');

  // Total
  const grandTotal =
    feeAdmission + feeTuition + feeExam + feeBooks + feeActivity + feeVans + feeOther;

  // Initialize defaults
  useEffect(() => {
    generateNewReceiptNo();
    const today = new Date().toISOString().split('T')[0];
    setReceiptDate(today);
  }, []);

  // Update dynamic QR code when total or student name changes
  useEffect(() => {
    const upiUri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
      amount: grandTotal > 0 ? grandTotal : undefined,
      note: `Fee ${rollNo} ${studentName}`,
    });
    generateQrDataUrl(upiUri).then(src => setQrSrc(src));
  }, [grandTotal, rollNo, studentName, settings]);

  // Auto-populate when selectedStudent prop changes
  useEffect(() => {
    if (selectedStudent) {
      handleSelectStudent(selectedStudent.id);
    }
  }, [selectedStudent]);

  const generateNewReceiptNo = () => {
    const rand = Math.floor(1000 + Math.random() * 9000);
    setReceiptNo(`WNS-2026-${rand}`);
  };

  // Handle student quick select from directory
  const handleSelectStudent = (studentId: string) => {
    setSelectedStudentId(studentId);
    if (!studentId) return;

    const std = students.find(s => s.id === studentId);
    if (!std) return;

    setStudentName(std.name);
    setRollNo(std.admissionNo);
    setStudentClass(std.studentClass);
    setSection(std.section);
    setParentPhone(std.parentPhone);

    // Populate fees
    const bk = std.schoolFees.feeBreakdown;
    setFeeAdmission(bk.admissionFee || 0);
    setFeeTuition(bk.tuitionFee || 0);
    setFeeExam(bk.examFee || 0);
    setFeeBooks(bk.booksStationeryFee || 0);
    setFeeActivity(bk.uniformActivityFee || 0);
    setFeeOther(bk.otherFee || 0);
    setFeeVans(std.vanFees.usesVan ? std.vanFees.termFee : 0);
  };

  const handleReset = () => {
    generateNewReceiptNo();
    setSelectedStudentId('');
    setStudentName('');
    setRollNo('');
    setFeeAdmission(0);
    setFeeTuition(0);
    setFeeExam(0);
    setFeeBooks(0);
    setFeeActivity(0);
    setFeeVans(0);
    setFeeOther(0);
    setTxnRef('');
  };

  const handleSave = () => {
    if (!studentName.trim()) {
      alert('Please enter student name.');
      return;
    }

    const items = [
      { description: 'Admission Fee', amount: feeAdmission },
      { description: `Tuition Fee (${termName})`, amount: feeTuition },
      { description: 'Examination & Term Fee', amount: feeExam },
      { description: 'Books, Notebooks & Stationery', amount: feeBooks },
      { description: 'Uniform & Activities', amount: feeActivity },
      { description: 'Transport / Van Fee', amount: feeVans },
      { description: 'Miscellaneous Charges', amount: feeOther },
    ].filter(i => i.amount > 0);

    const receipt: FeeReceipt = {
      id: `rcpt-${Date.now()}`,
      receiptNo,
      date: receiptDate,
      studentId: selectedStudentId || 'manual',
      studentName,
      admissionNo: rollNo,
      studentClass,
      section,
      academicYear,
      feeType: feeVans > 0 && items.length > 1 ? 'Combined' : feeVans > 0 ? 'Van Fee' : 'School Fee',
      term: termName,
      items,
      totalAmount: grandTotal,
      paidAmount: grandTotal,
      balanceAmount: 0,
      paymentMode,
      transactionRef: txnRef || (paymentMode.includes('GPay') ? `GPAY-${settings.gpayNumber}` : undefined),
      receivedBy: `${settings.adminName} & ${settings.principalName}`,
    };

    onSaveReceipt(receipt);
    alert(`Receipt ${receiptNo} saved successfully!`);
    generateNewReceiptNo();
  };

  const handleSendWhatsAppReceipt = () => {
    if (!parentPhone) {
      alert('Please provide parent mobile number.');
      return;
    }

    const dummyStudent: Student = {
      id: selectedStudentId || 'temp',
      admissionNo: rollNo,
      name: studentName,
      fatherName: 'Parent',
      studentClass,
      section,
      gender: 'Male',
      parentPhone,
      whatsappPhone: parentPhone,
      address: 'Essur',
      academicYear,
      schoolFees: {
        totalFee: grandTotal,
        paidAmount: grandTotal,
        term: termName,
        feeBreakdown: {
          admissionFee: feeAdmission,
          tuitionFee: feeTuition,
          examFee: feeExam,
          booksStationeryFee: feeBooks,
          uniformActivityFee: feeActivity,
          otherFee: feeOther,
        },
        status: 'Paid',
      },
      vanFees: {
        usesVan: feeVans > 0,
        route: 'Route 1',
        pickupPoint: 'Stop',
        termFee: feeVans,
        paidAmount: feeVans,
        vanStatus: 'Paid',
      },
    };

    const text = generatePaymentReceiptMessage(
      dummyStudent,
      receiptNo,
      grandTotal,
      feeVans > 0 ? 'School & Van Fee' : 'School Fee',
      settings
    );

    const clean = parentPhone.replace(/\D/g, '');
    const phoneWithPrefix = clean.length === 10 ? `91${clean}` : clean;
    const url = `https://wa.me/${phoneWithPrefix}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Filter active fee items for rendering receipt table
  const activeItems = [
    { name: 'Admission Fee', amount: feeAdmission },
    { name: `Tuition Fee (${termName})`, amount: feeTuition },
    { name: 'Examination & Term Fee', amount: feeExam },
    { name: 'Books, Notebooks & Stationery', amount: feeBooks },
    { name: 'Uniform & Daycare / Activities', amount: feeActivity },
    { name: 'Transport / School Van Fee', amount: feeVans },
    { name: 'Miscellaneous & Other Fee', amount: feeOther },
  ].filter(i => i.amount > 0);

  return (
    <div className="w-full">
      {/* Screen View: Grid with Form on Left and Live Preview on Right */}
      <div className="no-print grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Input Form */}
        <section className="lg:col-span-5 space-y-4">
          
          {/* Quick Student Selection */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <UserCheck className="w-4 h-4 text-blue-600" />
                Select Existing Student (LKG - 5th Std)
              </span>
              <span className="text-[10px] text-blue-600 font-normal">Autofill details</span>
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => handleSelectStudent(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none bg-slate-50"
            >
              <option value="">-- Or enter custom student info below --</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.studentClass} - {s.section}) • Roll: {s.admissionNo}
                </option>
              ))}
            </select>
          </div>

          {/* Student Info Card */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h2 className="font-bold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                <GraduationCap className="w-4 h-4 text-blue-600" />
                Student & Receipt Info
              </h2>
              <span className="text-[10px] bg-blue-50 text-blue-700 font-semibold px-2 py-0.5 rounded border border-blue-100">
                Step 1
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-600 mb-1">Receipt No *</label>
                <div className="flex gap-1">
                  <input
                    type="text"
                    value={receiptNo}
                    onChange={(e) => setReceiptNo(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 font-mono font-bold text-slate-900 bg-slate-50"
                  />
                  <button
                    onClick={generateNewReceiptNo}
                    title="Generate new number"
                    className="p-2 border border-slate-300 rounded-lg hover:bg-slate-100 text-slate-600"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">Receipt Date *</label>
                <input
                  type="date"
                  value={receiptDate}
                  onChange={(e) => setReceiptDate(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div className="col-span-2">
                <label className="block font-semibold text-slate-600 mb-1">Student Name *</label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  placeholder="e.g. S. Vignesh"
                  className="w-full border border-slate-300 rounded-lg p-2 font-semibold text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">Roll / Adm No *</label>
                <input
                  type="text"
                  value={rollNo}
                  onChange={(e) => setRollNo(e.target.value)}
                  placeholder="e.g. W2026-001"
                  className="w-full border border-slate-300 rounded-lg p-2 uppercase font-mono font-semibold focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">Standard / Class *</label>
                <select
                  value={studentClass}
                  onChange={(e) => setStudentClass(e.target.value as SchoolClass)}
                  className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-600 focus:outline-none font-semibold text-slate-800"
                >
                  <option value="Pre-KG">Pre-KG</option>
                  <option value="LKG">LKG</option>
                  <option value="UKG">UKG</option>
                  <option value="1st Standard">1st Standard</option>
                  <option value="2nd Standard">2nd Standard</option>
                  <option value="3rd Standard">3rd Standard</option>
                  <option value="4th Standard">4th Standard</option>
                  <option value="5th Standard">5th Standard</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">Section</label>
                <select
                  value={section}
                  onChange={(e) => setSection(e.target.value as Section)}
                  className="w-full border border-slate-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                >
                  <option value="A">Section A</option>
                  <option value="B">Section B</option>
                  <option value="C">Section C</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-600 mb-1">Parent WhatsApp No</label>
                <input
                  type="text"
                  value={parentPhone}
                  onChange={(e) => setParentPhone(e.target.value)}
                  placeholder="e.g. 9176593190"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Fee Particulars Breakup */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h2 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                Fee Particulars Breakup (₹)
              </h2>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 font-semibold px-2 py-0.5 rounded border border-emerald-100">
                Step 2
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="grid grid-cols-12 gap-2 items-center">
                <label className="col-span-7 font-medium text-slate-700">1. Admission Fee</label>
                <input
                  type="number"
                  value={feeAdmission || ''}
                  onChange={(e) => setFeeAdmission(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center">
                <div className="col-span-7">
                  <label className="font-medium text-slate-700 block">2. Tuition Fee</label>
                  <select
                    value={termName}
                    onChange={(e) => setTermName(e.target.value)}
                    className="text-[10px] text-slate-500 border border-slate-200 rounded p-0.5 w-full mt-0.5"
                  >
                    <option value="Term I">Term I</option>
                    <option value="Term II">Term II</option>
                    <option value="Term III">Term III</option>
                    <option value="Full Year">Full Year</option>
                    <option value="Monthly">Monthly</option>
                  </select>
                </div>
                <input
                  type="number"
                  value={feeTuition || ''}
                  onChange={(e) => setFeeTuition(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono font-semibold"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center">
                <label className="col-span-7 font-medium text-slate-700">3. Examination Fee</label>
                <input
                  type="number"
                  value={feeExam || ''}
                  onChange={(e) => setFeeExam(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center">
                <label className="col-span-7 font-medium text-slate-700">4. Books, Notebooks & Stationery</label>
                <input
                  type="number"
                  value={feeBooks || ''}
                  onChange={(e) => setFeeBooks(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center">
                <label className="col-span-7 font-medium text-slate-700">5. Uniform & Activity</label>
                <input
                  type="number"
                  value={feeActivity || ''}
                  onChange={(e) => setFeeActivity(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center bg-amber-50/60 p-1 rounded">
                <label className="col-span-7 font-bold text-amber-900 flex items-center gap-1">
                  <span>🚌 6. Van / Transport Fee</span>
                </label>
                <input
                  type="number"
                  value={feeVans || ''}
                  onChange={(e) => setFeeVans(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-amber-300 rounded-lg p-1.5 text-right font-mono font-bold text-amber-900 bg-white"
                />
              </div>

              <div className="grid grid-cols-12 gap-2 items-center">
                <label className="col-span-7 font-medium text-slate-700">7. Miscellaneous Fee</label>
                <input
                  type="number"
                  value={feeOther || ''}
                  onChange={(e) => setFeeOther(parseFloat(e.target.value) || 0)}
                  placeholder="0"
                  className="col-span-5 border border-slate-300 rounded-lg p-1.5 text-right font-mono"
                />
              </div>

              {/* Total Row */}
              <div className="grid grid-cols-12 gap-2 items-center pt-2.5 border-t border-slate-200">
                <span className="col-span-7 font-bold text-slate-900 text-sm">TOTAL AMOUNT</span>
                <div className="col-span-5 text-right font-mono font-extrabold text-emerald-700 text-base">
                  ₹ {grandTotal.toLocaleString('en-IN')}
                </div>
              </div>
            </div>
          </div>

          {/* Payment Mode Card */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 space-y-3">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h2 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
                Payment Mode & GPay ({settings.gpayNumber})
              </h2>
              <span className="text-[10px] bg-indigo-50 text-indigo-700 font-semibold px-2 py-0.5 rounded border border-indigo-100">
                Step 3
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setPaymentMode('GPay / UPI')}
                className={`p-2 rounded-lg border text-center transition flex flex-col items-center gap-1 ${
                  paymentMode === 'GPay / UPI'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span className="w-5 h-5 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-[10px]">
                  G
                </span>
                <span>GPay / UPI</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMode('Cash')}
                className={`p-2 rounded-lg border text-center transition flex flex-col items-center gap-1 ${
                  paymentMode === 'Cash'
                    ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span className="text-base">💵</span>
                <span>Cash</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMode('Bank / Cheque')}
                className={`p-2 rounded-lg border text-center transition flex flex-col items-center gap-1 ${
                  paymentMode === 'Bank / Cheque'
                    ? 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <span className="text-base">🏦</span>
                <span>Bank / Chq</span>
              </button>
            </div>

            <div className="text-xs">
              <label className="block font-semibold text-slate-600 mb-1">
                Transaction Ref / GPay Ref / Remarks
              </label>
              <input
                type="text"
                value={txnRef}
                onChange={(e) => setTxnRef(e.target.value)}
                placeholder="e.g. GPAY-917659319-9021 or Cash"
                className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-800 focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            {/* Quick Action Buttons */}
            <div className="pt-2 flex flex-wrap gap-2 text-xs">
              <button
                onClick={handleSave}
                className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-sm transition flex items-center justify-center gap-1.5"
              >
                <Bookmark className="w-4 h-4" />
                <span>Save Record</span>
              </button>
              <button
                onClick={handleSendWhatsAppReceipt}
                className="py-2 px-3 bg-teal-600 hover:bg-teal-500 text-white font-semibold rounded-lg shadow-sm transition flex items-center justify-center gap-1.5"
                title="Send receipt acknowledgment directly to parent's WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
                <span>WhatsApp Receipt</span>
              </button>
              <button
                onClick={handleReset}
                className="py-2 px-2.5 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg transition"
                title="Reset form"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Recent Receipts Saved */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2">
              Recent Receipts Saved
            </h3>
            {recentReceipts.length === 0 ? (
              <p className="text-xs text-slate-400 italic text-center py-2">
                No receipts saved in current session yet.
              </p>
            ) : (
              <div className="space-y-1.5 max-h-40 overflow-y-auto text-xs pr-1">
                {recentReceipts.slice(0, 6).map((rc) => (
                  <div
                    key={rc.id}
                    className="p-2 rounded-lg border border-slate-200 hover:bg-slate-50 flex justify-between items-center transition"
                  >
                    <div>
                      <p className="font-bold text-slate-800">{rc.studentName}</p>
                      <p className="text-[10px] text-slate-500 font-mono">
                        {rc.receiptNo} • {rc.studentClass} ({rc.date})
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-emerald-700">
                        ₹ {rc.paidAmount.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </section>

        {/* RIGHT COLUMN: Live Print Preview (A4 Dual-Copy) */}
        <section className="lg:col-span-7 bg-slate-200/90 rounded-2xl p-4 border border-slate-300 flex flex-col items-center">
          
          {/* Preview Bar Actions */}
          <div className="w-full flex justify-between items-center mb-3 px-1">
            <div className="flex items-center gap-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Official A4 Dual-Copy Print Preview
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onOpenGpayModal(grandTotal, studentName)}
                className="text-xs font-semibold px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-300 rounded text-slate-700 flex items-center gap-1 shadow-sm"
              >
                <QrCode className="w-3.5 h-3.5 text-emerald-600" />
                <span>GPay QR</span>
              </button>
              <button
                onClick={() => window.print()}
                className="text-xs font-bold px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded shadow flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>PRINT A4</span>
              </button>
            </div>
          </div>

          {/* Visual Container representing A4 sheet */}
          <div className="w-full bg-white p-3 md:p-4 rounded-xl shadow-xl border border-slate-300 space-y-3 max-w-[210mm] text-slate-900">
            
            {/* 1. SCHOOL COPY */}
            <ReceiptCopyCard
              copyTitle="SCHOOL COPY"
              receiptNo={receiptNo}
              date={receiptDate}
              studentName={studentName}
              rollNo={rollNo}
              studentClass={studentClass}
              section={section}
              academicYear={academicYear}
              activeItems={activeItems}
              grandTotal={grandTotal}
              paymentMode={paymentMode}
              txnRef={txnRef}
              settings={settings}
              qrSrc={qrSrc}
            />

            {/* DASHED CUT LINE FOR PRINTING */}
            <div className="relative py-1 text-center flex items-center justify-center">
              <div className="border-t-2 border-dashed border-slate-300 w-full"></div>
              <span className="absolute bg-slate-200 px-3 text-[10px] font-mono text-slate-600 flex items-center gap-1.5 rounded-full">
                <Scissors className="w-3 h-3 text-slate-700" /> Cut Here (Standard A4 Dual Print)
              </span>
            </div>

            {/* 2. STUDENT / PARENT COPY */}
            <ReceiptCopyCard
              copyTitle="STUDENT / PARENT COPY"
              receiptNo={receiptNo}
              date={receiptDate}
              studentName={studentName}
              rollNo={rollNo}
              studentClass={studentClass}
              section={section}
              academicYear={academicYear}
              activeItems={activeItems}
              grandTotal={grandTotal}
              paymentMode={paymentMode}
              txnRef={txnRef}
              settings={settings}
              qrSrc={qrSrc}
            />

          </div>
        </section>

      </div>

      {/* PRINT-ONLY CONTAINER (Revealed exclusively during window.print()) */}
      <div className="print-only">
        <div className="space-y-4">
          <ReceiptCopyCard
            copyTitle="SCHOOL COPY"
            receiptNo={receiptNo}
            date={receiptDate}
            studentName={studentName}
            rollNo={rollNo}
            studentClass={studentClass}
            section={section}
            academicYear={academicYear}
            activeItems={activeItems}
            grandTotal={grandTotal}
            paymentMode={paymentMode}
            txnRef={txnRef}
            settings={settings}
            qrSrc={qrSrc}
          />

          <div className="relative py-2 text-center flex items-center justify-center">
            <div className="border-t border-dashed border-slate-500 w-full"></div>
            <span className="absolute bg-white px-2 text-[9px] font-mono text-slate-600">
              --- CUT HERE (DUAL COPY) ---
            </span>
          </div>

          <ReceiptCopyCard
            copyTitle="STUDENT / PARENT COPY"
            receiptNo={receiptNo}
            date={receiptDate}
            studentName={studentName}
            rollNo={rollNo}
            studentClass={studentClass}
            section={section}
            academicYear={academicYear}
            activeItems={activeItems}
            grandTotal={grandTotal}
            paymentMode={paymentMode}
            txnRef={txnRef}
            settings={settings}
            qrSrc={qrSrc}
          />
        </div>
      </div>
    </div>
  );
};

interface ReceiptCopyCardProps {
  copyTitle: string;
  receiptNo: string;
  date: string;
  studentName: string;
  rollNo: string;
  studentClass: string;
  section: string;
  academicYear: string;
  activeItems: { name: string; amount: number }[];
  grandTotal: number;
  paymentMode: string;
  txnRef: string;
  settings: SchoolSettings;
  qrSrc: string;
}

const ReceiptCopyCard: React.FC<ReceiptCopyCardProps> = ({
  copyTitle,
  receiptNo,
  date,
  studentName,
  rollNo,
  studentClass,
  section,
  academicYear,
  activeItems,
  grandTotal,
  paymentMode,
  txnRef,
  settings,
  qrSrc,
}) => {
  const isSchool = copyTitle.includes('SCHOOL');

  return (
    <div className="receipt-copy relative border-2 border-slate-800 rounded-lg p-3 bg-white text-slate-900">
      {/* Copy Label Badge */}
      <span
        className={`absolute top-2 right-2 text-white font-bold text-[9px] uppercase px-2 py-0.5 rounded tracking-widest ${
          isSchool ? 'bg-slate-900' : 'bg-blue-900'
        }`}
      >
        {copyTitle}
      </span>

      {/* School Header */}
      <div className="border-b-2 border-slate-800 pb-2 mb-2 text-center">
        <div className="flex items-center justify-center gap-2">
          {settings.logoUrl ? (
            <img src={settings.logoUrl} alt="Logo" className="w-9 h-9 object-contain rounded" />
          ) : (
            <div className="w-8 h-8 rounded-lg bg-blue-950 text-white flex items-center justify-center text-sm font-bold">
              W
            </div>
          )}
          <div>
            <h1 className="font-header text-base md:text-lg font-bold tracking-tight text-slate-950 uppercase leading-none">
              {settings.schoolName}
            </h1>
            <p className="text-[10px] font-medium text-slate-700">
              {settings.addressLine1}, {settings.addressLine2}
            </p>
            <p className="text-[9px] font-semibold text-slate-600">
              {settings.affiliation} • Phone: {settings.phone1}
            </p>
          </div>
        </div>

        <div className="mt-1 flex items-center justify-center gap-3">
          <span className="inline-block bg-slate-100 border border-slate-400 font-bold text-[10px] uppercase px-3 py-0.5 rounded-full text-slate-900 tracking-wider">
            OFFICIAL FEE RECEIPT
          </span>
          <span className="text-[10px] font-bold text-emerald-800">
            GPay: {settings.gpayNumber} ({settings.adminName})
          </span>
        </div>
      </div>

      {/* Student Details Grid */}
      <div className="grid grid-cols-12 gap-x-2 gap-y-1 text-[11px] mb-2 font-sans">
        <div className="col-span-6">
          <span className="font-bold text-slate-600">Receipt No:</span>{' '}
          <span className="font-mono font-bold text-slate-900">{receiptNo || '---'}</span>
        </div>
        <div className="col-span-6 text-right">
          <span className="font-bold text-slate-600">Date:</span>{' '}
          <span className="font-semibold text-slate-900">{date || '---'}</span>
        </div>

        <div className="col-span-7">
          <span className="font-bold text-slate-600">Student Name:</span>{' '}
          <span className="font-bold text-slate-950 text-xs uppercase">
            {studentName || '_______________________'}
          </span>
        </div>
        <div className="col-span-5 text-right">
          <span className="font-bold text-slate-600">Adm / Roll No:</span>{' '}
          <span className="font-mono font-semibold text-slate-900">{rollNo || '_______'}</span>
        </div>

        <div className="col-span-6">
          <span className="font-bold text-slate-600">Standard & Sec:</span>{' '}
          <span className="font-semibold text-slate-900">
            {studentClass} - {section}
          </span>
        </div>
        <div className="col-span-6 text-right">
          <span className="font-bold text-slate-600">Academic Year:</span>{' '}
          <span className="font-semibold text-slate-900">{academicYear}</span>
        </div>
      </div>

      {/* Particulars Table */}
      <table className="w-full text-left border-collapse border border-slate-400 text-[10.5px] mb-2">
        <thead>
          <tr className="bg-slate-100 text-slate-800 border-b border-slate-400 font-bold">
            <th className="p-1 border-r border-slate-400 w-10 text-center">S.No</th>
            <th className="p-1 border-r border-slate-400">Particulars / Description</th>
            <th className="p-1 text-right w-28">Amount (₹)</th>
          </tr>
        </thead>
        <tbody>
          {activeItems.length === 0 ? (
            <tr>
              <td colSpan={3} className="p-2 text-center text-slate-400 italic">
                No fee particulars entered
              </td>
            </tr>
          ) : (
            activeItems.map((item, index) => (
              <tr key={index} className="border-b border-slate-300">
                <td className="p-1 border-r border-slate-400 text-center font-mono">{index + 1}</td>
                <td className="p-1 border-r border-slate-400 font-medium text-slate-800">
                  {item.name}
                </td>
                <td className="p-1 text-right font-mono font-semibold">
                  ₹ {item.amount.toLocaleString('en-IN')}
                </td>
              </tr>
            ))
          )}
        </tbody>
        <tfoot>
          <tr className="border-t-2 border-slate-800 font-bold bg-slate-50 text-[11px]">
            <td colSpan={2} className="p-1 text-right border-r border-slate-400 uppercase">
              Total Amount Received:
            </td>
            <td className="p-1 text-right font-mono font-extrabold text-xs text-slate-900">
              ₹ {grandTotal.toLocaleString('en-IN')}
            </td>
          </tr>
        </tfoot>
      </table>

      {/* Amount in words & payment details */}
      <div className="text-[10px] space-y-1 mb-2">
        <div>
          <span className="font-bold text-slate-700">Amount in Words:</span>{' '}
          <span className="font-semibold text-slate-900 italic capitalize">
            {numberToWordsIndian(grandTotal)}
          </span>
        </div>
        <div className="flex flex-wrap justify-between items-center gap-1">
          <div>
            <span className="font-bold text-slate-700">Payment Mode:</span>{' '}
            <span className="font-bold text-slate-900">{paymentMode}</span>
            {txnRef && <span className="font-mono text-slate-600 ml-1.5">({txnRef})</span>}
          </div>
          <div>
            <span className="font-bold text-slate-700">GPay:</span>{' '}
            <span className="font-mono font-semibold text-emerald-800">
              {settings.gpayNumber} • {settings.upiId}
            </span>
          </div>
        </div>
      </div>

      {/* Signatures & Embedded QR code */}
      <div className="pt-4 flex justify-between items-end text-[10px]">
        <div className="text-center border-t border-dashed border-slate-400 pt-1 w-28">
          <span className="font-semibold text-slate-700">Parent / Guardian</span>
        </div>

        {/* Embedded QR Code Thumbnail */}
        {qrSrc && (
          <div className="flex flex-col items-center">
            <img src={qrSrc} alt="GPay QR" className="w-11 h-11 border border-slate-300 rounded p-0.5 bg-white" />
            <span className="text-[7.5px] font-mono text-slate-700 font-bold max-w-[130px] truncate">{settings.upiId}</span>
          </div>
        )}

        <div className="text-center border-t border-dashed border-slate-400 pt-1 w-32">
          <span className="font-bold text-slate-900 block leading-tight">Admin ({settings.adminName})</span>
          <span className="text-[8.5px] text-slate-500">Correspondent & Admin</span>
        </div>

        <div className="text-center border-t border-dashed border-slate-400 pt-1 w-32">
          <span className="font-bold text-slate-900 block leading-tight">Principal ({settings.principalName})</span>
          <span className="text-[8.5px] text-slate-500">Authorized Signatory</span>
        </div>
      </div>
    </div>
  );
};
