import React, { useState } from 'react';
import { 
  Plus, 
  Upload, 
  Download, 
  Search, 
  Filter, 
  MessageCircle, 
  CreditCard, 
  Trash2, 
  Edit3, 
  CheckCircle, 
  AlertCircle, 
  Bus, 
  X,
  FileSpreadsheet,
  IndianRupee,
  QrCode,
  UserX,
  CheckSquare,
  Square,
  RotateCcw
} from 'lucide-react';
import { Student, SchoolSettings, SchoolClass, Section } from '../types';
import { exportStudentsToCsv, downloadSampleCsvTemplate, parseStudentsCsv } from '../utils/csvHelper';
import { generateFeeDueMessage } from '../utils/whatsappHelper';

interface StudentDirectoryProps {
  students: Student[];
  onAddStudent: (newStudent: Student) => void;
  onUpdateStudent: (updatedStudent: Student) => void;
  onDeleteStudent: (id: string) => void;
  onDeleteMultipleStudents?: (ids: string[]) => void;
  onDeleteAllStudents?: () => void;
  onRestoreSampleStudents?: () => void;
  onSelectForReceipt: (student: Student) => void;
  settings: SchoolSettings;
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
  onEditFees: (student: Student) => void;
}

export const StudentDirectory: React.FC<StudentDirectoryProps> = ({
  students,
  onAddStudent,
  onUpdateStudent,
  onDeleteStudent,
  onDeleteMultipleStudents,
  onDeleteAllStudents,
  onRestoreSampleStudents,
  onSelectForReceipt,
  settings,
  onOpenGpayModal,
  onEditFees,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [feeStatusFilter, setFeeStatusFilter] = useState<'All' | 'Paid' | 'Partial' | 'Pending' | 'Van'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [deleteConfirmType, setDeleteConfirmType] = useState<'selected' | 'all' | null>(null);

  // Form State for Add / Edit
  const [formAdmNo, setFormAdmNo] = useState<string>('');
  const [formName, setFormName] = useState<string>('');
  const [formFatherName, setFormFatherName] = useState<string>('');
  const [formClass, setFormClass] = useState<SchoolClass>('LKG');
  const [formSection, setFormSection] = useState<Section>('A');
  const [formGender, setFormGender] = useState<'Male' | 'Female'>('Male');
  const [formPhone, setFormPhone] = useState<string>('');
  const [formAddress, setFormAddress] = useState<string>('');
  
  // School fees form
  const [formTuition, setFormTuition] = useState<number>(8000);
  const [formBooks, setFormBooks] = useState<number>(2000);
  const [formAdmissionFee, setFormAdmissionFee] = useState<number>(0);
  const [formExamFee, setFormExamFee] = useState<number>(1500);
  const [formPaid, setFormPaid] = useState<number>(0);

  // Van fees form
  const [formUsesVan, setFormUsesVan] = useState<boolean>(false);
  const [formVanRoute, setFormVanRoute] = useState<string>('Route 1: Essur - Thozhupedu');
  const [formPickupPoint, setFormPickupPoint] = useState<string>('Essur Bus Stand');
  const [formVanFee, setFormVanFee] = useState<number>(4500);
  const [formVanPaid, setFormVanPaid] = useState<number>(0);

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  const openAddModal = () => {
    setEditingStudent(null);
    const rand = Math.floor(100 + Math.random() * 900);
    setFormAdmNo(`W2026-${rand}`);
    setFormName('');
    setFormFatherName('');
    setFormClass('LKG');
    setFormSection('A');
    setFormGender('Male');
    setFormPhone('9176593190');
    setFormAddress('Essur Village');
    setFormAdmissionFee(0);
    setFormTuition(8000);
    setFormBooks(2000);
    setFormExamFee(1500);
    setFormPaid(0);
    setFormUsesVan(false);
    setFormVanFee(4500);
    setFormVanPaid(0);
    setShowAddModal(true);
  };

  const openEditModal = (std: Student) => {
    setEditingStudent(std);
    setFormAdmNo(std.admissionNo);
    setFormName(std.name);
    setFormFatherName(std.fatherName);
    setFormClass(std.studentClass);
    setFormSection(std.section);
    setFormGender(std.gender);
    setFormPhone(std.parentPhone);
    setFormAddress(std.address);
    setFormAdmissionFee(std.schoolFees.feeBreakdown.admissionFee);
    setFormTuition(std.schoolFees.feeBreakdown.tuitionFee);
    setFormBooks(std.schoolFees.feeBreakdown.booksStationeryFee);
    setFormExamFee(std.schoolFees.feeBreakdown.examFee);
    setFormPaid(std.schoolFees.paidAmount);
    setFormUsesVan(std.vanFees.usesVan);
    setFormVanRoute(std.vanFees.route);
    setFormPickupPoint(std.vanFees.pickupPoint);
    setFormVanFee(std.vanFees.termFee);
    setFormVanPaid(std.vanFees.paidAmount);
    setShowAddModal(true);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formAdmNo.trim()) {
      alert('Please fill student name and admission number.');
      return;
    }

    const totalSchoolFee = formAdmissionFee + formTuition + formBooks + formExamFee;
    let schoolStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';
    if (formPaid >= totalSchoolFee && totalSchoolFee > 0) schoolStatus = 'Paid';
    else if (formPaid > 0) schoolStatus = 'Partial';

    let vanStatus: 'Paid' | 'Partial' | 'Pending' = 'Pending';
    if (formVanPaid >= formVanFee && formVanFee > 0) vanStatus = 'Paid';
    else if (formVanPaid > 0) vanStatus = 'Partial';

    const studentData: Student = {
      id: editingStudent ? editingStudent.id : `std-${Date.now()}`,
      admissionNo: formAdmNo,
      name: formName,
      fatherName: formFatherName,
      studentClass: formClass,
      section: formSection,
      gender: formGender,
      parentPhone: formPhone,
      whatsappPhone: formPhone,
      address: formAddress,
      academicYear: settings.currentAcademicYear,
      schoolFees: {
        totalFee: totalSchoolFee,
        paidAmount: formPaid,
        term: 'Annual',
        feeBreakdown: {
          admissionFee: formAdmissionFee,
          tuitionFee: formTuition,
          examFee: formExamFee,
          booksStationeryFee: formBooks,
          uniformActivityFee: 0,
          otherFee: 0,
        },
        status: schoolStatus,
        lastPaymentDate: formPaid > 0 ? new Date().toISOString().split('T')[0] : undefined,
      },
      vanFees: {
        usesVan: formUsesVan,
        route: formUsesVan ? formVanRoute : 'None',
        pickupPoint: formUsesVan ? formPickupPoint : 'Walking',
        termFee: formUsesVan ? formVanFee : 0,
        paidAmount: formUsesVan ? formVanPaid : 0,
        vanStatus: formUsesVan ? vanStatus : 'Paid',
        lastPaymentDate: formVanPaid > 0 ? new Date().toISOString().split('T')[0] : undefined,
      },
      remarks: editingStudent?.remarks || 'Active Student',
    };

    if (editingStudent) {
      onUpdateStudent(studentData);
    } else {
      onAddStudent(studentData);
    }

    setShowAddModal(false);
  };

  // CSV File Import Handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;
      const imported = parseStudentsCsv(text);
      if (imported.length === 0) {
        alert('Could not find valid student rows in the uploaded CSV file.');
        return;
      }
      imported.forEach(st => onAddStudent(st));
      alert(`Successfully imported ${imported.length} students!`);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Direct WhatsApp Reminder for single student
  const sendWhatsAppReminder = (student: Student) => {
    const message = generateFeeDueMessage(student, settings, 'en');
    const cleanPhone = (student.parentPhone || '').replace(/\D/g, '');
    const fullPhone = cleanPhone.length === 10 ? `91${cleanPhone}` : cleanPhone;
    const url = `https://wa.me/${fullPhone}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  // Filter students
  const filteredStudents = students.filter(s => {
    // Class filter
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;

    // Fee Status filter
    if (feeStatusFilter === 'Paid' && s.schoolFees.status !== 'Paid') return false;
    if (feeStatusFilter === 'Partial' && s.schoolFees.status !== 'Partial') return false;
    if (feeStatusFilter === 'Pending' && s.schoolFees.status !== 'Pending') return false;
    if (feeStatusFilter === 'Van' && !s.vanFees.usesVan) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = s.name.toLowerCase().includes(q);
      const matchAdm = s.admissionNo.toLowerCase().includes(q);
      const matchFather = s.fatherName.toLowerCase().includes(q);
      const matchPhone = s.parentPhone.includes(q);
      return matchName || matchAdm || matchFather || matchPhone;
    }

    return true;
  });

  // Bulk Selection Handlers
  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleToggleSelectAllFiltered = () => {
    const filteredIds = filteredStudents.map(s => s.id);
    const allFilteredSelected = filteredIds.length > 0 && filteredIds.every(id => selectedIds.includes(id));

    if (allFilteredSelected) {
      setSelectedIds(prev => prev.filter(id => !filteredIds.includes(id)));
    } else {
      setSelectedIds(prev => Array.from(new Set([...prev, ...filteredIds])));
    }
  };

  const handleSelectAllStudents = () => {
    if (selectedIds.length === students.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(students.map(s => s.id));
    }
  };

  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  const handleExecuteDeleteSelected = () => {
    if (selectedIds.length === 0) return;
    if (onDeleteMultipleStudents) {
      onDeleteMultipleStudents(selectedIds);
    } else {
      selectedIds.forEach(id => onDeleteStudent(id));
    }
    setSelectedIds([]);
    setDeleteConfirmType(null);
  };

  const handleExecuteDeleteAll = () => {
    if (onDeleteAllStudents) {
      onDeleteAllStudents();
    } else {
      students.forEach(s => onDeleteStudent(s.id));
    }
    setSelectedIds([]);
    setDeleteConfirmType(null);
  };

  const selectedStudents = students.filter(s => selectedIds.includes(s.id));
  const isAllFilteredSelected = filteredStudents.length > 0 && filteredStudents.every(s => selectedIds.includes(s.id));

  return (
    <div className="space-y-4">
      {/* Top Action Bar */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4">
        <div className="flex flex-wrap justify-between items-center gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <span>LKG to 5th Std Student Directory</span>
              <span className="text-xs bg-blue-100 text-blue-800 font-bold px-2.5 py-0.5 rounded-full">
                {filteredStudents.length} Students
              </span>
              {selectedIds.length > 0 && (
                <span className="text-xs bg-amber-100 text-amber-800 font-bold px-2.5 py-0.5 rounded-full">
                  {selectedIds.length} Selected
                </span>
              )}
            </h2>
            <p className="text-xs text-slate-500">
              Manage student enrollment, fee records, select all / bulk delete, and parent contacts.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Add Student Button */}
            <button
              onClick={openAddModal}
              className="px-3.5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Student</span>
            </button>

            {/* CSV Import */}
            <label className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition border border-slate-300 flex items-center gap-1.5 cursor-pointer">
              <Upload className="w-4 h-4 text-slate-600" />
              <span>Import CSV</span>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            {/* CSV Template */}
            <button
              onClick={downloadSampleCsvTemplate}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition border border-slate-300 flex items-center gap-1.5"
              title="Download empty CSV format with examples"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>CSV Template</span>
            </button>

            {/* Export CSV */}
            <button
              onClick={() => exportStudentsToCsv(filteredStudents)}
              className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition shadow-sm flex items-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Export CSV</span>
            </button>

            {/* Select All Toggle */}
            {filteredStudents.length > 0 && (
              <button
                onClick={handleToggleSelectAllFiltered}
                className={`px-3 py-2 rounded-xl text-xs font-semibold transition border flex items-center gap-1.5 ${
                  isAllFilteredSelected
                    ? 'bg-blue-100 text-blue-900 border-blue-300 shadow-sm'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                }`}
                title={isAllFilteredSelected ? "Deselect all visible students" : "Select all visible students"}
              >
                <CheckSquare className="w-4 h-4 text-blue-600" />
                <span>{isAllFilteredSelected ? 'Deselect All' : 'Select All'}</span>
              </button>
            )}

            {/* Delete All Students */}
            {students.length > 0 && (
              <button
                onClick={() => setDeleteConfirmType('all')}
                className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-semibold transition border border-rose-200 flex items-center gap-1.5"
                title="Delete all students from database"
              >
                <Trash2 className="w-4 h-4 text-rose-600" />
                <span>Delete All</span>
              </button>
            )}

            {/* Restore Default Sample Students */}
            {onRestoreSampleStudents && (
              <button
                onClick={() => {
                  if (confirm('Restore default sample student roster (LKG to 5th Std)? This will reload sample records.')) {
                    onRestoreSampleStudents();
                    setSelectedIds([]);
                  }
                }}
                className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-semibold transition border border-amber-200 flex items-center gap-1.5"
                title="Restore default sample students"
              >
                <RotateCcw className="w-4 h-4 text-amber-700" />
                <span>Restore Sample</span>
              </button>
            )}
          </div>
        </div>

        {/* Filters and Search Row */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap justify-between items-center gap-3">
          {/* Class selection pills */}
          <div className="flex gap-1 overflow-x-auto pb-1 max-w-full">
            {classesList.map((cls) => (
              <button
                key={cls}
                onClick={() => setSelectedClass(cls)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition whitespace-nowrap ${
                  selectedClass === cls
                    ? 'bg-blue-900 text-white font-bold shadow-sm'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cls}
              </button>
            ))}
          </div>

          {/* Search box & Status filter */}
          <div className="flex items-center gap-2 flex-grow sm:flex-grow-0">
            <div className="relative flex-grow sm:w-60">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search by name, roll no, phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <select
              value={feeStatusFilter}
              onChange={(e) => setFeeStatusFilter(e.target.value as any)}
              className="border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
            >
              <option value="All">All Statuses</option>
              <option value="Paid">Fully Paid</option>
              <option value="Partial">Partial Paid</option>
              <option value="Pending">Pending Dues</option>
              <option value="Van">Van Riders</option>
            </select>
          </div>
        </div>
      </div>

      {/* Selected Students Bulk Actions Banner */}
      {selectedIds.length > 0 && (
        <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white p-4 rounded-2xl shadow-lg border border-blue-500/40 flex flex-wrap items-center justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 border border-blue-400/40 flex items-center justify-center text-amber-300 font-bold shadow-inner">
              <CheckSquare className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="font-bold text-sm flex items-center gap-2">
                <span>{selectedIds.length} Student{selectedIds.length > 1 ? 's' : ''} Selected</span>
                <span className="text-[10px] bg-blue-500/30 text-blue-200 border border-blue-400/30 px-2.5 py-0.5 rounded-full font-mono">
                  out of {students.length} Total
                </span>
              </div>
              <p className="text-xs text-blue-200/80">
                Bulk operations applied to all selected students
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {selectedIds.length < filteredStudents.length && (
              <button
                onClick={() => {
                  const allFiltered = filteredStudents.map(s => s.id);
                  setSelectedIds(prev => Array.from(new Set([...prev, ...allFiltered])));
                }}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition border border-white/10"
              >
                Select All Visible ({filteredStudents.length})
              </button>
            )}

            {selectedIds.length < students.length && (
              <button
                onClick={handleSelectAllStudents}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition border border-white/10"
              >
                Select All Students ({students.length})
              </button>
            )}

            <button
              onClick={() => exportStudentsToCsv(selectedStudents, `Wisdom_Selected_${selectedStudents.length}_Students.csv`)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-sm flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Selected ({selectedIds.length})</span>
            </button>

            <button
              onClick={() => setDeleteConfirmType('selected')}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition shadow-sm flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete Selected ({selectedIds.length})</span>
            </button>

            <button
              onClick={handleClearSelection}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium transition border border-slate-700"
            >
              Deselect All
            </button>
          </div>
        </div>
      )}

      {/* Student Cards Grid / Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 text-slate-700 uppercase font-bold text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3 w-10 text-center">
                  <input
                    type="checkbox"
                    aria-label="Select all visible students"
                    checked={isAllFilteredSelected}
                    onChange={handleToggleSelectAllFiltered}
                    className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer accent-blue-600"
                  />
                </th>
                <th className="p-3">Adm No</th>
                <th className="p-3">Student & Parent</th>
                <th className="p-3">Class & Sec</th>
                <th className="p-3">Parent Mobile</th>
                <th className="p-3">School Fee</th>
                <th className="p-3">School Due</th>
                <th className="p-3">Van Status</th>
                <th className="p-3 text-right">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-10 text-center text-slate-500">
                    <div className="max-w-md mx-auto space-y-3">
                      <UserX className="w-12 h-12 text-slate-300 mx-auto" />
                      <p className="text-sm font-semibold text-slate-700">No students found matching your criteria</p>
                      <p className="text-xs text-slate-400">
                        {students.length === 0 
                          ? 'Your student database is empty. You can add new students or restore default sample records.' 
                          : 'Try clearing the search query or changing class/status filters.'}
                      </p>
                      {students.length === 0 && onRestoreSampleStudents && (
                        <div className="pt-2 flex justify-center gap-2">
                          <button
                            onClick={onRestoreSampleStudents}
                            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                          >
                            <RotateCcw className="w-4 h-4" />
                            <span>Restore Sample Students</span>
                          </button>
                          <button
                            onClick={openAddModal}
                            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition border border-slate-300 flex items-center gap-1.5"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add Student Manually</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => {
                  const isSelected = selectedIds.includes(s.id);
                  const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
                  const vanDue = s.vanFees.usesVan
                    ? s.vanFees.termFee - s.vanFees.paidAmount
                    : 0;

                  return (
                    <tr 
                      key={s.id} 
                      className={`transition ${isSelected ? 'bg-blue-50/90 font-medium' : 'hover:bg-slate-50/80'}`}
                    >
                      <td className="p-3 text-center">
                        <input
                          type="checkbox"
                          aria-label={`Select student ${s.name}`}
                          checked={isSelected}
                          onChange={() => handleToggleSelect(s.id)}
                          className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300 cursor-pointer accent-blue-600"
                        />
                      </td>
                      <td className="p-3 font-mono font-bold text-slate-800">
                        {s.admissionNo}
                      </td>
                      <td className="p-3">
                        <div className="font-bold text-slate-900 text-xs">{s.name}</div>
                        <div className="text-[10px] text-slate-500">Father: {s.fatherName}</div>
                      </td>
                      <td className="p-3">
                        <span className="font-semibold text-slate-800">{s.studentClass}</span>
                        <span className="text-[10px] text-slate-500 ml-1">({s.section})</span>
                      </td>
                      <td className="p-3 font-mono text-slate-700">
                        {s.parentPhone}
                      </td>
                      <td className="p-3">
                        <div className="font-mono font-semibold text-slate-900">
                          ₹ {s.schoolFees.totalFee.toLocaleString('en-IN')}
                        </div>
                        <div className="text-[10px] text-emerald-700">
                          Paid: ₹ {s.schoolFees.paidAmount.toLocaleString('en-IN')}
                        </div>
                      </td>
                      <td className="p-3">
                        {schoolDue <= 0 ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            <CheckCircle className="w-3 h-3" /> Paid
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                            <AlertCircle className="w-3 h-3" /> ₹ {schoolDue.toLocaleString('en-IN')}
                          </span>
                        )}
                      </td>
                      <td className="p-3">
                        {s.vanFees.usesVan ? (
                          <div>
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              <Bus className="w-3 h-3" /> {vanDue > 0 ? `Due ₹${vanDue}` : 'Paid'}
                            </span>
                            <div className="text-[9px] text-slate-500 truncate max-w-[120px]">
                              {s.vanFees.route}
                            </div>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400">No Van</span>
                        )}
                      </td>
                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {/* Receipt Bill Action */}
                          <button
                            onClick={() => onSelectForReceipt(s)}
                            className="p-1.5 rounded-lg bg-blue-50 text-blue-700 hover:bg-blue-100 transition"
                            title="Generate & Print Fee Receipt"
                          >
                            <CreditCard className="w-4 h-4" />
                          </button>

                          {/* Edit Fees Action */}
                          <button
                            onClick={() => onEditFees(s)}
                            className="p-1.5 rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 transition"
                            title="Edit Fees Particulars & Collections"
                          >
                            <IndianRupee className="w-4 h-4" />
                          </button>

                          {/* GPay QR Action */}
                          <button
                            onClick={() => onOpenGpayModal((s.schoolFees.totalFee - s.schoolFees.paidAmount) + (s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0), s.name)}
                            className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition"
                            title={`Show GPay QR (${settings.upiId})`}
                          >
                            <QrCode className="w-4 h-4" />
                          </button>

                          {/* WhatsApp Reminder */}
                          <button
                            onClick={() => sendWhatsAppReminder(s)}
                            className="p-1.5 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100 transition"
                            title={`Send WhatsApp Fee Notice (${settings.upiId})`}
                          >
                            <MessageCircle className="w-4 h-4" />
                          </button>

                          {/* Edit Student Info */}
                          <button
                            onClick={() => openEditModal(s)}
                            className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 transition"
                            title="Edit Student Info"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          {/* Delete Student */}
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete student record for ${s.name} (${s.admissionNo})? This action cannot be undone.`)) {
                                onDeleteStudent(s.id);
                                setSelectedIds(prev => prev.filter(x => x !== s.id));
                              }
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 text-rose-600 hover:bg-rose-100 transition"
                            title="Delete Student Record"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Student Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
            <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-4 text-white flex justify-between items-center sticky top-0 z-10">
              <h3 className="font-bold text-base">
                {editingStudent ? 'Edit Student Details' : 'Add New Student (LKG to 5th Std)'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg text-blue-200 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="p-5 space-y-4 text-xs">
              {/* Section 1: Basic Info */}
              <div className="space-y-3">
                <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] border-b pb-1">
                  Student & Academic Details
                </h4>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Admission No *</label>
                    <input
                      type="text"
                      required
                      value={formAdmNo}
                      onChange={(e) => setFormAdmNo(e.target.value)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block font-semibold text-slate-700 mb-1">Student Name *</label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="e.g. S. Vignesh"
                      className="w-full border border-slate-300 rounded-lg p-2 font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Father / Guardian Name</label>
                    <input
                      type="text"
                      value={formFatherName}
                      onChange={(e) => setFormFatherName(e.target.value)}
                      placeholder="e.g. P. Sivakumar"
                      className="w-full border border-slate-300 rounded-lg p-2"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Standard / Class *</label>
                    <select
                      value={formClass}
                      onChange={(e) => setFormClass(e.target.value as SchoolClass)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-semibold"
                    >
                      <option value="Pre-KG">Pre-KG</option>
                      <option value="LKG">LKG</option>
                      <option value="UKG">UKG</option>
                      <option value="1st Standard">1st Standard</option>
                      <option value="2nd Standard">2nd Standard</option>
                      <option value="3rd Standard">3rd Standard</option>
                      <option value="4th Standard">4th Standard</option>
                      <option value="5th Standard">5th Standard</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Section</label>
                    <select
                      value={formSection}
                      onChange={(e) => setFormSection(e.target.value as Section)}
                      className="w-full border border-slate-300 rounded-lg p-2"
                    >
                      <option value="A">Section A</option>
                      <option value="B">Section B</option>
                      <option value="C">Section C</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Gender</label>
                    <select
                      value={formGender}
                      onChange={(e) => setFormGender(e.target.value as any)}
                      className="w-full border border-slate-300 rounded-lg p-2"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Parent Mobile / WhatsApp</label>
                    <input
                      type="text"
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      placeholder="e.g. 9176593190"
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Address / Village</label>
                    <input
                      type="text"
                      value={formAddress}
                      onChange={(e) => setFormAddress(e.target.value)}
                      placeholder="e.g. Essur Village"
                      className="w-full border border-slate-300 rounded-lg p-2"
                    />
                  </div>
                </div>
              </div>

              {/* Section 2: School Fees Structure */}
              <div className="space-y-3 pt-2">
                <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] border-b pb-1">
                  School Fees Particulars (₹)
                </h4>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Admission Fee</label>
                    <input
                      type="number"
                      value={formAdmissionFee || ''}
                      onChange={(e) => setFormAdmissionFee(parseFloat(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Tuition Fee</label>
                    <input
                      type="number"
                      value={formTuition || ''}
                      onChange={(e) => setFormTuition(parseFloat(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Books & Stationery</label>
                    <input
                      type="number"
                      value={formBooks || ''}
                      onChange={(e) => setFormBooks(parseFloat(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Exam Fee</label>
                    <input
                      type="number"
                      value={formExamFee || ''}
                      onChange={(e) => setFormExamFee(parseFloat(e.target.value) || 0)}
                      className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                    />
                  </div>

                  <div className="col-span-2">
                    <label className="block font-bold text-slate-800 mb-1">Total School Fee Calculated</label>
                    <div className="p-2 bg-slate-100 rounded-lg font-mono font-bold text-sm text-slate-900">
                      ₹ {(formAdmissionFee + formTuition + formBooks + formExamFee).toLocaleString('en-IN')}
                    </div>
                  </div>

                  <div className="col-span-2">
                    <label className="block font-bold text-emerald-800 mb-1">Amount Paid So Far (₹)</label>
                    <input
                      type="number"
                      value={formPaid || ''}
                      onChange={(e) => setFormPaid(parseFloat(e.target.value) || 0)}
                      placeholder="0"
                      className="w-full border border-emerald-400 bg-emerald-50 rounded-lg p-2 font-mono font-bold text-emerald-900"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Van & Transport Fees */}
              <div className="space-y-3 pt-2">
                <div className="flex justify-between items-center border-b pb-1">
                  <h4 className="font-bold uppercase tracking-wider text-amber-800 text-[10px] flex items-center gap-1.5">
                    <Bus className="w-3.5 h-3.5" />
                    School Van & Transport Facility
                  </h4>
                  <label className="flex items-center gap-1.5 cursor-pointer text-xs font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={formUsesVan}
                      onChange={(e) => setFormUsesVan(e.target.checked)}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span>Uses School Van</span>
                  </label>
                </div>

                {formUsesVan && (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-amber-50/50 p-3 rounded-xl border border-amber-200">
                    <div className="col-span-2">
                      <label className="block font-semibold text-slate-700 mb-1">Van Route</label>
                      <input
                        type="text"
                        value={formVanRoute}
                        onChange={(e) => setFormVanRoute(e.target.value)}
                        placeholder="e.g. Route 1: Essur - Thozhupedu"
                        className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                      />
                    </div>

                    <div className="col-span-2">
                      <label className="block font-semibold text-slate-700 mb-1">Pickup / Drop Point</label>
                      <input
                        type="text"
                        value={formPickupPoint}
                        onChange={(e) => setFormPickupPoint(e.target.value)}
                        placeholder="e.g. Essur Temple Stop"
                        className="w-full border border-slate-300 rounded-lg p-2 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Van Fee Term (₹)</label>
                      <input
                        type="number"
                        value={formVanFee || ''}
                        onChange={(e) => setFormVanFee(parseFloat(e.target.value) || 0)}
                        className="w-full border border-slate-300 rounded-lg p-2 font-mono bg-white"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Van Fee Paid (₹)</label>
                      <input
                        type="number"
                        value={formVanPaid || ''}
                        onChange={(e) => setFormVanPaid(parseFloat(e.target.value) || 0)}
                        className="w-full border border-slate-300 rounded-lg p-2 font-mono bg-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-sm"
                >
                  {editingStudent ? 'Update Student' : 'Save Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Selected Students Confirmation Modal */}
      {deleteConfirmType === 'selected' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-rose-700 to-rose-900 p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-200" />
                <h3 className="font-bold text-base">
                  Delete {selectedIds.length} Selected Student{selectedIds.length > 1 ? 's' : ''}
                </h3>
              </div>
              <button
                onClick={() => setDeleteConfirmType(null)}
                className="p-1 rounded-lg text-rose-200 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 text-rose-900 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-rose-900 text-sm">
                    Confirm Deletion of {selectedIds.length} Selected Record{selectedIds.length > 1 ? 's' : ''}
                  </p>
                  <p className="mt-1 text-rose-700 leading-relaxed">
                    Are you sure you want to permanently delete these {selectedIds.length} student records? This action cannot be undone.
                  </p>
                </div>
              </div>

              <div>
                <div className="text-[11px] font-bold text-slate-600 uppercase mb-2 flex justify-between items-center">
                  <span>Selected Students to be Deleted:</span>
                  <span className="font-mono text-slate-500">{selectedStudents.length} Students</span>
                </div>
                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50 p-1">
                  {selectedStudents.map(st => (
                    <div key={st.id} className="p-2.5 flex justify-between items-center text-xs">
                      <div>
                        <span className="font-bold text-slate-900">{st.name}</span>
                        <span className="text-[10px] text-slate-500 ml-2 font-mono">({st.admissionNo})</span>
                      </div>
                      <span className="text-[10px] font-semibold bg-white border border-slate-200 px-2 py-0.5 rounded text-slate-700">
                        {st.studentClass} - {st.section}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmType(null)}
                  className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteDeleteSelected}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl font-bold transition shadow-sm flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Confirm Delete ({selectedIds.length})</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete All Students Confirmation Modal */}
      {deleteConfirmType === 'all' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-red-800 to-rose-950 p-4 text-white flex justify-between items-center">
              <div className="flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-rose-300" />
                <h3 className="font-bold text-base">Delete All Students</h3>
              </div>
              <button
                onClick={() => setDeleteConfirmType(null)}
                className="p-1 rounded-lg text-rose-200 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="bg-red-50 border border-red-200 rounded-xl p-3.5 text-red-900 flex items-start gap-3">
                <AlertCircle className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-red-900 text-sm">
                    Warning: Clear Entire Student Roster ({students.length} Students)
                  </p>
                  <p className="mt-1 text-red-700 leading-relaxed">
                    You are about to delete <strong>ALL {students.length} students</strong> currently in the system.
                    This will empty the roster completely.
                  </p>
                  <p className="mt-2 text-xs text-amber-800 font-semibold bg-amber-50 p-2 rounded-lg border border-amber-200">
                    Note: You can restore sample student records at any time using the "Restore Sample" button.
                  </p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmType(null)}
                  className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold text-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteDeleteAll}
                  className="px-5 py-2 bg-red-600 hover:bg-red-500 text-white rounded-xl font-bold transition shadow-sm flex items-center gap-1.5"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Yes, Delete All {students.length} Students</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
