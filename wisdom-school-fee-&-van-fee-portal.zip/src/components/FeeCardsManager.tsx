import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Bus, 
  Download, 
  Printer, 
  FileDown, 
  GraduationCap, 
  Layers, 
  ShieldCheck, 
  QrCode,
  Calendar,
  CheckCircle2
} from 'lucide-react';
import { Student, SchoolSettings } from '../types';
import { 
  generateTuitionFeeCardPdf, 
  generateBulkTuitionCardsPdf,
  generateVanFeeCardPdf,
  generateBulkVanCardsPdf
} from '../utils/pdfGenerator';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';
import { DEFAULT_SCHOOL_LOGO } from '../utils/sampleData';

interface FeeCardsManagerProps {
  students: Student[];
  settings: SchoolSettings;
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
}

export const FeeCardsManager: React.FC<FeeCardsManagerProps> = ({
  students,
  settings,
  onOpenGpayModal,
}) => {
  const [activeCardType, setActiveCardType] = useState<'tuition' | 'van'>('tuition');
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [qrSrc, setQrSrc] = useState<string>('');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  const filteredStudents = students.filter(s => {
    if (activeCardType === 'van' && !s.vanFees.usesVan) return false;
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;
    return true;
  });

  const selectedStudent = students.find(s => s.id === selectedStudentId) || filteredStudents[0] || students[0];

  useEffect(() => {
    if (selectedStudent) {
      const amount = activeCardType === 'tuition' 
        ? Math.max(0, selectedStudent.schoolFees.totalFee - selectedStudent.schoolFees.paidAmount)
        : Math.max(0, selectedStudent.vanFees.termFee - selectedStudent.vanFees.paidAmount);

      const upiUri = buildUpiUri({
        upiId: settings.upiId,
        payeeName: settings.adminName,
        amount: amount > 0 ? amount : undefined,
        note: `${activeCardType === 'tuition' ? 'Tuition' : 'Van'} Fee ${selectedStudent.admissionNo}`,
      });
      generateQrDataUrl(upiUri).then(dataUrl => setQrSrc(dataUrl));
    }
  }, [selectedStudent, activeCardType, settings]);

  const handleDownloadSingleCard = () => {
    if (!selectedStudent) return;
    setIsDownloading(true);
    setTimeout(() => {
      if (activeCardType === 'tuition') {
        generateTuitionFeeCardPdf(selectedStudent, settings, qrSrc);
      } else {
        generateVanFeeCardPdf(selectedStudent, settings, qrSrc);
      }
      setIsDownloading(false);
    }, 200);
  };

  const handleDownloadBulkCards = () => {
    if (filteredStudents.length === 0) return;
    setIsDownloading(true);
    setTimeout(() => {
      if (activeCardType === 'tuition') {
        generateBulkTuitionCardsPdf(filteredStudents, settings, qrSrc);
      } else {
        generateBulkVanCardsPdf(filteredStudents, settings, qrSrc);
      }
      setIsDownloading(false);
    }, 300);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl text-white flex items-center justify-center font-bold shadow-sm ${
              activeCardType === 'tuition' ? 'bg-blue-900' : 'bg-amber-600'
            }`}>
              {activeCardType === 'tuition' ? (
                <GraduationCap className="w-6 h-6 text-amber-400" />
              ) : (
                <Bus className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 leading-tight">
                {activeCardType === 'tuition' 
                  ? 'Student Tuition Fees Passbook Card Generator' 
                  : 'Student Van / Transport Pass Card Generator'}
              </h2>
              <p className="text-xs text-slate-500">
                Generate official student passbook cards with payment installments, route stops, and GPay QR ({settings.upiId}).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadBulkCards}
              disabled={isDownloading}
              className={`px-3.5 py-2 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5 ${
                activeCardType === 'tuition' ? 'bg-blue-800 hover:bg-blue-700' : 'bg-amber-700 hover:bg-amber-600'
              }`}
            >
              <Layers className="w-4 h-4 text-amber-300" />
              <span>Bulk Download All Cards ({filteredStudents.length} Students)</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              <span>Print A4</span>
            </button>
          </div>
        </div>

        {/* Card Type Switch Tabs */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap justify-between items-center gap-3 text-xs">
          <div className="flex rounded-xl bg-slate-100 p-1 font-bold">
            <button
              onClick={() => setActiveCardType('tuition')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg transition ${
                activeCardType === 'tuition'
                  ? 'bg-blue-900 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>Tuition Fees Card</span>
            </button>
            <button
              onClick={() => setActiveCardType('van')}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg transition ${
                activeCardType === 'van'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bus className="w-4 h-4" />
              <span>Van Transport Pass Card</span>
            </button>
          </div>

          {/* Student Selector */}
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700">Select Student:</span>
            <select
              value={selectedStudent?.id || ''}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="border border-slate-300 rounded-lg p-1.5 text-xs font-semibold text-slate-800 bg-white"
            >
              {filteredStudents.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.studentClass} - {s.section}) • {s.admissionNo}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Class Filter pills */}
        <div className="mt-3 flex items-center gap-1.5 overflow-x-auto text-xs">
          <span className="font-bold text-slate-600 text-[11px]">Class:</span>
          {classesList.map((cls) => (
            <button
              key={cls}
              onClick={() => setSelectedClass(cls)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
                selectedClass === cls
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cls}
            </button>
          ))}
        </div>
      </div>

      {/* Main Container: Full Official Card Preview */}
      <div className="bg-slate-200/90 rounded-2xl p-4 sm:p-6 border border-slate-300 flex flex-col items-center">
        
        {/* Actions bar above card */}
        <div className="w-full max-w-4xl flex justify-between items-center mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
            {activeCardType === 'tuition' ? 'Tuition Fee Card Preview' : 'Van Transport Pass Card Preview'}
          </span>
          <button
            onClick={handleDownloadSingleCard}
            disabled={isDownloading}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span>Download PDF Card</span>
          </button>
        </div>

        {selectedStudent && (
          <div className="w-full max-w-4xl bg-white rounded-xl shadow-xl border-2 border-slate-800 p-6 space-y-5 text-slate-900 font-sans">
            
            {/* Header */}
            <div className={`p-4 rounded-xl text-white text-center border-b-4 ${
              activeCardType === 'tuition' ? 'bg-blue-900 border-amber-400' : 'bg-amber-700 border-slate-900'
            }`}>
              <div className="flex items-center justify-center gap-3">
                <img
                  src={settings.logoUrl || DEFAULT_SCHOOL_LOGO}
                  alt="School Logo"
                  className="w-12 h-12 rounded-full bg-white p-1 object-contain shrink-0"
                />
                <div>
                  <h1 className="font-header text-lg md:text-xl font-bold uppercase tracking-tight text-white leading-tight">
                    {settings.schoolName}
                  </h1>
                  <p className="text-xs text-blue-100 font-medium">
                    {settings.addressLine1}, {settings.addressLine2}
                  </p>
                  <p className="text-[10px] text-blue-200">
                    {settings.affiliation} • Phone: {settings.phone1}
                  </p>
                </div>
              </div>

              <div className="mt-2 inline-block bg-white text-slate-950 font-extrabold text-xs uppercase px-4 py-1 rounded-full tracking-wider shadow">
                {activeCardType === 'tuition' 
                  ? `OFFICIAL STUDENT TUITION FEE CARD (${settings.currentAcademicYear})` 
                  : `SCHOOL TRANSPORT & VAN PASS CARD (${settings.currentAcademicYear})`}
              </div>
            </div>

            {/* Student Particulars Banner */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-3.5 bg-slate-50 rounded-xl border border-slate-300 text-xs">
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Student Full Name</span>
                <span className="font-bold text-slate-950 text-sm uppercase">{selectedStudent.name}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Admission / Roll No</span>
                <span className="font-mono font-bold text-slate-900 text-sm">{selectedStudent.admissionNo}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Standard & Section</span>
                <span className="font-bold text-blue-900 text-sm">{selectedStudent.studentClass} - {selectedStudent.section}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Parent Contact</span>
                <span className="font-mono font-bold text-slate-900 text-sm">{selectedStudent.parentPhone}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Father / Guardian</span>
                <span className="font-medium text-slate-800">{selectedStudent.fatherName || 'Parent'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Address</span>
                <span className="font-medium text-slate-800 truncate block">{selectedStudent.address || 'Essur'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">Blood Group</span>
                <span className="font-bold text-rose-700">{selectedStudent.bloodGroup || 'B+ Positive'}</span>
              </div>
              <div>
                <span className="text-slate-500 font-semibold block text-[10px] uppercase">
                  {activeCardType === 'tuition' ? 'Tuition Term' : 'Van Pickup Point'}
                </span>
                <span className="font-bold text-slate-900">
                  {activeCardType === 'tuition' ? selectedStudent.schoolFees.term : selectedStudent.vanFees.pickupPoint}
                </span>
              </div>
            </div>

            {/* CARD TYPE 1: TUITION FEE PASSBOOK PARTICULARS */}
            {activeCardType === 'tuition' && (
              <div className="space-y-4">
                {/* Fee Particulars Breakdown Table */}
                <table className="w-full text-left border-collapse border border-slate-300 text-xs">
                  <thead className="bg-slate-100 font-bold border-b border-slate-300 text-slate-800">
                    <tr>
                      <th className="p-2 border-r border-slate-300">Fee Particulars</th>
                      <th className="p-2 border-r border-slate-300 text-right">Amount (₹)</th>
                      <th className="p-2 border-r border-slate-300">Billing Term</th>
                      <th className="p-2 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-medium">Admission & Registration Fee</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {selectedStudent.schoolFees.feeBreakdown.admissionFee.toLocaleString('en-IN')}</td>
                      <td className="p-2 border-r border-slate-300">One-Time</td>
                      <td className="p-2 text-center text-emerald-700 font-bold">Billed</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-medium">Tuition & Academic Term Fee</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono font-bold">₹ {selectedStudent.schoolFees.feeBreakdown.tuitionFee.toLocaleString('en-IN')}</td>
                      <td className="p-2 border-r border-slate-300">{selectedStudent.schoolFees.term}</td>
                      <td className="p-2 text-center text-blue-900 font-bold">Active</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-medium">Examination & Term Evaluation Fee</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {selectedStudent.schoolFees.feeBreakdown.examFee.toLocaleString('en-IN')}</td>
                      <td className="p-2 border-r border-slate-300">Term-wise</td>
                      <td className="p-2 text-center text-slate-700">Scheduled</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-medium">Books, Notebooks & Stationery Charges</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {selectedStudent.schoolFees.feeBreakdown.booksStationeryFee.toLocaleString('en-IN')}</td>
                      <td className="p-2 border-r border-slate-300">Annual</td>
                      <td className="p-2 text-center text-slate-700">Issued</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 font-medium">Uniform & Extra Activities Charges</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {selectedStudent.schoolFees.feeBreakdown.uniformActivityFee.toLocaleString('en-IN')}</td>
                      <td className="p-2 border-r border-slate-300">Annual</td>
                      <td className="p-2 text-center text-slate-700">Active</td>
                    </tr>
                  </tbody>
                  <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-800 text-xs">
                    <tr>
                      <td className="p-2 border-r border-slate-300 uppercase">Total School Fees:</td>
                      <td className="p-2 border-r border-slate-300 text-right font-mono font-extrabold text-blue-950">
                        ₹ {selectedStudent.schoolFees.totalFee.toLocaleString('en-IN')}
                      </td>
                      <td className="p-2 border-r border-slate-300">
                        Paid: <strong className="text-emerald-700 font-mono">₹ {selectedStudent.schoolFees.paidAmount.toLocaleString('en-IN')}</strong>
                      </td>
                      <td className="p-2 text-center font-bold text-rose-700 font-mono">
                        Due: ₹ {Math.max(0, selectedStudent.schoolFees.totalFee - selectedStudent.schoolFees.paidAmount).toLocaleString('en-IN')}
                      </td>
                    </tr>
                  </tfoot>
                </table>

                {/* Installment Passbook Stamping Grid */}
                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-800 mb-1.5">
                    Installment Payment & Cashier Seal Record
                  </h4>
                  <table className="w-full text-left border-collapse border border-slate-300 text-xs">
                    <thead className="bg-slate-800 text-white font-bold">
                      <tr>
                        <th className="p-2 border-r border-slate-700">Installment Period</th>
                        <th className="p-2 border-r border-slate-700 text-center">Due Month</th>
                        <th className="p-2 border-r border-slate-700 text-right">Scheduled (₹)</th>
                        <th className="p-2 border-r border-slate-700 text-right">Amount Paid</th>
                        <th className="p-2 border-r border-slate-700 text-center">Receipt Date</th>
                        <th className="p-2 border-r border-slate-700 text-right">Balance</th>
                        <th className="p-2 text-center">Office Seal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term I (1st Installment)</td>
                        <td className="p-2 border-r border-slate-300 text-center text-slate-600">June - July</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.schoolFees.totalFee * 0.4).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          ₹ {Math.min(selectedStudent.schoolFees.paidAmount, Math.round(selectedStudent.schoolFees.totalFee * 0.4)).toLocaleString('en-IN')}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">{selectedStudent.schoolFees.lastPaymentDate || 'Pending'}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-slate-800">
                          {selectedStudent.schoolFees.paidAmount >= Math.round(selectedStudent.schoolFees.totalFee * 0.4) ? 'NIL' : `₹ ${Math.max(0, Math.round(selectedStudent.schoolFees.totalFee * 0.4) - selectedStudent.schoolFees.paidAmount).toLocaleString('en-IN')}`}
                        </td>
                        <td className="p-2 text-center text-emerald-800 font-bold">
                          {selectedStudent.schoolFees.paidAmount > 0 ? 'CLEARED' : '---'}
                        </td>
                      </tr>
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term II (2nd Installment)</td>
                        <td className="p-2 border-r border-slate-300 text-center text-slate-600">October - November</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.schoolFees.totalFee * 0.35).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          {selectedStudent.schoolFees.paidAmount > Math.round(selectedStudent.schoolFees.totalFee * 0.4) 
                            ? `₹ ${Math.min(selectedStudent.schoolFees.paidAmount - Math.round(selectedStudent.schoolFees.totalFee * 0.4), Math.round(selectedStudent.schoolFees.totalFee * 0.35)).toLocaleString('en-IN')}` 
                            : '₹ 0'}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">Pending</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-slate-800">
                          ₹ {Math.max(0, selectedStudent.schoolFees.totalFee - selectedStudent.schoolFees.paidAmount).toLocaleString('en-IN')}
                        </td>
                        <td className="p-2 text-center text-slate-400">---</td>
                      </tr>
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term III (3rd Installment)</td>
                        <td className="p-2 border-r border-slate-300 text-center text-slate-600">January - February</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.schoolFees.totalFee * 0.25).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          {selectedStudent.schoolFees.status === 'Paid' ? `₹ ${Math.round(selectedStudent.schoolFees.totalFee * 0.25).toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">Pending</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-rose-700">
                          {selectedStudent.schoolFees.status === 'Paid' ? 'NIL' : `₹ ${Math.max(0, selectedStudent.schoolFees.totalFee - selectedStudent.schoolFees.paidAmount).toLocaleString('en-IN')}`}
                        </td>
                        <td className="p-2 text-center text-slate-400">---</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* CARD TYPE 2: VAN TRANSPORT PASS PARTICULARS */}
            {activeCardType === 'van' && (
              <div className="space-y-4">
                {/* Route Information Box */}
                <div className="bg-amber-50 p-4 rounded-xl border border-amber-300 flex justify-between items-center text-xs">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-amber-800 block">Assigned Transport Route</span>
                    <span className="text-base font-extrabold text-slate-900">{selectedStudent.vanFees.route}</span>
                    <span className="block text-slate-600 mt-0.5">
                      Designated Stop: <strong>{selectedStudent.vanFees.pickupPoint}</strong>
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-amber-800 block">Van Fee Per Term</span>
                    <span className="text-base font-extrabold font-mono text-amber-950">₹ {selectedStudent.vanFees.termFee.toLocaleString('en-IN')}</span>
                    <span className="block text-emerald-700 font-bold">Paid: ₹ {selectedStudent.vanFees.paidAmount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                {/* Van Installment Grid */}
                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-800 mb-1.5">
                    Transport Stamping & Monthly Pass Verification Grid
                  </h4>
                  <table className="w-full text-left border-collapse border border-slate-300 text-xs">
                    <thead className="bg-amber-800 text-white font-bold">
                      <tr>
                        <th className="p-2 border-r border-amber-700">Term / Schedule</th>
                        <th className="p-2 border-r border-amber-700 text-right">Van Fee (₹)</th>
                        <th className="p-2 border-r border-amber-700 text-right">Paid (₹)</th>
                        <th className="p-2 border-r border-amber-700 text-center">Receipt Date</th>
                        <th className="p-2 border-r border-amber-700 text-right">Due Balance</th>
                        <th className="p-2 text-center">Driver / Incharge Stamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term I (June to September)</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.vanFees.termFee * 0.4).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          ₹ {Math.min(selectedStudent.vanFees.paidAmount, Math.round(selectedStudent.vanFees.termFee * 0.4)).toLocaleString('en-IN')}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">{selectedStudent.vanFees.lastPaymentDate || 'Pending'}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-slate-800">
                          {selectedStudent.vanFees.paidAmount >= Math.round(selectedStudent.vanFees.termFee * 0.4) ? 'NIL' : `₹ ${Math.max(0, Math.round(selectedStudent.vanFees.termFee * 0.4) - selectedStudent.vanFees.paidAmount).toLocaleString('en-IN')}`}
                        </td>
                        <td className="p-2 text-center text-emerald-800 font-bold">
                          {selectedStudent.vanFees.paidAmount > 0 ? 'AUTHORIZED' : '---'}
                        </td>
                      </tr>
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term II (October to December)</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.vanFees.termFee * 0.35).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          {selectedStudent.vanFees.paidAmount > Math.round(selectedStudent.vanFees.termFee * 0.4) 
                            ? `₹ ${Math.min(selectedStudent.vanFees.paidAmount - Math.round(selectedStudent.vanFees.termFee * 0.4), Math.round(selectedStudent.vanFees.termFee * 0.35)).toLocaleString('en-IN')}` 
                            : '₹ 0'}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">Pending</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-slate-800">
                          ₹ {Math.max(0, selectedStudent.vanFees.termFee - selectedStudent.vanFees.paidAmount).toLocaleString('en-IN')}
                        </td>
                        <td className="p-2 text-center text-slate-400">---</td>
                      </tr>
                      <tr>
                        <td className="p-2 border-r border-slate-300 font-bold">Term III (January to April)</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono">₹ {Math.round(selectedStudent.vanFees.termFee * 0.25).toLocaleString('en-IN')}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-700 font-bold">
                          {selectedStudent.vanFees.vanStatus === 'Paid' ? `₹ ${Math.round(selectedStudent.vanFees.termFee * 0.25).toLocaleString('en-IN')}` : '₹ 0'}
                        </td>
                        <td className="p-2 border-r border-slate-300 text-center">Pending</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-rose-700">
                          {selectedStudent.vanFees.vanStatus === 'Paid' ? 'NIL' : `₹ ${Math.max(0, selectedStudent.vanFees.termFee - selectedStudent.vanFees.paidAmount).toLocaleString('en-IN')}`}
                        </td>
                        <td className="p-2 text-center text-slate-400">---</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* GPay UPI QR Payment Footer Banner */}
            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-300 flex flex-wrap justify-between items-center gap-3 text-xs">
              <div className="flex items-center gap-3">
                {qrSrc && (
                  <img src={qrSrc} alt="GPay QR" className="w-14 h-14 bg-white p-1 rounded-lg border border-emerald-300 shadow-sm" />
                )}
                <div>
                  <span className="font-bold text-emerald-950 block text-xs">
                    Pay via Google Pay / UPI directly to Wisdom School
                  </span>
                  <span className="font-mono font-bold text-emerald-900 block text-xs">
                    UPI ID: {settings.upiId} • Mobile: {settings.gpayNumber}
                  </span>
                  <span className="text-[11px] text-emerald-800">
                    Payee Name: {settings.adminName} (Admin & Correspondent)
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenGpayModal(
                    activeCardType === 'tuition' 
                      ? Math.max(0, selectedStudent.schoolFees.totalFee - selectedStudent.schoolFees.paidAmount)
                      : Math.max(0, selectedStudent.vanFees.termFee - selectedStudent.vanFees.paidAmount),
                    selectedStudent.name
                  )}
                  className="px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow-sm"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Open GPay QR</span>
                </button>
              </div>
            </div>

            {/* Signatures */}
            <div className="pt-6 flex justify-between items-end text-xs border-t border-slate-300">
              <div className="text-center w-36 border-t border-dashed border-slate-500 pt-1">
                <span className="font-semibold text-slate-700 text-[11px]">Parent Signature</span>
              </div>
              <div className="text-center w-40 border-t border-dashed border-slate-500 pt-1">
                <span className="font-bold text-slate-900 block text-[11px]">Admin ({settings.adminName})</span>
                <span className="text-[9px] text-slate-500">Correspondent & Admin</span>
              </div>
              <div className="text-center w-40 border-t border-dashed border-slate-500 pt-1">
                <span className="font-bold text-slate-900 block text-[11px]">Principal ({settings.principalName})</span>
                <span className="text-[9px] text-slate-500">Authorized Signatory</span>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
