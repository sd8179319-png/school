import React, { useState } from 'react';
import { 
  AlertCircle, 
  IndianRupee, 
  Bus, 
  GraduationCap, 
  MessageCircle, 
  CreditCard, 
  QrCode, 
  Edit3, 
  Trash2,
  Plus,
  ChevronDown, 
  ChevronUp, 
  Filter, 
  Search, 
  DownloadCloud,
  ExternalLink,
  ShieldAlert
} from 'lucide-react';
import { Student, SchoolSettings } from '../types';
import { generateBulkSchoolFeesPdf, generateBulkVanFeesPdf } from '../utils/pdfGenerator';
import { generateFeeDueMessage } from '../utils/whatsappHelper';

interface PendingDuesSummaryProps {
  students: Student[];
  settings: SchoolSettings;
  onSelectForReceipt: (student: Student) => void;
  onOpenGpayModal: (amount?: number, studentName?: string) => void;
  onEditFees: (student: Student) => void;
  onNavigateToWhatsApp?: () => void;
  onEditStudent?: (student: Student) => void;
  onDeleteStudent?: (id: string) => void;
  onAddStudent?: () => void;
}

export const PendingDuesSummary: React.FC<PendingDuesSummaryProps> = ({
  students,
  settings,
  onSelectForReceipt,
  onOpenGpayModal,
  onEditFees,
  onNavigateToWhatsApp,
  onEditStudent,
  onDeleteStudent,
  onAddStudent,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [dueTypeFilter, setDueTypeFilter] = useState<'all' | 'school-only' | 'van-only'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  // Identify all students with pending school or van dues
  const allPendingStudents = students.filter(s => {
    const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
    const vanDue = s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0;
    return schoolDue > 0 || vanDue > 0;
  });

  // Calculate overall metrics
  const totalSchoolDueAll = allPendingStudents.reduce(
    (sum, s) => sum + Math.max(0, s.schoolFees.totalFee - s.schoolFees.paidAmount),
    0
  );
  const totalVanDueAll = allPendingStudents.reduce(
    (sum, s) => sum + (s.vanFees.usesVan ? Math.max(0, s.vanFees.termFee - s.vanFees.paidAmount) : 0),
    0
  );
  const totalGrandDueAll = totalSchoolDueAll + totalVanDueAll;

  // Filter based on user selection
  const filteredPendingStudents = allPendingStudents.filter(s => {
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;

    const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
    const vanDue = s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0;

    if (dueTypeFilter === 'school-only' && schoolDue <= 0) return false;
    if (dueTypeFilter === 'van-only' && (!s.vanFees.usesVan || vanDue <= 0)) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = s.name.toLowerCase().includes(q);
      const matchAdm = s.admissionNo.toLowerCase().includes(q);
      const matchPhone = s.parentPhone.includes(q);
      return matchName || matchAdm || matchPhone;
    }

    return true;
  });

  const handleSendWhatsApp = (student: Student) => {
    const msg = generateFeeDueMessage(student, settings, 'en');
    const clean = student.parentPhone.replace(/\D/g, '');
    const phone = clean.length === 10 ? `91${clean}` : clean;
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="bg-white rounded-2xl shadow-md border-2 border-rose-200 overflow-hidden transition-all duration-300">
      
      {/* Top Banner Header */}
      <div 
        onClick={() => setIsExpanded(!isExpanded)}
        className="bg-gradient-to-r from-rose-900 via-rose-800 to-amber-900 text-white p-4 cursor-pointer flex flex-wrap justify-between items-center gap-3 select-none"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center text-rose-300 shadow-inner">
            <ShieldAlert className="w-6 h-6 text-amber-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-base md:text-lg leading-tight tracking-tight">
                Current Term Pending Dues Summary
              </h3>
              <span className="text-[10px] bg-amber-400 text-slate-950 font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
                {allPendingStudents.length} Students Unpaid
              </span>
            </div>
            <p className="text-xs text-rose-200">
              Unpaid school tuition & van transport fees • GPay: <strong className="text-white font-mono">{settings.upiId}</strong> ({settings.gpayNumber})
            </p>
          </div>
        </div>

        {/* Quick Amount Highlights & Toggle */}
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <span className="text-[10px] uppercase font-bold text-rose-200 block">Total Outstanding</span>
            <span className="text-lg font-mono font-extrabold text-amber-300">
              ₹ {totalGrandDueAll.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition">
            {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </div>
        </div>
      </div>

      {/* Expandable Body */}
      {isExpanded && (
        <div className="p-4 sm:p-5 space-y-4 bg-slate-50/50">
          
          {/* Key Metrics Dashboard Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            
            {/* Card 1: Students Count */}
            <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Unpaid Students</span>
                <span className="p-1 bg-rose-50 text-rose-600 rounded">
                  <AlertCircle className="w-3.5 h-3.5" />
                </span>
              </div>
              <div className="mt-1 text-xl font-extrabold text-slate-900 font-mono">
                {allPendingStudents.length}
              </div>
              <span className="text-[10px] text-slate-500">In LKG to 5th Std</span>
            </div>

            {/* Card 2: School Fee Due */}
            <div className="bg-white p-3.5 rounded-xl border border-blue-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold uppercase tracking-wider text-blue-700">School Fees Due</span>
                <span className="p-1 bg-blue-50 text-blue-600 rounded">
                  <GraduationCap className="w-3.5 h-3.5" />
                </span>
              </div>
              <div className="mt-1 text-xl font-extrabold text-blue-900 font-mono">
                ₹ {totalSchoolDueAll.toLocaleString('en-IN')}
              </div>
              <span className="text-[10px] text-slate-500">Tuition, Exam, Books</span>
            </div>

            {/* Card 3: Van Fee Due */}
            <div className="bg-white p-3.5 rounded-xl border border-amber-200 shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800">Van Fees Due</span>
                <span className="p-1 bg-amber-50 text-amber-700 rounded">
                  <Bus className="w-3.5 h-3.5" />
                </span>
              </div>
              <div className="mt-1 text-xl font-extrabold text-amber-900 font-mono">
                ₹ {totalVanDueAll.toLocaleString('en-IN')}
              </div>
              <span className="text-[10px] text-slate-500">Transport & Bus Passes</span>
            </div>

            {/* Card 4: Total Grand Due & GPay */}
            <div className="bg-gradient-to-br from-rose-600 to-rose-700 text-white p-3.5 rounded-xl shadow-sm">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-100">Total Due (Combined)</span>
                <span className="p-1 bg-white/20 text-white rounded">
                  <IndianRupee className="w-3.5 h-3.5" />
                </span>
              </div>
              <div className="mt-1 text-xl font-extrabold text-white font-mono">
                ₹ {totalGrandDueAll.toLocaleString('en-IN')}
              </div>
              <button
                onClick={() => onOpenGpayModal(totalGrandDueAll)}
                className="mt-1 text-[10px] font-semibold text-amber-300 hover:text-white flex items-center gap-1"
              >
                <QrCode className="w-3 h-3" /> GPay QR: {settings.upiId}
              </button>
            </div>

          </div>

          {/* Quick Filter Bar */}
          <div className="bg-white p-3 rounded-xl border border-slate-200 flex flex-wrap justify-between items-center gap-3 text-xs">
            
            {/* Class filter pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="font-bold text-slate-600 text-[11px] whitespace-nowrap">Filter Class:</span>
              {classesList.map((cls) => (
                <button
                  key={cls}
                  onClick={() => setSelectedClass(cls)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition whitespace-nowrap ${
                    selectedClass === cls
                      ? 'bg-rose-900 text-white shadow-sm'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>

            {/* Due Category Filter & Search */}
            <div className="flex items-center gap-2 flex-grow sm:flex-grow-0">
              <select
                value={dueTypeFilter}
                onChange={(e) => setDueTypeFilter(e.target.value as any)}
                className="border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-700 bg-white"
              >
                <option value="all">All Unpaid Dues</option>
                <option value="school-only">School Fees Unpaid Only</option>
                <option value="van-only">Van Fees Unpaid Only</option>
              </select>

              <div className="relative w-44 sm:w-56">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search student or phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-2.5 py-1 text-xs border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>
            </div>

          </div>

          {/* Students With Unpaid Fees Table / Cards */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="p-3 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
              <span className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-600" />
                <span>Unpaid Students List ({filteredPendingStudents.length} Found)</span>
              </span>

              <div className="flex items-center gap-2">
                {onAddStudent && (
                  <button
                    onClick={onAddStudent}
                    className="px-2.5 py-1 bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold rounded-lg transition flex items-center gap-1 shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Student</span>
                  </button>
                )}
                {onNavigateToWhatsApp && (
                  <button
                    onClick={onNavigateToWhatsApp}
                    className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold rounded-lg transition flex items-center gap-1 shadow-sm"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>WhatsApp All Unpaid</span>
                  </button>
                )}
                <button
                  onClick={() => generateBulkSchoolFeesPdf(students, settings, { statusFilter: 'due' })}
                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white text-[11px] font-bold rounded-lg transition flex items-center gap-1 shadow-sm"
                >
                  <DownloadCloud className="w-3.5 h-3.5" />
                  <span>Download Dues PDF</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto max-h-80 overflow-y-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] tracking-wider border-b sticky top-0">
                  <tr>
                    <th className="p-2.5">Adm No</th>
                    <th className="p-2.5">Student & Father</th>
                    <th className="p-2.5">Class</th>
                    <th className="p-2.5">Parent WhatsApp</th>
                    <th className="p-2.5 text-right">School Due</th>
                    <th className="p-2.5 text-right">Van Due</th>
                    <th className="p-2.5 text-right">Total Due</th>
                    <th className="p-2.5 text-right">Actions (Edit / Fees / Del)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPendingStudents.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-6 text-center text-slate-400 italic">
                        No students with pending dues found in this category! All accounts clear.
                      </td>
                    </tr>
                  ) : (
                    filteredPendingStudents.map((s) => {
                      const schoolDue = Math.max(0, s.schoolFees.totalFee - s.schoolFees.paidAmount);
                      const vanDue = s.vanFees.usesVan
                        ? Math.max(0, s.vanFees.termFee - s.vanFees.paidAmount)
                        : 0;
                      const combinedDue = schoolDue + vanDue;

                      return (
                        <tr key={s.id} className="hover:bg-rose-50/40 transition">
                          <td className="p-2.5 font-mono font-bold text-slate-800">
                            {s.admissionNo}
                          </td>
                          <td className="p-2.5">
                            <div className="font-bold text-slate-900">{s.name}</div>
                            <div className="text-[10px] text-slate-500">Father: {s.fatherName}</div>
                          </td>
                          <td className="p-2.5">
                            <span className="font-semibold text-slate-800">{s.studentClass}</span>
                            <span className="text-[10px] text-slate-500 ml-1">({s.section})</span>
                          </td>
                          <td className="p-2.5 font-mono text-slate-700">
                            {s.parentPhone}
                          </td>
                          <td className="p-2.5 text-right">
                            {schoolDue > 0 ? (
                              <div>
                                <span className="font-mono font-bold text-blue-900">
                                  ₹ {schoolDue.toLocaleString('en-IN')}
                                </span>
                                <div className="text-[9px] text-slate-500">{s.schoolFees.term}</div>
                              </div>
                            ) : (
                              <span className="text-emerald-700 font-semibold text-[10px]">Paid</span>
                            )}
                          </td>
                          <td className="p-2.5 text-right">
                            {s.vanFees.usesVan ? (
                              vanDue > 0 ? (
                                <div>
                                  <span className="font-mono font-bold text-amber-800">
                                    ₹ {vanDue.toLocaleString('en-IN')}
                                  </span>
                                  <div className="text-[9px] text-slate-500 truncate max-w-[100px]">
                                    {s.vanFees.pickupPoint}
                                  </div>
                                </div>
                              ) : (
                                <span className="text-emerald-700 font-semibold text-[10px]">Paid</span>
                              )
                            ) : (
                              <span className="text-slate-400 text-[10px]">No Van</span>
                            )}
                          </td>
                          <td className="p-2.5 text-right">
                            <span className="font-mono font-extrabold text-sm text-rose-700">
                              ₹ {combinedDue.toLocaleString('en-IN')}
                            </span>
                          </td>
                          <td className="p-2.5 text-right">
                            <div className="flex items-center justify-end gap-1 flex-wrap">
                              {/* Edit Student Info */}
                              {onEditStudent && (
                                <button
                                  onClick={() => onEditStudent(s)}
                                  className="px-2 py-1 rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-900 font-bold transition flex items-center gap-1 shadow-xs"
                                  title="Edit Student Info"
                                >
                                  <Edit3 className="w-3 h-3 text-blue-700" />
                                  <span>Edit</span>
                                </button>
                              )}

                              {/* Edit Fees */}
                              <button
                                onClick={() => onEditFees(s)}
                                className="px-2 py-1 rounded-lg bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold transition flex items-center gap-1 shadow-xs"
                                title="Edit Fee Particulars"
                              >
                                <IndianRupee className="w-3 h-3 text-amber-700" />
                                <span>Fees</span>
                              </button>

                              {/* Delete Student */}
                              {onDeleteStudent && (
                                <button
                                  onClick={() => {
                                    if (confirm(`Are you sure you want to delete student ${s.name} (${s.admissionNo})?`)) {
                                      onDeleteStudent(s.id);
                                    }
                                  }}
                                  className="px-2 py-1 rounded-lg bg-rose-100 hover:bg-rose-200 text-rose-700 font-bold transition flex items-center gap-1 shadow-xs"
                                  title="Delete Student Record"
                                >
                                  <Trash2 className="w-3 h-3 text-rose-600" />
                                  <span>Del</span>
                                </button>
                              )}

                              {/* Collect Fee / Open Receipt Maker */}
                              <button
                                onClick={() => onSelectForReceipt(s)}
                                className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition"
                                title="Bill Receipt / Collect Payment"
                              >
                                <CreditCard className="w-3.5 h-3.5" />
                              </button>

                              {/* GPay QR Code for exact balance */}
                              <button
                                onClick={() => onOpenGpayModal(combinedDue, s.name)}
                                className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition"
                                title="Show GPay QR Code (rsaravanan102002-1@okhdfcbank)"
                              >
                                <QrCode className="w-3.5 h-3.5" />
                              </button>

                              {/* WhatsApp Reminder */}
                              <button
                                onClick={() => handleSendWhatsApp(s)}
                                className="p-1.5 rounded-lg bg-teal-50 text-teal-700 hover:bg-teal-100 transition"
                                title="Send WhatsApp Due Notice"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
