import React, { useState } from 'react';
import { 
  FileDown, 
  FileText, 
  Bus, 
  GraduationCap, 
  CheckCircle, 
  AlertCircle, 
  Filter, 
  Layers, 
  QrCode,
  DownloadCloud
} from 'lucide-react';
import { Student, SchoolSettings, SchoolClass } from '../types';
import { 
  generateBulkSchoolFeesPdf, 
  generateBulkVanFeesPdf, 
  generateBulkReceiptSlipsPdf,
  generateBulkTuitionCardsPdf,
  generateBulkVanCardsPdf,
  BulkPdfFilter 
} from '../utils/pdfGenerator';
import { buildUpiUri, generateQrDataUrl } from '../utils/qrGenerator';

interface BulkPdfCenterProps {
  students: Student[];
  settings: SchoolSettings;
  onOpenGpayModal: () => void;
}

export const BulkPdfCenter: React.FC<BulkPdfCenterProps> = ({
  students,
  settings,
  onOpenGpayModal,
}) => {
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<'all' | 'due' | 'paid'>('all');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  const classesList = ['All', 'Pre-KG', 'LKG', 'UKG', '1st Standard', '2nd Standard', '3rd Standard', '4th Standard', '5th Standard'];

  // Filter students based on selection
  const filteredStudents = students.filter(s => {
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;
    if (statusFilter === 'due' && s.schoolFees.status === 'Paid') return false;
    if (statusFilter === 'paid' && s.schoolFees.status !== 'Paid') return false;
    return true;
  });

  const vanFiltered = students.filter(s => {
    if (!s.vanFees.usesVan) return false;
    if (selectedClass !== 'All' && s.studentClass !== selectedClass) return false;
    if (statusFilter === 'due' && s.vanFees.vanStatus === 'Paid') return false;
    if (statusFilter === 'paid' && s.vanFees.vanStatus !== 'Paid') return false;
    return true;
  });

  // School Fee Stats
  const totalSchoolBilled = filteredStudents.reduce((acc, s) => acc + s.schoolFees.totalFee, 0);
  const totalSchoolCollected = filteredStudents.reduce((acc, s) => acc + s.schoolFees.paidAmount, 0);
  const totalSchoolDue = totalSchoolBilled - totalSchoolCollected;

  // Van Fee Stats
  const totalVanBilled = vanFiltered.reduce((acc, s) => acc + s.vanFees.termFee, 0);
  const totalVanCollected = vanFiltered.reduce((acc, s) => acc + s.vanFees.paidAmount, 0);
  const totalVanDue = totalVanBilled - totalVanCollected;

  const handleDownloadSchoolFeeRegister = () => {
    setIsGenerating(true);
    setTimeout(() => {
      generateBulkSchoolFeesPdf(students, settings, {
        selectedClass,
        statusFilter,
      });
      setIsGenerating(false);
    }, 200);
  };

  const handleDownloadVanFeeRegister = () => {
    setIsGenerating(true);
    setTimeout(() => {
      generateBulkVanFeesPdf(students, settings, {
        selectedClass,
        statusFilter,
      });
      setIsGenerating(false);
    }, 200);
  };

  const handleDownloadSchoolSlips = async () => {
    setIsGenerating(true);
    const upiUri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
    });
    const qr = await generateQrDataUrl(upiUri);
    setTimeout(() => {
      generateBulkReceiptSlipsPdf(filteredStudents, settings, 'school-only', qr);
      setIsGenerating(false);
    }, 300);
  };

  const handleDownloadVanSlips = async () => {
    setIsGenerating(true);
    const upiUri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
    });
    const qr = await generateQrDataUrl(upiUri);
    setTimeout(() => {
      generateBulkReceiptSlipsPdf(vanFiltered, settings, 'van-only', qr);
      setIsGenerating(false);
    }, 300);
  };

  const handleDownloadBulkTuitionCards = async () => {
    setIsGenerating(true);
    const upiUri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
    });
    const qr = await generateQrDataUrl(upiUri);
    setTimeout(() => {
      generateBulkTuitionCardsPdf(filteredStudents, settings, qr);
      setIsGenerating(false);
    }, 300);
  };

  const handleDownloadBulkVanCards = async () => {
    setIsGenerating(true);
    const upiUri = buildUpiUri({
      upiId: settings.upiId,
      payeeName: settings.adminName,
    });
    const qr = await generateQrDataUrl(upiUri);
    setTimeout(() => {
      generateBulkVanCardsPdf(vanFiltered, settings, qr);
      setIsGenerating(false);
    }, 300);
  };

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex flex-wrap justify-between items-center gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <DownloadCloud className="w-5 h-5 text-blue-600" />
              <span>Bulk PDF Generation Center</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Generate official bulk PDF reports & printable slips: School Fees Only or Van Fee Only.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">
              Admin: <strong className="text-slate-900">{settings.adminName}</strong> | Principal:{' '}
              <strong className="text-slate-900">{settings.principalName}</strong>
            </span>
          </div>
        </div>

        {/* Global Filter Bar */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          {/* Class Filter */}
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-xs font-bold text-slate-700">Filter Class:</span>
            <div className="flex gap-1 overflow-x-auto">
              {classesList.map((cls) => (
                <button
                  key={cls}
                  onClick={() => setSelectedClass(cls)}
                  className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
                    selectedClass === cls
                      ? 'bg-blue-900 text-white font-bold'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {cls}
                </button>
              ))}
            </div>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-700">Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="border border-slate-300 rounded-lg px-2.5 py-1 text-xs text-slate-700 focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
            >
              <option value="all">All Records</option>
              <option value="due">Pending Dues Only</option>
              <option value="paid">Fully Paid Only</option>
            </select>
          </div>
        </div>
      </div>

      {/* TWO PRIMARY BULK DOWNLOAD COLUMNS: School Fees & Van Fees */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* CARD 1: SCHOOL FEES ONLY BULK PDF */}
        <div className="bg-white rounded-2xl shadow-sm border-2 border-blue-200 p-5 space-y-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-700 to-indigo-600"></div>

          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center font-bold">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                  Bulk School Fees Only
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  School Fees Bulk PDF
                </h3>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded">
              {filteredStudents.length} Students
            </span>
          </div>

          <p className="text-xs text-slate-600">
            Export comprehensive school fee ledgers or individual dual-copy fee receipts for all students in LKG to 5th Std.
          </p>

          {/* Metrics summary */}
          <div className="grid grid-cols-3 gap-2 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Billed</span>
              <span className="font-mono font-bold text-slate-900">
                ₹ {totalSchoolBilled.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-emerald-600 uppercase font-semibold block">Collected</span>
              <span className="font-mono font-bold text-emerald-700">
                ₹ {totalSchoolCollected.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-rose-600 uppercase font-semibold block">Balance Due</span>
              <span className="font-mono font-bold text-rose-700">
                ₹ {totalSchoolDue.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              disabled={isGenerating}
              onClick={handleDownloadSchoolFeeRegister}
              className="w-full py-2.5 px-4 bg-blue-800 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <FileDown className="w-4 h-4" />
              <span>Download School Fees Audit Register (PDF)</span>
            </button>

            <button
              disabled={isGenerating}
              onClick={handleDownloadSchoolSlips}
              className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Download Bulk School Fee Slips (Dual A4 PDF)</span>
            </button>

            <button
              disabled={isGenerating}
              onClick={handleDownloadBulkTuitionCards}
              className="w-full py-2.5 px-4 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <FileDown className="w-4 h-4 text-white" />
              <span>Download Bulk Tuition Fee Passbook Cards (PDF)</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Includes Admin: {settings.adminName}</span>
            <span>GPay: {settings.gpayNumber}</span>
          </div>
        </div>

        {/* CARD 2: VAN FEE ONLY BULK PDF */}
        <div className="bg-white rounded-2xl shadow-sm border-2 border-amber-200 p-5 space-y-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 to-amber-700"></div>

          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
                <Bus className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                  Bulk Van Fee Only
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  Van / Transport Fee Bulk PDF
                </h3>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-900 bg-amber-100 px-2 py-1 rounded">
              {vanFiltered.length} Van Riders
            </span>
          </div>

          <p className="text-xs text-slate-600">
            Export route-wise school bus registers, driver pickup checklists, and printable student transport passes.
          </p>

          {/* Metrics summary */}
          <div className="grid grid-cols-3 gap-2 p-3 bg-amber-50/50 rounded-xl border border-amber-200 text-xs">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold block">Van Fees</span>
              <span className="font-mono font-bold text-slate-900">
                ₹ {totalVanBilled.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-emerald-600 uppercase font-semibold block">Van Collected</span>
              <span className="font-mono font-bold text-emerald-700">
                ₹ {totalVanCollected.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-rose-600 uppercase font-semibold block">Van Dues</span>
              <span className="font-mono font-bold text-rose-700">
                ₹ {totalVanDue.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2">
            <button
              disabled={isGenerating}
              onClick={handleDownloadVanFeeRegister}
              className="w-full py-2.5 px-4 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <FileDown className="w-4 h-4" />
              <span>Download Van Fee Master Register (PDF)</span>
            </button>

            <button
              disabled={isGenerating}
              onClick={handleDownloadVanSlips}
              className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>Download Bulk Van Fee Receipts / Passes (PDF)</span>
            </button>

            <button
              disabled={isGenerating}
              onClick={handleDownloadBulkVanCards}
              className="w-full py-2.5 px-4 bg-amber-800 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow flex items-center justify-center gap-2"
            >
              <FileDown className="w-4 h-4 text-white" />
              <span>Download Bulk Van Transport Pass Cards (PDF)</span>
            </button>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2">
            <span>Route & Driver incharge audit sheet</span>
            <span>GPay: {settings.gpayNumber}</span>
          </div>
        </div>

      </div>

      {/* Table Preview of Currently Selected Students */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-5">
        <div className="flex justify-between items-center mb-3">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-700 flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-600" />
            <span>Target Student List for Bulk PDF ({filteredStudents.length} Students)</span>
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            Class: <strong className="text-slate-800">{selectedClass}</strong> • Status: <strong className="text-slate-800">{statusFilter.toUpperCase()}</strong>
          </span>
        </div>

        <div className="overflow-x-auto max-h-72 overflow-y-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[10px] tracking-wider border-b sticky top-0">
              <tr>
                <th className="p-2.5">Adm No</th>
                <th className="p-2.5">Student Name</th>
                <th className="p-2.5">Class & Sec</th>
                <th className="p-2.5">Parent Mobile</th>
                <th className="p-2.5 text-right">School Fee</th>
                <th className="p-2.5 text-right">School Due</th>
                <th className="p-2.5 text-right">Van Fee</th>
                <th className="p-2.5 text-right">Van Due</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((s) => {
                const schoolDue = s.schoolFees.totalFee - s.schoolFees.paidAmount;
                const vanDue = s.vanFees.usesVan ? s.vanFees.termFee - s.vanFees.paidAmount : 0;
                return (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="p-2.5 font-mono font-bold text-slate-800">{s.admissionNo}</td>
                    <td className="p-2.5 font-semibold text-slate-900">{s.name}</td>
                    <td className="p-2.5">{s.studentClass} - {s.section}</td>
                    <td className="p-2.5 font-mono text-slate-600">{s.parentPhone}</td>
                    <td className="p-2.5 text-right font-mono">₹ {s.schoolFees.totalFee.toLocaleString('en-IN')}</td>
                    <td className="p-2.5 text-right font-mono font-bold text-rose-700">₹ {schoolDue.toLocaleString('en-IN')}</td>
                    <td className="p-2.5 text-right font-mono">
                      {s.vanFees.usesVan ? `₹ ${s.vanFees.termFee.toLocaleString('en-IN')}` : '-'}
                    </td>
                    <td className="p-2.5 text-right font-mono font-bold text-amber-800">
                      {s.vanFees.usesVan ? `₹ ${vanDue.toLocaleString('en-IN')}` : '-'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
