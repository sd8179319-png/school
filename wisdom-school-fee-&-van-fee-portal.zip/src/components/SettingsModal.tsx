import React, { useState } from 'react';
import { X, Save, RotateCcw, ShieldCheck, School, Smartphone, Upload, Image as ImageIcon, Trash2 } from 'lucide-react';
import { SchoolSettings } from '../types';
import { DEFAULT_SETTINGS, DEFAULT_SCHOOL_LOGO } from '../utils/sampleData';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SchoolSettings;
  onSaveSettings: (settings: SchoolSettings) => void;
  onResetData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  onResetData,
}) => {
  const [formData, setFormData] = useState<SchoolSettings>({ ...settings });

  if (!isOpen) return null;

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('Logo file size must be less than 2MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setFormData(prev => ({ ...prev, logoUrl: dataUrl }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetLogo = () => {
    setFormData(prev => ({ ...prev, logoUrl: DEFAULT_SCHOOL_LOGO }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    alert('Settings and School Logo updated successfully!');
    onClose();
  };

  const handleResetToDefault = () => {
    if (confirm('Reset all school & payment configuration back to default settings?')) {
      setFormData({ ...DEFAULT_SETTINGS });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto border border-slate-200">
        <div className="bg-gradient-to-r from-slate-900 to-blue-950 p-4 text-white flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <School className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base">School & GPay Configuration</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          
          {/* School Official Logo Upload Card */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-bold uppercase tracking-wider text-slate-700 text-[10px] flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-blue-600" />
                <span>School Logo & Seal (For Receipts, ID Cards & Fee Cards)</span>
              </span>
              {formData.logoUrl && formData.logoUrl !== DEFAULT_SCHOOL_LOGO && (
                <button
                  type="button"
                  onClick={handleResetLogo}
                  className="text-[10px] text-rose-600 hover:underline flex items-center gap-1 font-semibold"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Reset to Default Logo</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-4 pt-1">
              {/* Logo Preview */}
              <div className="w-16 h-16 rounded-xl border-2 border-slate-300 bg-white p-1 flex items-center justify-center shadow-sm overflow-hidden shrink-0">
                <img
                  src={formData.logoUrl || DEFAULT_SCHOOL_LOGO}
                  alt="School Logo Preview"
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Upload Input */}
              <div className="space-y-1 flex-grow">
                <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer shadow-sm transition">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload School Logo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>
                <p className="text-[10px] text-slate-500">
                  Recommended: Square PNG, JPG or SVG with transparent or white background (Max 2MB).
                </p>
              </div>
            </div>
          </div>
          {/* Key Administration & GPay Credentials */}
          <div className="bg-blue-50/70 p-3.5 rounded-xl border border-blue-200 space-y-3">
            <div className="flex items-center gap-2 text-blue-950 font-bold">
              <ShieldCheck className="w-4 h-4 text-blue-700" />
              <span>Admin, Principal & Google Pay (GPAY) Information</span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Administrator / Correspondent Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.adminName}
                  onChange={(e) => setFormData({ ...formData, adminName: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Principal Name *
                </label>
                <input
                  type="text"
                  required
                  value={formData.principalName}
                  onChange={(e) => setFormData({ ...formData, principalName: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-bold text-slate-900 bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-emerald-800 mb-1 flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Google Pay (GPay) Mobile *</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.gpayNumber}
                  onChange={(e) => setFormData({ ...formData, gpayNumber: e.target.value })}
                  placeholder="917659319"
                  className="w-full border border-emerald-400 bg-emerald-50/80 rounded-lg p-2 font-mono font-bold text-emerald-950"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  UPI VPA ID (for QR Code) *
                </label>
                <input
                  type="text"
                  required
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                  placeholder="rsaravanan102002-1@okhdfcbank"
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono text-slate-900 bg-white"
                />
              </div>
            </div>
          </div>

          {/* School Details */}
          <div className="space-y-3">
            <h4 className="font-bold uppercase tracking-wider text-slate-500 text-[10px] border-b pb-1">
              Institution Letterhead Details
            </h4>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">School Full Name</label>
              <input
                type="text"
                value={formData.schoolName}
                onChange={(e) => setFormData({ ...formData, schoolName: e.target.value })}
                className="w-full border border-slate-300 rounded-lg p-2 font-semibold text-slate-900"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Government Recognition / Code</label>
              <input
                type="text"
                value={formData.affiliation}
                onChange={(e) => setFormData({ ...formData, affiliation: e.target.value })}
                className="w-full border border-slate-300 rounded-lg p-2 text-slate-800"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Address Line 1</label>
                <input
                  type="text"
                  value={formData.addressLine1}
                  onChange={(e) => setFormData({ ...formData, addressLine1: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Address Line 2 (District & PIN)</label>
                <input
                  type="text"
                  value={formData.addressLine2}
                  onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Primary Phone</label>
                <input
                  type="text"
                  value={formData.phone1}
                  onChange={(e) => setFormData({ ...formData, phone1: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Academic Year</label>
                <input
                  type="text"
                  value={formData.currentAcademicYear}
                  onChange={(e) => setFormData({ ...formData, currentAcademicYear: e.target.value })}
                  className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold"
                />
              </div>
            </div>
          </div>

          {/* Reset Actions */}
          <div className="pt-2 border-t flex justify-between items-center">
            <button
              type="button"
              onClick={handleResetToDefault}
              className="px-3 py-1.5 text-xs text-rose-600 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition font-semibold"
            >
              Reset Configuration
            </button>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-xl hover:bg-slate-100 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold shadow-sm flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
