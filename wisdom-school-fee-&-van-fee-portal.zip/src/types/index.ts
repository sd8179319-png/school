export type SchoolClass = 
  | 'Pre-KG' 
  | 'LKG' 
  | 'UKG' 
  | '1st Standard' 
  | '2nd Standard' 
  | '3rd Standard' 
  | '4th Standard' 
  | '5th Standard';

export type Section = 'A' | 'B' | 'C';

export type PaymentMode = 'Cash' | 'GPay / UPI' | 'Bank / Cheque';

export type PaymentStatus = 'Paid' | 'Partial' | 'Pending';

export interface FeeStructure {
  admissionFee: number;
  tuitionFee: number;
  examFee: number;
  booksStationeryFee: number;
  uniformActivityFee: number;
  otherFee: number;
}

export interface VanFeeDetails {
  usesVan: boolean;
  route: string;
  pickupPoint: string;
  termFee: number;
  paidAmount: number;
  lastPaymentDate?: string;
  vanStatus: PaymentStatus;
}

export interface Student {
  id: string;
  admissionNo: string;
  name: string;
  fatherName: string;
  motherName?: string;
  studentClass: SchoolClass;
  section: Section;
  gender: 'Male' | 'Female';
  parentPhone: string;
  whatsappPhone: string;
  address: string;
  academicYear: string;
  schoolFees: {
    totalFee: number;
    paidAmount: number;
    term: string; // e.g. "Term 1", "Term 2", "Term 3", "Annual"
    feeBreakdown: FeeStructure;
    lastPaymentDate?: string;
    status: PaymentStatus;
  };
  vanFees: VanFeeDetails;
  remarks?: string;
  photoUrl?: string;
  bloodGroup?: string;
  dob?: string;
  emergencyContact?: string;
}

export interface FeeReceipt {
  id: string;
  receiptNo: string;
  date: string;
  studentId: string;
  studentName: string;
  admissionNo: string;
  studentClass: SchoolClass;
  section: Section;
  academicYear: string;
  feeType: 'School Fee' | 'Van Fee' | 'Combined';
  term: string;
  items: {
    description: string;
    amount: number;
  }[];
  totalAmount: number;
  paidAmount: number;
  balanceAmount: number;
  paymentMode: PaymentMode;
  transactionRef?: string;
  receivedBy: string; // Admin Saravanan or Principal Chithra
  remarks?: string;
}

export interface SchoolSettings {
  schoolName: string;
  affiliation: string;
  addressLine1: string;
  addressLine2: string;
  phone1: string;
  phone2: string;
  email: string;
  adminName: string;
  adminRole: string;
  principalName: string;
  principalRole: string;
  gpayNumber: string;
  upiId: string;
  currentAcademicYear: string;
  logoUrl?: string;
}
