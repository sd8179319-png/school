# Wisdom School Fee & Van Fee Portal

## Run locally

**Prerequisites:** Node.js

1. Install dependencies: `npm install --legacy-peer-deps`
2. Start the development server: `npm run dev`

## Deploy to GitHub Pages

The workflow in `.github/workflows/deploy.yml` extracts the website source from
`wisdom-school-fee-&-van-fee-portal.zip`, then builds and deploys it whenever changes
are pushed to `main`, or when started manually from the Actions tab. The repository's
Pages setting must use **GitHub Actions** as its build and deployment source.

The deployed site is available at
https://sd8179319-png.github.io/school/ after the first successful workflow run.

Student records, receipts, and settings are saved in IndexedDB in each visitor's
browser. GitHub Pages does not provide shared server-side storage or synchronization
between devices.
